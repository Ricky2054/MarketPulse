import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import styled from 'styled-components';
import { logout } from '../../store/slices/authSlice';
import { RootState } from '../../store';

const HeaderContainer = styled.header`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
  height: 70px;
  background-color: #ffffff;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const Logo = styled.div`
  font-size: 24px;
  font-weight: bold;
  color: #2c3e50;
`;

const NavItems = styled.div`
  display: flex;
  align-items: center;
`;

const SearchBar = styled.div`
  position: relative;
  margin-right: 20px;
  
  input {
    padding: 8px 12px;
    padding-left: 35px;
    border-radius: 20px;
    border: 1px solid #e0e0e0;
    width: 250px;
    font-size: 14px;
    
    &:focus {
      outline: none;
      border-color: #3498db;
    }
  }
  
  svg {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: #95a5a6;
  }
`;

const UserMenu = styled.div`
  position: relative;
  display: flex;
  align-items: center;
  cursor: pointer;
  
  img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 10px;
  }
  
  span {
    font-weight: 500;
  }
`;

const DropdownMenu = styled.div<{ isOpen: boolean }>`
  position: absolute;
  top: 50px;
  right: 0;
  background-color: #ffffff;
  border-radius: 4px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  width: 200px;
  z-index: 100;
  display: ${(props) => (props.isOpen ? 'block' : 'none')};
  
  ul {
    list-style: none;
    padding: 0;
    margin: 0;
    
    li {
      padding: 12px 16px;
      border-bottom: 1px solid #f1f1f1;
      
      &:last-child {
        border-bottom: none;
      }
      
      &:hover {
        background-color: #f9f9f9;
      }
      
      a, button {
        text-decoration: none;
        color: #2c3e50;
        background: none;
        border: none;
        font-size: 14px;
        cursor: pointer;
        width: 100%;
        text-align: left;
        padding: 0;
        
        &:hover {
          color: #3498db;
        }
      }
    }
  }
`;

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  const { user } = useSelector((state: RootState) => state.auth);
  
  const handleLogout = () => {
    dispatch(logout());
    navigate('/login');
  };
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  
  const handleSearch = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      // Implement search functionality
      console.log('Searching for:', searchTerm);
    }
  };
  
  return (
    <HeaderContainer>
      <Logo>MarketPulse</Logo>
      
      <NavItems>
        <SearchBar>
          <input
            type="text"
            placeholder="Search assets, markets..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={handleSearch}
          />
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
        </SearchBar>
        
        {user && (
          <UserMenu onClick={toggleMenu}>
            <img src={user.profileImage || 'https://via.placeholder.com/40'} alt="User" />
            <span>{user.name}</span>
            
            <DropdownMenu isOpen={isMenuOpen}>
              <ul>
                <li>
                  <button onClick={() => navigate('/profile')}>Profile</button>
                </li>
                <li>
                  <button onClick={() => navigate('/settings')}>Settings</button>
                </li>
                <li>
                  <button onClick={handleLogout}>Logout</button>
                </li>
              </ul>
            </DropdownMenu>
          </UserMenu>
        )}
      </NavItems>
    </HeaderContainer>
  );
};

export default Header; 