import { Routes, Route } from 'react-router-dom';
import { useEffect } from 'react';
import styled from 'styled-components';

// Pages
import Dashboard from './pages/dashboard/Dashboard';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import Trading from './pages/trading/Trading';
import Analytics from './pages/analytics/Analytics';
import Tokenization from './pages/tokenization/Tokenization';

// Components
import Header from './components/common/Header';
import Sidebar from './components/common/Sidebar';
import ProtectedRoute from './components/auth/ProtectedRoute';

const AppContainer = styled.div`
  display: flex;
  height: 100vh;
  background-color: #f5f7fa;
`;

const MainContent = styled.main`
  flex: 1;
  padding: 20px;
  overflow-y: auto;
`;

function App() {
  useEffect(() => {
    // Initialize any app-wide services or connections
    // For example, WebSocket connections for real-time data
  }, []);

  return (
    <AppContainer>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <Header />
        <MainContent>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/trading" element={<ProtectedRoute><Trading /></ProtectedRoute>} />
            <Route path="/analytics" element={<ProtectedRoute><Analytics /></ProtectedRoute>} />
            <Route path="/tokenization" element={<ProtectedRoute><Tokenization /></ProtectedRoute>} />
          </Routes>
        </MainContent>
      </div>
    </AppContainer>
  );
}

export default App; 