import User from '../models/User.js';
import AppError from '../utils/appError.js';
import { logger } from '../utils/logger.js';

// @desc    Get all users
// @route   GET /api/v1/users
// @access  Private/Admin
export const getUsers = async (req, res, next) => {
  try {
    const users = await User.find();

    res.status(200).json({
      success: true,
      count: users.length,
      data: users,
    });
  } catch (error) {
    logger.error(`Error getting users: ${error.message}`);
    next(error);
  }
};

// @desc    Get single user
// @route   GET /api/v1/users/:id
// @access  Private/Admin
export const getUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id || req.user.id);

    if (!user) {
      return next(new AppError(`User not found with id of ${req.params.id}`, 404));
    }

    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    logger.error(`Error getting user: ${error.message}`);
    next(error);
  }
};

// @desc    Update user
// @route   PUT /api/v1/users/:id
// @access  Private/Admin
export const updateUser = async (req, res, next) => {
  try {
    // Get user ID (either from params for admin or from authenticated user)
    const userId = req.params.id || req.user.id;
    
    // Check if user exists
    let user = await User.findById(userId);
    
    if (!user) {
      return next(new AppError(`User not found with id of ${userId}`, 404));
    }
    
    // Check if user is trying to update email
    if (req.body.email && req.body.email !== user.email) {
      // Check if email is already in use
      const existingUser = await User.findOne({ email: req.body.email });
      if (existingUser) {
        return next(new AppError('Email already in use', 400));
      }
    }
    
    // Fields to update
    const fieldsToUpdate = {
      name: req.body.name,
      email: req.body.email,
      phone: req.body.phone,
      country: req.body.country,
      preferences: req.body.preferences,
    };
    
    // Remove undefined fields
    Object.keys(fieldsToUpdate).forEach(key => 
      fieldsToUpdate[key] === undefined && delete fieldsToUpdate[key]
    );
    
    // Update user
    user = await User.findByIdAndUpdate(
      userId,
      fieldsToUpdate,
      {
        new: true,
        runValidators: true,
      }
    );
    
    logger.info(`User updated: ${user._id}`);
    
    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    logger.error(`Error updating user: ${error.message}`);
    next(error);
  }
};

// @desc    Delete user
// @route   DELETE /api/v1/users/:id
// @access  Private/Admin
export const deleteUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return next(new AppError(`User not found with id of ${req.params.id}`, 404));
    }

    await user.deleteOne();
    
    logger.info(`User deleted: ${req.params.id}`);

    res.status(200).json({
      success: true,
      data: {},
    });
  } catch (error) {
    logger.error(`Error deleting user: ${error.message}`);
    next(error);
  }
};

// @desc    Register push subscription
// @route   POST /api/v1/users/push-subscription
// @access  Private
export const registerPushSubscription = async (req, res, next) => {
  try {
    const { subscription } = req.body;

    if (!subscription) {
      return next(new AppError('Please provide a subscription object', 400));
    }

    // Update user with push subscription
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { pushSubscription: subscription },
      {
        new: true,
        runValidators: true,
      }
    );

    logger.info(`Push subscription registered for user: ${req.user.id}`);

    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    logger.error(`Error registering push subscription: ${error.message}`);
    next(error);
  }
}; 