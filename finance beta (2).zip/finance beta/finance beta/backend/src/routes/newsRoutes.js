import express from 'express';
import {
  getNews,
  getNewsArticle,
  createNewsArticle,
  updateNewsArticle,
  deleteNewsArticle,
  likeNewsArticle,
  unlikeNewsArticle,
  shareNewsArticle,
  getTrendingNews,
  getNewsByAsset,
  getNewsSentiment,
  getNewsMetadata,
} from '../controllers/newsController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { validate, schemas } from '../utils/validator.js';

const router = express.Router();

// Public routes
router.get('/', getNews);
router.get('/trending', getTrendingNews);
router.get('/asset/:symbol', getNewsByAsset);
router.get('/sentiment/:symbol', getNewsSentiment);
router.get('/metadata', getNewsMetadata);
router.get('/:id', getNewsArticle);

// Protected routes
router.use(authenticate);
router.post('/:id/like', likeNewsArticle);
router.post('/:id/unlike', unlikeNewsArticle);
router.post('/:id/share', shareNewsArticle);

// Admin routes
router.post('/', authorize('admin'), validate(schemas.newsCreate), createNewsArticle);
router.put('/:id', authorize('admin'), validate(schemas.newsUpdate), updateNewsArticle);
router.delete('/:id', authorize('admin'), deleteNewsArticle);

export default router; 