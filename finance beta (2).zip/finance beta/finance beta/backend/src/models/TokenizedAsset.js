import mongoose from 'mongoose';

const TokenizedAssetSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    symbol: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },
    description: {
      type: String,
      required: true,
    },
    assetType: {
      type: String,
      enum: ['real_estate', 'art', 'collectible', 'commodity', 'equity', 'fund', 'debt', 'other'],
      required: true,
    },
    tokenStandard: {
      type: String,
      enum: ['ERC20', 'ERC721', 'ERC1155', 'BEP20', 'other'],
      required: true,
    },
    blockchain: {
      network: {
        type: String,
        required: true,
        enum: ['ethereum', 'polygon', 'binance', 'solana', 'avalanche', 'other'],
      },
      contractAddress: {
        type: String,
        required: true,
      },
      deploymentTxHash: String,
      deploymentDate: Date,
      deploymentBlock: Number,
    },
    totalSupply: {
      type: Number,
      required: true,
      min: [0, 'Total supply cannot be negative'],
    },
    circulatingSupply: {
      type: Number,
      required: true,
      min: [0, 'Circulating supply cannot be negative'],
    },
    tokenPrice: {
      type: Number,
      required: true,
      min: [0, 'Token price cannot be negative'],
    },
    marketCap: {
      type: Number,
      min: [0, 'Market cap cannot be negative'],
    },
    priceHistory: [
      {
        date: {
          type: Date,
          required: true,
        },
        price: {
          type: Number,
          required: true,
        },
        volume: Number,
      },
    ],
    underlyingAsset: {
      type: {
        type: String,
        required: true,
      },
      identifier: {
        type: String,
        required: true,
      },
      location: String,
      value: {
        type: Number,
        required: true,
      },
      valuationDate: {
        type: Date,
        required: true,
      },
      valuationMethod: String,
      valuationProvider: String,
      documents: [
        {
          name: String,
          description: String,
          fileUrl: String,
          fileHash: String,
          uploadDate: Date,
        },
      ],
    },
    issuer: {
      name: {
        type: String,
        required: true,
      },
      description: String,
      website: String,
      legalEntity: String,
      jurisdiction: String,
      regulatoryCompliance: [String],
      contactEmail: String,
    },
    governance: {
      votingRights: Boolean,
      dividendRights: Boolean,
      redemptionRights: Boolean,
      votingMechanism: String,
      governanceDocuments: [
        {
          name: String,
          description: String,
          fileUrl: String,
          fileHash: String,
        },
      ],
    },
    distribution: {
      initialOffering: {
        type: {
          type: String,
          enum: ['ico', 'sto', 'ieo', 'ido', 'private_sale', 'other'],
        },
        startDate: Date,
        endDate: Date,
        initialPrice: Number,
        amountRaised: Number,
        currency: String,
      },
      tokenomics: {
        teamAllocation: Number,
        publicSale: Number,
        reserve: Number,
        vesting: [
          {
            group: String,
            percentage: Number,
            vestingPeriod: Number, // in months
            cliff: Number, // in months
            tgeUnlock: Number, // percentage
          },
        ],
      },
    },
    trading: {
      exchanges: [
        {
          name: String,
          url: String,
          pairings: [String],
          volume24h: Number,
        },
      ],
      restrictions: [String],
    },
    media: {
      logo: String,
      images: [String],
      videos: [String],
    },
    socialMedia: {
      website: String,
      twitter: String,
      telegram: String,
      discord: String,
      reddit: String,
      medium: String,
      github: String,
    },
    status: {
      type: String,
      enum: ['active', 'inactive', 'pending', 'suspended'],
      default: 'pending',
    },
    verified: {
      type: Boolean,
      default: false,
    },
    verificationDetails: {
      verifiedBy: String,
      verificationDate: Date,
      verificationDocuments: [
        {
          name: String,
          description: String,
          fileUrl: String,
          fileHash: String,
        },
      ],
    },
    riskRating: {
      score: {
        type: Number,
        min: 1,
        max: 10,
      },
      factors: [
        {
          name: String,
          description: String,
          impact: {
            type: String,
            enum: ['low', 'medium', 'high'],
          },
        },
      ],
      lastUpdated: Date,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Indexes for faster queries
TokenizedAssetSchema.index({ symbol: 1 }, { unique: true });
TokenizedAssetSchema.index({ 'blockchain.contractAddress': 1 }, { unique: true });
TokenizedAssetSchema.index({ assetType: 1 });
TokenizedAssetSchema.index({ status: 1 });
TokenizedAssetSchema.index({ createdBy: 1 });
TokenizedAssetSchema.index({ tokenPrice: 1 });

// Virtual for asset URL
TokenizedAssetSchema.virtual('assetUrl').get(function () {
  return `/tokenized-assets/${this.symbol.toLowerCase()}`;
});

// Method to update token price
TokenizedAssetSchema.methods.updatePrice = async function (newPrice, volume = 0) {
  const priceChange = this.tokenPrice > 0 ? (newPrice - this.tokenPrice) / this.tokenPrice * 100 : 0;
  
  // Add to price history
  this.priceHistory.push({
    date: new Date(),
    price: newPrice,
    volume: volume,
  });
  
  // Limit history to last 100 entries
  if (this.priceHistory.length > 100) {
    this.priceHistory.shift();
  }
  
  // Update current price and market cap
  this.tokenPrice = newPrice;
  this.marketCap = this.circulatingSupply * newPrice;
  
  return this.save();
};

// Static method to find tokenized assets with pagination and filtering
TokenizedAssetSchema.statics.findTokenizedAssets = async function (
  filters = {},
  page = 1,
  limit = 20,
  sort = { createdAt: -1 }
) {
  const query = { ...filters };
  
  const total = await this.countDocuments(query);
  const assets = await this.find(query)
    .sort(sort)
    .skip((page - 1) * limit)
    .limit(limit)
    .populate('createdBy', 'name email');
  
  return {
    assets,
    pagination: {
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    },
  };
};

// Static method to get market statistics
TokenizedAssetSchema.statics.getMarketStats = async function () {
  const stats = await this.aggregate([
    {
      $match: { status: 'active' },
    },
    {
      $group: {
        _id: '$assetType',
        count: { $sum: 1 },
        totalMarketCap: { $sum: '$marketCap' },
        avgPrice: { $avg: '$tokenPrice' },
      },
    },
  ]);
  
  // Calculate total market stats
  const totalStats = await this.aggregate([
    {
      $match: { status: 'active' },
    },
    {
      $group: {
        _id: null,
        totalAssets: { $sum: 1 },
        totalMarketCap: { $sum: '$marketCap' },
        avgPrice: { $avg: '$tokenPrice' },
      },
    },
  ]);
  
  return {
    byAssetType: stats,
    total: totalStats[0] || { totalAssets: 0, totalMarketCap: 0, avgPrice: 0 },
  };
};

const TokenizedAsset = mongoose.model('TokenizedAsset', TokenizedAssetSchema);

export default TokenizedAsset; 