import { logger } from './logger.js';

/**
 * Socket.io event handlers
 * @param {Object} io - Socket.io instance
 * @param {Object} redisClient - Redis client
 */
export const setupSocketEvents = (io, redisClient) => {
  // Track connected users
  const connectedUsers = new Map();
  
  // Handle connection
  io.on('connection', (socket) => {
    logger.info(`Socket connected: ${socket.id}`);
    
    // Handle authentication
    socket.on('authenticate', async (data) => {
      try {
        const { userId, token } = data;
        
        if (!userId || !token) {
          socket.emit('error', { message: 'Authentication failed: Missing userId or token' });
          return;
        }
        
        // Check if token is blacklisted
        const isBlacklisted = await redisClient.get(`blacklist_${token}`);
        if (isBlacklisted) {
          socket.emit('error', { message: 'Authentication failed: Token is invalid' });
          return;
        }
        
        // Store user info
        connectedUsers.set(socket.id, { userId, rooms: [] });
        
        // Join user's room
        socket.join(`user_${userId}`);
        connectedUsers.get(socket.id).rooms.push(`user_${userId}`);
        
        socket.emit('authenticated', { userId });
        logger.info(`Socket authenticated: ${socket.id} for user ${userId}`);
      } catch (error) {
        logger.error(`Socket authentication error: ${error.message}`);
        socket.emit('error', { message: 'Authentication failed: Server error' });
      }
    });
    
    // Handle subscribing to market updates
    socket.on('subscribe', (data) => {
      try {
        const { symbols } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (!userInfo) {
          socket.emit('error', { message: 'Not authenticated' });
          return;
        }
        
        if (symbols && Array.isArray(symbols)) {
          // Join rooms for each symbol
          symbols.forEach((symbol) => {
            const room = `market_${symbol.toUpperCase()}`;
            socket.join(room);
            userInfo.rooms.push(room);
          });
          
          socket.emit('subscribed', { symbols });
          logger.info(`Socket ${socket.id} subscribed to symbols: ${symbols.join(', ')}`);
        }
      } catch (error) {
        logger.error(`Socket subscription error: ${error.message}`);
        socket.emit('error', { message: 'Subscription failed: Server error' });
      }
    });
    
    // Handle unsubscribing from market updates
    socket.on('unsubscribe', (data) => {
      try {
        const { symbols } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (!userInfo) {
          socket.emit('error', { message: 'Not authenticated' });
          return;
        }
        
        if (symbols && Array.isArray(symbols)) {
          // Leave rooms for each symbol
          symbols.forEach((symbol) => {
            const room = `market_${symbol.toUpperCase()}`;
            socket.leave(room);
            
            // Remove from user's rooms
            const index = userInfo.rooms.indexOf(room);
            if (index !== -1) {
              userInfo.rooms.splice(index, 1);
            }
          });
          
          socket.emit('unsubscribed', { symbols });
          logger.info(`Socket ${socket.id} unsubscribed from symbols: ${symbols.join(', ')}`);
        }
      } catch (error) {
        logger.error(`Socket unsubscription error: ${error.message}`);
        socket.emit('error', { message: 'Unsubscription failed: Server error' });
      }
    });
    
    // Handle subscribing to portfolio updates
    socket.on('subscribePortfolio', (data) => {
      try {
        const { portfolioIds } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (!userInfo) {
          socket.emit('error', { message: 'Not authenticated' });
          return;
        }
        
        if (portfolioIds && Array.isArray(portfolioIds)) {
          // Join rooms for each portfolio
          portfolioIds.forEach((portfolioId) => {
            const room = `portfolio_${portfolioId}`;
            socket.join(room);
            userInfo.rooms.push(room);
          });
          
          socket.emit('portfolioSubscribed', { portfolioIds });
          logger.info(`Socket ${socket.id} subscribed to portfolios: ${portfolioIds.join(', ')}`);
        }
      } catch (error) {
        logger.error(`Socket portfolio subscription error: ${error.message}`);
        socket.emit('error', { message: 'Portfolio subscription failed: Server error' });
      }
    });
    
    // Handle unsubscribing from portfolio updates
    socket.on('unsubscribePortfolio', (data) => {
      try {
        const { portfolioIds } = data;
        const userInfo = connectedUsers.get(socket.id);
        
        if (!userInfo) {
          socket.emit('error', { message: 'Not authenticated' });
          return;
        }
        
        if (portfolioIds && Array.isArray(portfolioIds)) {
          // Leave rooms for each portfolio
          portfolioIds.forEach((portfolioId) => {
            const room = `portfolio_${portfolioId}`;
            socket.leave(room);
            
            // Remove from user's rooms
            const index = userInfo.rooms.indexOf(room);
            if (index !== -1) {
              userInfo.rooms.splice(index, 1);
            }
          });
          
          socket.emit('portfolioUnsubscribed', { portfolioIds });
          logger.info(`Socket ${socket.id} unsubscribed from portfolios: ${portfolioIds.join(', ')}`);
        }
      } catch (error) {
        logger.error(`Socket portfolio unsubscription error: ${error.message}`);
        socket.emit('error', { message: 'Portfolio unsubscription failed: Server error' });
      }
    });
    
    // Handle subscribing to alerts
    socket.on('subscribeAlerts', () => {
      try {
        const userInfo = connectedUsers.get(socket.id);
        
        if (!userInfo) {
          socket.emit('error', { message: 'Not authenticated' });
          return;
        }
        
        const room = `alerts_${userInfo.userId}`;
        socket.join(room);
        userInfo.rooms.push(room);
        
        socket.emit('alertsSubscribed');
        logger.info(`Socket ${socket.id} subscribed to alerts for user ${userInfo.userId}`);
      } catch (error) {
        logger.error(`Socket alerts subscription error: ${error.message}`);
        socket.emit('error', { message: 'Alerts subscription failed: Server error' });
      }
    });
    
    // Handle unsubscribing from alerts
    socket.on('unsubscribeAlerts', () => {
      try {
        const userInfo = connectedUsers.get(socket.id);
        
        if (!userInfo) {
          socket.emit('error', { message: 'Not authenticated' });
          return;
        }
        
        const room = `alerts_${userInfo.userId}`;
        socket.leave(room);
        
        // Remove from user's rooms
        const index = userInfo.rooms.indexOf(room);
        if (index !== -1) {
          userInfo.rooms.splice(index, 1);
        }
        
        socket.emit('alertsUnsubscribed');
        logger.info(`Socket ${socket.id} unsubscribed from alerts for user ${userInfo.userId}`);
      } catch (error) {
        logger.error(`Socket alerts unsubscription error: ${error.message}`);
        socket.emit('error', { message: 'Alerts unsubscription failed: Server error' });
      }
    });
    
    // Handle disconnection
    socket.on('disconnect', () => {
      const userInfo = connectedUsers.get(socket.id);
      
      if (userInfo) {
        logger.info(`Socket disconnected: ${socket.id} for user ${userInfo.userId}`);
        connectedUsers.delete(socket.id);
      } else {
        logger.info(`Socket disconnected: ${socket.id}`);
      }
    });
  });
  
  // Helper function to emit price updates
  const emitPriceUpdate = (symbol, data) => {
    io.to(`market_${symbol.toUpperCase()}`).emit('priceUpdate', {
      symbol,
      ...data,
    });
  };
  
  // Helper function to emit portfolio updates
  const emitPortfolioUpdate = (portfolioId, data) => {
    io.to(`portfolio_${portfolioId}`).emit('portfolioUpdate', {
      portfolioId,
      ...data,
    });
  };
  
  // Helper function to emit alert notifications
  const emitAlert = (userId, alert) => {
    io.to(`alerts_${userId}`).emit('alert', alert);
    io.to(`user_${userId}`).emit('notification', {
      type: 'alert',
      message: alert.message || `Alert triggered for ${alert.symbol || 'your portfolio'}`,
      data: alert,
    });
  };
  
  // Helper function to emit news notifications
  const emitNewsNotification = (symbols, news) => {
    symbols.forEach((symbol) => {
      io.to(`market_${symbol.toUpperCase()}`).emit('newsUpdate', {
        symbol,
        news,
      });
    });
  };
  
  // Helper function to emit system notifications
  const emitSystemNotification = (userId, notification) => {
    io.to(`user_${userId}`).emit('notification', {
      type: 'system',
      ...notification,
    });
  };
  
  // Return public methods
  return {
    emitPriceUpdate,
    emitPortfolioUpdate,
    emitAlert,
    emitNewsNotification,
    emitSystemNotification,
    getConnectedUsers: () => connectedUsers.size,
  };
}; 