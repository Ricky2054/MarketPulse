import twilio from 'twilio';
import env from '../config/env.js';
import { logger } from './logger.js';

/**
 * SMS service for sending text messages
 * @class SmsService
 */
class SmsService {
  constructor() {
    this.client = null;
    this.initializeClient();
  }

  /**
   * Initialize the Twilio client
   */
  initializeClient() {
    try {
      if (env.TWILIO_ACCOUNT_SID && env.TWILIO_AUTH_TOKEN) {
        this.client = twilio(env.TWILIO_ACCOUNT_SID, env.TWILIO_AUTH_TOKEN);
        logger.info('SMS service initialized');
      } else {
        logger.warn('SMS service not configured properly');
      }
    } catch (error) {
      logger.error(`SMS service initialization error: ${error.message}`);
    }
  }

  /**
   * Send an SMS
   * @param {Object} options - SMS options
   * @param {string} options.to - Recipient phone number
   * @param {string} options.body - Message body
   * @returns {Promise<Object>} Twilio message object
   */
  async sendSms(options) {
    try {
      if (!this.client) {
        throw new Error('SMS client not initialized');
      }

      const message = await this.client.messages.create({
        body: options.body,
        from: env.TWILIO_PHONE_NUMBER,
        to: options.to,
      });

      logger.info(`SMS sent: ${message.sid}`);
      return message;
    } catch (error) {
      logger.error(`Error sending SMS: ${error.message}`);
      throw error;
    }
  }

  /**
   * Send a verification code
   * @param {Object} options - Options
   * @param {string} options.phone - User phone number
   * @param {string} options.code - Verification code
   * @returns {Promise<Object>} Twilio message object
   */
  async sendVerificationCode(options) {
    const body = `Your Finance App verification code is: ${options.code}. This code will expire in 10 minutes.`;
    return this.sendSms({
      to: options.phone,
      body,
    });
  }

  /**
   * Send an alert notification
   * @param {Object} options - Options
   * @param {string} options.phone - User phone number
   * @param {Object} options.alert - Alert object
   * @returns {Promise<Object>} Twilio message object
   */
  async sendAlertSms(options) {
    const { alert } = options;
    const body = `FINANCE ALERT: ${alert.message || `${alert.condition.toUpperCase()} ${alert.threshold} for ${alert.symbol || 'your portfolio'}`}. Time: ${new Date().toLocaleString()}`;
    
    return this.sendSms({
      to: options.phone,
      body,
    });
  }

  /**
   * Send a welcome message
   * @param {Object} options - Options
   * @param {string} options.phone - User phone number
   * @param {string} options.name - User name
   * @returns {Promise<Object>} Twilio message object
   */
  async sendWelcomeSms(options) {
    const body = `Welcome to Finance App, ${options.name}! Thank you for joining us. Reply STOP to unsubscribe from SMS notifications.`;
    
    return this.sendSms({
      to: options.phone,
      body,
    });
  }
}

// Create and export a singleton instance
const smsService = new SmsService();
export default smsService; 