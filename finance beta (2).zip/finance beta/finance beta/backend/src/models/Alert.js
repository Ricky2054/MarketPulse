import mongoose from 'mongoose';

const AlertSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    type: {
      type: String,
      enum: [
        'price_alert',
        'portfolio_change',
        'news',
        'transaction_status',
        'security',
        'system',
        'tokenization_event',
        'market_event',
        'custom',
      ],
      required: true,
      index: true,
    },
    title: {
      type: String,
      required: true,
    },
    message: {
      type: String,
      required: true,
    },
    priority: {
      type: String,
      enum: ['low', 'medium', 'high', 'critical'],
      default: 'medium',
      index: true,
    },
    status: {
      type: String,
      enum: ['unread', 'read', 'archived'],
      default: 'unread',
      index: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
      index: true,
    },
    expiresAt: {
      type: Date,
      index: true,
    },
    readAt: Date,
    archivedAt: Date,
    relatedAsset: {
      assetId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Asset',
        index: true,
      },
      symbol: String,
      name: String,
      price: Number,
      priceChange: Number,
    },
    relatedTokenizedAsset: {
      tokenizedAssetId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'TokenizedAsset',
        index: true,
      },
      symbol: String,
      name: String,
      price: Number,
      priceChange: Number,
    },
    relatedTransaction: {
      transactionId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Transaction',
        index: true,
      },
      type: String,
      status: String,
      amount: Number,
    },
    relatedPortfolio: {
      portfolioId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Portfolio',
        index: true,
      },
      name: String,
      value: Number,
      change: Number,
      changePercentage: Number,
    },
    actionUrl: String,
    actionText: String,
    metadata: {
      type: mongoose.Schema.Types.Mixed,
    },
    notificationSent: {
      email: {
        sent: {
          type: Boolean,
          default: false,
        },
        sentAt: Date,
      },
      push: {
        sent: {
          type: Boolean,
          default: false,
        },
        sentAt: Date,
      },
      sms: {
        sent: {
          type: Boolean,
          default: false,
        },
        sentAt: Date,
      },
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Compound indexes for faster queries
AlertSchema.index({ userId: 1, status: 1, createdAt: -1 });
AlertSchema.index({ userId: 1, type: 1, createdAt: -1 });
AlertSchema.index({ userId: 1, priority: 1, status: 1 });

// Virtual for age of alert
AlertSchema.virtual('age').get(function () {
  return Math.floor((Date.now() - this.createdAt) / (1000 * 60 * 60 * 24)); // in days
});

// Virtual for isExpired
AlertSchema.virtual('isExpired').get(function () {
  if (!this.expiresAt) return false;
  return this.expiresAt < new Date();
});

// Method to mark alert as read
AlertSchema.methods.markAsRead = async function () {
  if (this.status === 'unread') {
    this.status = 'read';
    this.readAt = new Date();
    return this.save();
  }
  return this;
};

// Method to archive alert
AlertSchema.methods.archive = async function () {
  if (this.status !== 'archived') {
    this.status = 'archived';
    this.archivedAt = new Date();
    return this.save();
  }
  return this;
};

// Static method to find user alerts with pagination
AlertSchema.statics.findUserAlerts = async function (
  userId,
  filters = {},
  page = 1,
  limit = 20,
  sort = { createdAt: -1 }
) {
  const query = { userId, ...filters };
  
  // Don't show expired alerts unless specifically requested
  if (!filters.showExpired && !filters.isExpired) {
    query.$or = [
      { expiresAt: { $exists: false } },
      { expiresAt: null },
      { expiresAt: { $gt: new Date() } },
    ];
  }
  
  const total = await this.countDocuments(query);
  const alerts = await this.find(query)
    .sort(sort)
    .skip((page - 1) * limit)
    .limit(limit);
  
  return {
    alerts,
    pagination: {
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    },
  };
};

// Static method to get alert statistics
AlertSchema.statics.getAlertStats = async function (userId) {
  const stats = await this.aggregate([
    {
      $match: {
        userId: mongoose.Types.ObjectId(userId),
        $or: [
          { expiresAt: { $exists: false } },
          { expiresAt: null },
          { expiresAt: { $gt: new Date() } },
        ],
      },
    },
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 },
      },
    },
  ]);
  
  // Format the results
  const formattedStats = {
    unread: 0,
    read: 0,
    archived: 0,
    total: 0,
  };
  
  stats.forEach((stat) => {
    formattedStats[stat._id] = stat.count;
    formattedStats.total += stat.count;
  });
  
  // Get priority counts for unread alerts
  const priorityStats = await this.aggregate([
    {
      $match: {
        userId: mongoose.Types.ObjectId(userId),
        status: 'unread',
        $or: [
          { expiresAt: { $exists: false } },
          { expiresAt: null },
          { expiresAt: { $gt: new Date() } },
        ],
      },
    },
    {
      $group: {
        _id: '$priority',
        count: { $sum: 1 },
      },
    },
  ]);
  
  formattedStats.byPriority = {
    low: 0,
    medium: 0,
    high: 0,
    critical: 0,
  };
  
  priorityStats.forEach((stat) => {
    formattedStats.byPriority[stat._id] = stat.count;
  });
  
  return formattedStats;
};

// Static method to create a price alert
AlertSchema.statics.createPriceAlert = async function (
  userId,
  asset,
  price,
  priceChange,
  condition,
  message
) {
  return this.create({
    userId,
    type: 'price_alert',
    title: `Price Alert: ${asset.symbol} ${condition === 'above' ? 'above' : 'below'} ${price}`,
    message: message || `${asset.name} (${asset.symbol}) is now ${condition === 'above' ? 'above' : 'below'} ${price}`,
    priority: 'medium',
    relatedAsset: {
      assetId: asset._id,
      symbol: asset.symbol,
      name: asset.name,
      price: asset.price,
      priceChange: priceChange,
    },
    actionUrl: `/assets/${asset.symbol.toLowerCase()}`,
    actionText: 'View Asset',
  });
};

// Static method to create a portfolio change alert
AlertSchema.statics.createPortfolioAlert = async function (
  userId,
  portfolio,
  changePercentage,
  message
) {
  const priority = 
    Math.abs(changePercentage) >= 10 ? 'high' :
    Math.abs(changePercentage) >= 5 ? 'medium' : 'low';
  
  return this.create({
    userId,
    type: 'portfolio_change',
    title: `Portfolio ${changePercentage >= 0 ? 'Gain' : 'Loss'}: ${Math.abs(changePercentage).toFixed(2)}%`,
    message: message || `Your portfolio "${portfolio.name}" has ${changePercentage >= 0 ? 'gained' : 'lost'} ${Math.abs(changePercentage).toFixed(2)}% in value.`,
    priority,
    relatedPortfolio: {
      portfolioId: portfolio._id,
      name: portfolio.name,
      value: portfolio.totalValue,
      change: portfolio.totalProfitLoss,
      changePercentage: changePercentage,
    },
    actionUrl: '/portfolio',
    actionText: 'View Portfolio',
  });
};

// Static method to mark all alerts as read
AlertSchema.statics.markAllAsRead = async function (userId) {
  const result = await this.updateMany(
    { userId, status: 'unread' },
    { status: 'read', readAt: new Date() }
  );
  
  return result.nModified;
};

const Alert = mongoose.model('Alert', AlertSchema);

export default Alert;