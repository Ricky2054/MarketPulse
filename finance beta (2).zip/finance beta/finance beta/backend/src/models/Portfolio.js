import mongoose from 'mongoose';

const PositionSchema = new mongoose.Schema(
  {
    assetId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Asset',
      required: true,
    },
    quantity: {
      type: Number,
      required: true,
      min: [0, 'Quantity cannot be negative'],
    },
    averagePrice: {
      type: Number,
      required: true,
      min: [0, 'Average price cannot be negative'],
    },
    initialInvestment: {
      type: Number,
      required: true,
      min: [0, 'Initial investment cannot be negative'],
    },
    dateAcquired: {
      type: Date,
      default: Date.now,
    },
    notes: {
      type: String,
    },
    tags: [String],
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtual for current value
PositionSchema.virtual('currentValue').get(function () {
  if (this.asset && this.asset.price) {
    return this.quantity * this.asset.price;
  }
  return 0;
});

// Virtual for profit/loss
PositionSchema.virtual('profitLoss').get(function () {
  if (this.asset && this.asset.price) {
    return this.quantity * this.asset.price - this.initialInvestment;
  }
  return 0;
});

// Virtual for profit/loss percentage
PositionSchema.virtual('profitLossPercentage').get(function () {
  if (this.initialInvestment > 0 && this.asset && this.asset.price) {
    return ((this.quantity * this.asset.price - this.initialInvestment) / this.initialInvestment) * 100;
  }
  return 0;
});

const PortfolioSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      unique: true,
    },
    name: {
      type: String,
      default: 'Default Portfolio',
    },
    description: {
      type: String,
    },
    positions: [PositionSchema],
    watchlist: [
      {
        assetId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Asset',
        },
        addedAt: {
          type: Date,
          default: Date.now,
        },
        notes: String,
        priceAlert: {
          enabled: {
            type: Boolean,
            default: false,
          },
          condition: {
            type: String,
            enum: ['above', 'below'],
          },
          price: Number,
        },
      },
    ],
    settings: {
      defaultCurrency: {
        type: String,
        default: 'USD',
      },
      riskLevel: {
        type: String,
        enum: ['conservative', 'moderate', 'aggressive'],
        default: 'moderate',
      },
      autoRebalance: {
        enabled: {
          type: Boolean,
          default: false,
        },
        frequency: {
          type: String,
          enum: ['daily', 'weekly', 'monthly', 'quarterly'],
          default: 'monthly',
        },
        lastRebalanced: Date,
      },
    },
    performance: {
      daily: [
        {
          date: Date,
          value: Number,
          change: Number,
          changePercentage: Number,
        },
      ],
      weekly: [
        {
          date: Date,
          value: Number,
          change: Number,
          changePercentage: Number,
        },
      ],
      monthly: [
        {
          date: Date,
          value: Number,
          change: Number,
          changePercentage: Number,
        },
      ],
      yearly: [
        {
          date: Date,
          value: Number,
          change: Number,
          changePercentage: Number,
        },
      ],
    },
    // AI-generated insights
    aiInsights: {
      diversificationScore: {
        type: Number,
        min: 0,
        max: 100,
      },
      riskAssessment: {
        type: String,
        enum: ['very_low', 'low', 'medium', 'high', 'very_high'],
      },
      recommendations: [
        {
          type: {
            type: String,
            enum: ['buy', 'sell', 'hold', 'rebalance', 'diversify'],
          },
          assetId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Asset',
          },
          reason: String,
          confidence: {
            type: Number,
            min: 0,
            max: 100,
          },
          createdAt: {
            type: Date,
            default: Date.now,
          },
        },
      ],
      lastUpdated: Date,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtual for total value
PortfolioSchema.virtual('totalValue').get(function () {
  return this.positions.reduce((total, position) => {
    return total + (position.currentValue || 0);
  }, 0);
});

// Virtual for total profit/loss
PortfolioSchema.virtual('totalProfitLoss').get(function () {
  return this.positions.reduce((total, position) => {
    return total + (position.profitLoss || 0);
  }, 0);
});

// Virtual for total profit/loss percentage
PortfolioSchema.virtual('totalProfitLossPercentage').get(function () {
  const totalInvestment = this.positions.reduce((total, position) => {
    return total + (position.initialInvestment || 0);
  }, 0);
  
  if (totalInvestment > 0) {
    return (this.totalProfitLoss / totalInvestment) * 100;
  }
  
  return 0;
});

// Method to add a position
PortfolioSchema.methods.addPosition = async function (assetId, quantity, price) {
  // Check if position already exists
  const existingPosition = this.positions.find(
    (position) => position.assetId.toString() === assetId.toString()
  );
  
  if (existingPosition) {
    // Update existing position
    const totalQuantity = existingPosition.quantity + quantity;
    const totalInvestment = existingPosition.initialInvestment + quantity * price;
    
    existingPosition.quantity = totalQuantity;
    existingPosition.averagePrice = totalInvestment / totalQuantity;
    existingPosition.initialInvestment = totalInvestment;
  } else {
    // Create new position
    this.positions.push({
      assetId,
      quantity,
      averagePrice: price,
      initialInvestment: quantity * price,
    });
  }
  
  return this.save();
};

// Method to remove or reduce a position
PortfolioSchema.methods.reducePosition = async function (assetId, quantity, price) {
  const existingPosition = this.positions.find(
    (position) => position.assetId.toString() === assetId.toString()
  );
  
  if (!existingPosition) {
    throw new Error('Position not found');
  }
  
  if (quantity > existingPosition.quantity) {
    throw new Error('Cannot sell more than owned quantity');
  }
  
  if (quantity === existingPosition.quantity) {
    // Remove the entire position
    this.positions = this.positions.filter(
      (position) => position.assetId.toString() !== assetId.toString()
    );
  } else {
    // Reduce the position
    const remainingQuantity = existingPosition.quantity - quantity;
    const remainingInvestment = (existingPosition.initialInvestment / existingPosition.quantity) * remainingQuantity;
    
    existingPosition.quantity = remainingQuantity;
    existingPosition.initialInvestment = remainingInvestment;
    // Average price remains the same
  }
  
  return this.save();
};

// Method to update portfolio performance
PortfolioSchema.methods.updatePerformance = async function () {
  const currentValue = this.totalValue;
  const currentDate = new Date();
  
  // Update daily performance
  if (this.performance.daily.length === 0 || 
      this.performance.daily[this.performance.daily.length - 1].date.toDateString() !== currentDate.toDateString()) {
    
    const previousValue = this.performance.daily.length > 0 
      ? this.performance.daily[this.performance.daily.length - 1].value 
      : currentValue;
    
    const change = currentValue - previousValue;
    const changePercentage = previousValue > 0 ? (change / previousValue) * 100 : 0;
    
    this.performance.daily.push({
      date: currentDate,
      value: currentValue,
      change,
      changePercentage,
    });
    
    // Limit to last 30 days
    if (this.performance.daily.length > 30) {
      this.performance.daily.shift();
    }
  }
  
  // Update weekly performance (if it's a new week)
  const startOfWeek = new Date(currentDate);
  startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
  
  if (this.performance.weekly.length === 0 || 
      this.performance.weekly[this.performance.weekly.length - 1].date < startOfWeek) {
    
    const previousValue = this.performance.weekly.length > 0 
      ? this.performance.weekly[this.performance.weekly.length - 1].value 
      : currentValue;
    
    const change = currentValue - previousValue;
    const changePercentage = previousValue > 0 ? (change / previousValue) * 100 : 0;
    
    this.performance.weekly.push({
      date: currentDate,
      value: currentValue,
      change,
      changePercentage,
    });
    
    // Limit to last 52 weeks
    if (this.performance.weekly.length > 52) {
      this.performance.weekly.shift();
    }
  }
  
  // Similar logic for monthly and yearly performance...
  
  return this.save();
};

const Portfolio = mongoose.model('Portfolio', PortfolioSchema);

export default Portfolio; 