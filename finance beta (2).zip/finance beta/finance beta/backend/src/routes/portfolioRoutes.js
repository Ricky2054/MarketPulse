import express from 'express';
import {
  getPortfolios,
  getPortfolio,
  createPortfolio,
  updatePortfolio,
  deletePortfolio,
  addAsset,
  updateAsset,
  removeAsset,
  getPortfolioPerformance,
} from '../controllers/portfolioController.js';
import { authenticate } from '../middleware/auth.js';
import { validate, schemas } from '../utils/validator.js';

const router = express.Router();

// All routes require authentication
router.use(authenticate);

// Portfolio routes
router.get('/', getPortfolios);
router.get('/:id', getPortfolio);
router.post('/', validate(schemas.portfolioCreate), createPortfolio);
router.put('/:id', validate(schemas.portfolioUpdate), updatePortfolio);
router.delete('/:id', deletePortfolio);

// Portfolio asset routes
router.post('/:id/assets', validate(schemas.portfolioAddAsset), addAsset);
router.put('/:id/assets/:symbol', validate(schemas.portfolioUpdateAsset), updateAsset);
router.delete('/:id/assets/:symbol', removeAsset);

// Portfolio performance route
router.get('/:id/performance', getPortfolioPerformance);

export default router; 