import Asset from '../models/Asset.js';
import MarketData from '../models/MarketData.js';
import News from '../models/News.js';
import AppError from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { io } from '../index.js';

// @desc    Get all assets with pagination and filtering
// @route   GET /api/v1/assets
// @access  Public
export const getAssets = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 20;
    const sort = req.query.sort || '-marketCap';
    
    // Build filter object
    const filter = {};
    
    if (req.query.type) {
      filter.type = req.query.type;
    }
    
    if (req.query.search) {
      filter.$or = [
        { name: { $regex: req.query.search, $options: 'i' } },
        { symbol: { $regex: req.query.search, $options: 'i' } },
      ];
    }
    
    if (req.query.minPrice) {
      filter.price = { $gte: parseFloat(req.query.minPrice) };
    }
    
    if (req.query.maxPrice) {
      if (filter.price) {
        filter.price.$lte = parseFloat(req.query.maxPrice);
      } else {
        filter.price = { $lte: parseFloat(req.query.maxPrice) };
      }
    }
    
    if (req.query.verified === 'true') {
      filter.verified = true;
    }
    
    // Only show active assets by default
    if (!req.query.includeInactive) {
      filter.active = true;
    }
    
    // Execute query
    const assets = await Asset.find(filter)
      .sort(sort)
      .skip((page - 1) * limit)
      .limit(limit);
    
    // Get total count
    const total = await Asset.countDocuments(filter);
    
    res.status(200).json({
      success: true,
      count: assets.length,
      pagination: {
        total,
        page,
        pages: Math.ceil(total / limit),
        limit,
      },
      data: assets,
    });
  } catch (error) {
    logger.error(`Error getting assets: ${error.message}`);
    next(error);
  }
};

// @desc    Get single asset
// @route   GET /api/v1/assets/:id
// @access  Public
export const getAsset = async (req, res, next) => {
  try {
    let asset;
    
    // Check if the parameter is a valid ObjectId or a symbol
    if (req.params.id.match(/^[0-9a-fA-F]{24}$/)) {
      // It's a valid ObjectId, so find by ID
      asset = await Asset.findById(req.params.id);
    } else {
      // It's not a valid ObjectId, so find by symbol
      asset = await Asset.findOne({ symbol: req.params.id.toUpperCase() });
    }
    
    if (!asset) {
      return next(new AppError(`Asset not found with id of ${req.params.id}`, 404));
    }
    
    res.status(200).json({
      success: true,
      data: asset,
    });
  } catch (error) {
    logger.error(`Error getting asset: ${error.message}`);
    next(error);
  }
};

// @desc    Create new asset
// @route   POST /api/v1/assets
// @access  Private (Admin)
export const createAsset = async (req, res, next) => {
  try {
    // Check if asset with the same symbol already exists
    const existingAsset = await Asset.findOne({ symbol: req.body.symbol });
    if (existingAsset) {
      return next(new AppError(`Asset with symbol ${req.body.symbol} already exists`, 400));
    }
    
    // Create asset
    const asset = await Asset.create(req.body);
    
    // Log asset creation
    logger.info(`Asset created: ${asset.symbol} by user ${req.user.id}`);
    
    res.status(201).json({
      success: true,
      data: asset,
    });
  } catch (error) {
    logger.error(`Error creating asset: ${error.message}`);
    next(error);
  }
};

// @desc    Update asset
// @route   PUT /api/v1/assets/:id
// @access  Private (Admin)
export const updateAsset = async (req, res, next) => {
  try {
    let asset = await Asset.findById(req.params.id);
    
    if (!asset) {
      return next(new AppError(`Asset not found with id of ${req.params.id}`, 404));
    }
    
    // Check if trying to update symbol and if it already exists
    if (req.body.symbol && req.body.symbol !== asset.symbol) {
      const existingAsset = await Asset.findOne({ symbol: req.body.symbol });
      if (existingAsset) {
        return next(new AppError(`Asset with symbol ${req.body.symbol} already exists`, 400));
      }
    }
    
    // Update asset
    asset = await Asset.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    
    // Log asset update
    logger.info(`Asset updated: ${asset.symbol} by user ${req.user.id}`);
    
    res.status(200).json({
      success: true,
      data: asset,
    });
  } catch (error) {
    logger.error(`Error updating asset: ${error.message}`);
    next(error);
  }
};

// @desc    Delete asset
// @route   DELETE /api/v1/assets/:id
// @access  Private (Admin)
export const deleteAsset = async (req, res, next) => {
  try {
    const asset = await Asset.findById(req.params.id);
    
    if (!asset) {
      return next(new AppError(`Asset not found with id of ${req.params.id}`, 404));
    }
    
    // Instead of deleting, mark as inactive
    asset.active = false;
    await asset.save();
    
    // Log asset deletion
    logger.info(`Asset marked as inactive: ${asset.symbol} by user ${req.user.id}`);
    
    res.status(200).json({
      success: true,
      data: {},
    });
  } catch (error) {
    logger.error(`Error deleting asset: ${error.message}`);
    next(error);
  }
};

// @desc    Update asset price
// @route   PUT /api/v1/assets/:id/price
// @access  Private (Admin/System)
export const updateAssetPrice = async (req, res, next) => {
  try {
    const { price, volume } = req.body;
    
    if (!price) {
      return next(new AppError('Please provide a price', 400));
    }
    
    let asset = await Asset.findById(req.params.id);
    
    if (!asset) {
      return next(new AppError(`Asset not found with id of ${req.params.id}`, 404));
    }
    
    // Update price
    await asset.updatePrice(price, volume);
    
    // Emit price update event
    io.emit('priceUpdate', {
      symbol: asset.symbol,
      price: asset.price,
      priceChange24h: asset.priceChange24h,
      priceChangePercent24h: asset.priceChangePercent24h,
      updatedAt: new Date(),
    });
    
    res.status(200).json({
      success: true,
      data: asset,
    });
  } catch (error) {
    logger.error(`Error updating asset price: ${error.message}`);
    next(error);
  }
};

// @desc    Get asset price history
// @route   GET /api/v1/assets/:id/history
// @access  Public
export const getAssetPriceHistory = async (req, res, next) => {
  try {
    const asset = await Asset.findById(req.params.id);
    
    if (!asset) {
      return next(new AppError(`Asset not found with id of ${req.params.id}`, 404));
    }
    
    const interval = req.query.interval || '1d';
    const limit = parseInt(req.query.limit, 10) || 30;
    const startTime = req.query.startTime;
    const endTime = req.query.endTime;
    
    // Get OHLCV data from MarketData
    const priceHistory = await MarketData.getOHLCV(
      asset.symbol,
      interval,
      limit,
      startTime,
      endTime
    );
    
    res.status(200).json({
      success: true,
      count: priceHistory.length,
      data: priceHistory,
    });
  } catch (error) {
    logger.error(`Error getting asset price history: ${error.message}`);
    next(error);
  }
};

// @desc    Get asset news
// @route   GET /api/v1/assets/:id/news
// @access  Public
export const getAssetNews = async (req, res, next) => {
  try {
    const asset = await Asset.findById(req.params.id);
    
    if (!asset) {
      return next(new AppError(`Asset not found with id of ${req.params.id}`, 404));
    }
    
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    
    // Get news related to this asset
    const result = await News.findAssetNews(asset.symbol, page, limit);
    
    res.status(200).json({
      success: true,
      count: result.news.length,
      pagination: result.pagination,
      data: result.news,
    });
  } catch (error) {
    logger.error(`Error getting asset news: ${error.message}`);
    next(error);
  }
};

// @desc    Get asset technical indicators
// @route   GET /api/v1/assets/:id/indicators
// @access  Public
export const getAssetIndicators = async (req, res, next) => {
  try {
    const asset = await Asset.findById(req.params.id);
    
    if (!asset) {
      return next(new AppError(`Asset not found with id of ${req.params.id}`, 404));
    }
    
    // Parse requested indicators
    const indicators = req.query.indicators
      ? req.query.indicators.split(',')
      : [];
    
    // Get technical indicators from MarketData
    const technicalIndicators = await MarketData.getTechnicalIndicators(
      asset.symbol,
      indicators
    );
    
    res.status(200).json({
      success: true,
      data: technicalIndicators,
    });
  } catch (error) {
    logger.error(`Error getting asset indicators: ${error.message}`);
    next(error);
  }
};

// @desc    Get asset AI insights
// @route   GET /api/v1/assets/:id/insights
// @access  Public
export const getAssetInsights = async (req, res, next) => {
  try {
    const asset = await Asset.findById(req.params.id);
    
    if (!asset) {
      return next(new AppError(`Asset not found with id of ${req.params.id}`, 404));
    }
    
    // Get AI insights from MarketData
    const insights = await MarketData.getAIInsights(asset.symbol);
    
    // Get news sentiment
    const sentiment = await News.getAssetSentiment(asset.symbol, 7);
    
    res.status(200).json({
      success: true,
      data: {
        insights: insights?.aiInsights || null,
        sentiment,
      },
    });
  } catch (error) {
    logger.error(`Error getting asset insights: ${error.message}`);
    next(error);
  }
};

// @desc    Get market summary
// @route   GET /api/v1/assets/market/summary
// @access  Public
export const getMarketSummary = async (req, res, next) => {
  try {
    // Get top assets by market cap
    const topAssets = await Asset.find({ active: true })
      .sort('-marketCap')
      .limit(10);
    
    // Get trending assets (highest 24h percent change)
    const trendingAssets = await Asset.find({ active: true })
      .sort('-priceChangePercent24h')
      .limit(5);
    
    // Get market stats
    const totalMarketCap = await Asset.aggregate([
      { $match: { active: true } },
      { $group: { _id: null, total: { $sum: '$marketCap' } } },
    ]);
    
    const totalVolume24h = await Asset.aggregate([
      { $match: { active: true } },
      { $group: { _id: null, total: { $sum: '$volume24h' } } },
    ]);
    
    const marketCapByType = await Asset.aggregate([
      { $match: { active: true } },
      { $group: { _id: '$type', marketCap: { $sum: '$marketCap' } } },
      { $sort: { marketCap: -1 } },
    ]);
    
    res.status(200).json({
      success: true,
      data: {
        topAssets,
        trendingAssets,
        marketStats: {
          totalMarketCap: totalMarketCap[0]?.total || 0,
          totalVolume24h: totalVolume24h[0]?.total || 0,
          marketCapByType,
          assetCount: await Asset.countDocuments({ active: true }),
        },
      },
    });
  } catch (error) {
    logger.error(`Error getting market summary: ${error.message}`);
    next(error);
  }
}; 