import Portfolio from '../models/Portfolio.js';
import Transaction from '../models/Transaction.js';
import Asset from '../models/Asset.js';
import TokenizedAsset from '../models/TokenizedAsset.js';
import Alert from '../models/Alert.js';
import AppError from '../utils/appError.js';
import { logger } from '../utils/logger.js';

// @desc    Get all portfolios for a user
// @route   GET /api/v1/portfolios
// @access  Private
export const getPortfolios = async (req, res, next) => {
  try {
    const portfolios = await Portfolio.find({ user: req.user.id });

    res.status(200).json({
      success: true,
      count: portfolios.length,
      data: portfolios,
    });
  } catch (error) {
    logger.error(`Error getting portfolios: ${error.message}`);
    next(error);
  }
};

// @desc    Get single portfolio
// @route   GET /api/v1/portfolios/:id
// @access  Private
export const getPortfolio = async (req, res, next) => {
  try {
    const portfolio = await Portfolio.findById(req.params.id);

    if (!portfolio) {
      return next(new AppError(`Portfolio not found with id of ${req.params.id}`, 404));
    }

    // Check if portfolio belongs to user
    if (portfolio.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new AppError('Not authorized to access this portfolio', 401));
    }

    res.status(200).json({
      success: true,
      data: portfolio,
    });
  } catch (error) {
    logger.error(`Error getting portfolio: ${error.message}`);
    next(error);
  }
};

// @desc    Create new portfolio
// @route   POST /api/v1/portfolios
// @access  Private
export const createPortfolio = async (req, res, next) => {
  try {
    // Add user to request body
    req.body.user = req.user.id;

    const portfolio = await Portfolio.create(req.body);

    logger.info(`Portfolio created: ${portfolio._id} by user ${req.user.id}`);

    res.status(201).json({
      success: true,
      data: portfolio,
    });
  } catch (error) {
    logger.error(`Error creating portfolio: ${error.message}`);
    next(error);
  }
};

// @desc    Update portfolio
// @route   PUT /api/v1/portfolios/:id
// @access  Private
export const updatePortfolio = async (req, res, next) => {
  try {
    let portfolio = await Portfolio.findById(req.params.id);

    if (!portfolio) {
      return next(new AppError(`Portfolio not found with id of ${req.params.id}`, 404));
    }

    // Check if portfolio belongs to user
    if (portfolio.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new AppError('Not authorized to update this portfolio', 401));
    }

    portfolio = await Portfolio.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    logger.info(`Portfolio updated: ${portfolio._id}`);

    res.status(200).json({
      success: true,
      data: portfolio,
    });
  } catch (error) {
    logger.error(`Error updating portfolio: ${error.message}`);
    next(error);
  }
};

// @desc    Delete portfolio
// @route   DELETE /api/v1/portfolios/:id
// @access  Private
export const deletePortfolio = async (req, res, next) => {
  try {
    const portfolio = await Portfolio.findById(req.params.id);

    if (!portfolio) {
      return next(new AppError(`Portfolio not found with id of ${req.params.id}`, 404));
    }

    // Check if portfolio belongs to user
    if (portfolio.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new AppError('Not authorized to delete this portfolio', 401));
    }

    await portfolio.deleteOne();

    logger.info(`Portfolio deleted: ${req.params.id}`);

    res.status(200).json({
      success: true,
      data: {},
    });
  } catch (error) {
    logger.error(`Error deleting portfolio: ${error.message}`);
    next(error);
  }
};

// @desc    Add asset to portfolio
// @route   POST /api/v1/portfolios/:id/assets
// @access  Private
export const addAsset = async (req, res, next) => {
  try {
    const { symbol, quantity, purchasePrice, type } = req.body;

    // Find portfolio
    const portfolio = await Portfolio.findById(req.params.id);

    if (!portfolio) {
      return next(new AppError(`Portfolio not found with id of ${req.params.id}`, 404));
    }

    // Check if portfolio belongs to user
    if (portfolio.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new AppError('Not authorized to update this portfolio', 401));
    }

    // Check if asset exists
    let asset;
    if (type === 'tokenized') {
      asset = await TokenizedAsset.findOne({ symbol });
    } else {
      asset = await Asset.findOne({ symbol });
    }

    if (!asset) {
      return next(new AppError(`Asset not found with symbol ${symbol}`, 404));
    }

    // Check if asset already exists in portfolio
    const assetIndex = portfolio.assets.findIndex(
      (a) => a.symbol === symbol && a.type === type
    );

    if (assetIndex > -1) {
      // Update existing asset
      const existingAsset = portfolio.assets[assetIndex];
      const totalValue = existingAsset.quantity * existingAsset.averagePrice + quantity * purchasePrice;
      const totalQuantity = existingAsset.quantity + quantity;
      
      portfolio.assets[assetIndex].quantity = totalQuantity;
      portfolio.assets[assetIndex].averagePrice = totalValue / totalQuantity;
      portfolio.assets[assetIndex].currentValue = totalQuantity * asset.price;
    } else {
      // Add new asset
      portfolio.assets.push({
        symbol,
        name: asset.name,
        type,
        quantity,
        averagePrice: purchasePrice,
        currentPrice: asset.price,
        currentValue: quantity * asset.price,
      });
    }

    // Create transaction
    await Transaction.create({
      user: req.user.id,
      portfolio: portfolio._id,
      asset: asset._id,
      symbol,
      type: 'buy',
      quantity,
      price: purchasePrice,
      total: quantity * purchasePrice,
      status: 'completed',
    });

    // Save portfolio
    await portfolio.save();

    logger.info(`Asset ${symbol} added to portfolio ${portfolio._id}`);

    res.status(200).json({
      success: true,
      data: portfolio,
    });
  } catch (error) {
    logger.error(`Error adding asset to portfolio: ${error.message}`);
    next(error);
  }
};

// @desc    Update asset in portfolio
// @route   PUT /api/v1/portfolios/:id/assets/:symbol
// @access  Private
export const updateAsset = async (req, res, next) => {
  try {
    const { quantity } = req.body;
    const { symbol } = req.params;

    // Find portfolio
    const portfolio = await Portfolio.findById(req.params.id);

    if (!portfolio) {
      return next(new AppError(`Portfolio not found with id of ${req.params.id}`, 404));
    }

    // Check if portfolio belongs to user
    if (portfolio.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new AppError('Not authorized to update this portfolio', 401));
    }

    // Find asset in portfolio
    const assetIndex = portfolio.assets.findIndex((a) => a.symbol === symbol);

    if (assetIndex === -1) {
      return next(new AppError(`Asset not found in portfolio with symbol ${symbol}`, 404));
    }

    // Update asset quantity
    portfolio.assets[assetIndex].quantity = quantity;
    portfolio.assets[assetIndex].currentValue = quantity * portfolio.assets[assetIndex].currentPrice;

    // Save portfolio
    await portfolio.save();

    logger.info(`Asset ${symbol} updated in portfolio ${portfolio._id}`);

    res.status(200).json({
      success: true,
      data: portfolio,
    });
  } catch (error) {
    logger.error(`Error updating asset in portfolio: ${error.message}`);
    next(error);
  }
};

// @desc    Remove asset from portfolio
// @route   DELETE /api/v1/portfolios/:id/assets/:symbol
// @access  Private
export const removeAsset = async (req, res, next) => {
  try {
    const { symbol } = req.params;

    // Find portfolio
    const portfolio = await Portfolio.findById(req.params.id);

    if (!portfolio) {
      return next(new AppError(`Portfolio not found with id of ${req.params.id}`, 404));
    }

    // Check if portfolio belongs to user
    if (portfolio.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new AppError('Not authorized to update this portfolio', 401));
    }

    // Find asset in portfolio
    const assetIndex = portfolio.assets.findIndex((a) => a.symbol === symbol);

    if (assetIndex === -1) {
      return next(new AppError(`Asset not found in portfolio with symbol ${symbol}`, 404));
    }

    // Remove asset
    portfolio.assets.splice(assetIndex, 1);

    // Save portfolio
    await portfolio.save();

    logger.info(`Asset ${symbol} removed from portfolio ${portfolio._id}`);

    res.status(200).json({
      success: true,
      data: portfolio,
    });
  } catch (error) {
    logger.error(`Error removing asset from portfolio: ${error.message}`);
    next(error);
  }
};

// @desc    Get portfolio performance
// @route   GET /api/v1/portfolios/:id/performance
// @access  Private
export const getPortfolioPerformance = async (req, res, next) => {
  try {
    const portfolio = await Portfolio.findById(req.params.id);

    if (!portfolio) {
      return next(new AppError(`Portfolio not found with id of ${req.params.id}`, 404));
    }

    // Check if portfolio belongs to user
    if (portfolio.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new AppError('Not authorized to access this portfolio', 401));
    }

    // Get transactions for this portfolio
    const transactions = await Transaction.find({
      portfolio: portfolio._id,
      status: 'completed',
    }).sort({ createdAt: 1 });

    // Calculate performance metrics
    const performance = {
      totalValue: 0,
      totalCost: 0,
      totalProfit: 0,
      profitPercentage: 0,
      assets: [],
    };

    // Process each asset
    for (const asset of portfolio.assets) {
      // Get asset current price
      let currentPrice;
      if (asset.type === 'tokenized') {
        const tokenizedAsset = await TokenizedAsset.findOne({ symbol: asset.symbol });
        currentPrice = tokenizedAsset ? tokenizedAsset.price : asset.currentPrice;
      } else {
        const regularAsset = await Asset.findOne({ symbol: asset.symbol });
        currentPrice = regularAsset ? regularAsset.price : asset.currentPrice;
      }

      // Calculate asset metrics
      const currentValue = asset.quantity * currentPrice;
      const cost = asset.quantity * asset.averagePrice;
      const profit = currentValue - cost;
      const profitPercentage = cost > 0 ? (profit / cost) * 100 : 0;

      // Add to total
      performance.totalValue += currentValue;
      performance.totalCost += cost;
      performance.totalProfit += profit;

      // Add asset performance
      performance.assets.push({
        symbol: asset.symbol,
        name: asset.name,
        type: asset.type,
        quantity: asset.quantity,
        averagePrice: asset.averagePrice,
        currentPrice,
        currentValue,
        profit,
        profitPercentage,
      });
    }

    // Calculate total profit percentage
    performance.profitPercentage = performance.totalCost > 0
      ? (performance.totalProfit / performance.totalCost) * 100
      : 0;

    res.status(200).json({
      success: true,
      data: performance,
    });
  } catch (error) {
    logger.error(`Error getting portfolio performance: ${error.message}`);
    next(error);
  }
};

// @desc    Get portfolio transactions
// @route   GET /api/v1/portfolio/transactions
// @access  Private
export const getPortfolioTransactions = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 20;
    
    // Build filter object
    const filters = { userId: req.user.id };
    
    if (req.query.type) {
      filters.type = req.query.type;
    }
    
    if (req.query.status) {
      filters.status = req.query.status;
    }
    
    if (req.query.assetId) {
      filters.assetId = req.query.assetId;
    }
    
    if (req.query.startDate && req.query.endDate) {
      filters.date = {
        $gte: new Date(req.query.startDate),
        $lte: new Date(req.query.endDate),
      };
    } else if (req.query.startDate) {
      filters.date = { $gte: new Date(req.query.startDate) };
    } else if (req.query.endDate) {
      filters.date = { $lte: new Date(req.query.endDate) };
    }
    
    // Get transactions with pagination
    const result = await Transaction.findUserTransactions(
      req.user.id,
      filters,
      page,
      limit,
      { date: -1 }
    );
    
    res.status(200).json({
      success: true,
      count: result.transactions.length,
      pagination: result.pagination,
      data: result.transactions,
    });
  } catch (error) {
    logger.error(`Error getting portfolio transactions: ${error.message}`);
    next(error);
  }
};

// @desc    Get transaction statistics
// @route   GET /api/v1/portfolio/transactions/stats
// @access  Private
export const getTransactionStats = async (req, res, next) => {
  try {
    const period = parseInt(req.query.period, 10) || 30;
    
    // Get transaction statistics
    const stats = await Transaction.getTransactionStats(req.user.id, period);
    
    res.status(200).json({
      success: true,
      data: stats,
    });
  } catch (error) {
    logger.error(`Error getting transaction stats: ${error.message}`);
    next(error);
  }
};

// @desc    Add asset to watchlist
// @route   POST /api/v1/portfolio/watchlist
// @access  Private
export const addToWatchlist = async (req, res, next) => {
  try {
    const { assetId, notes, priceAlert } = req.body;
    
    if (!assetId) {
      return next(new AppError('Please provide assetId', 400));
    }
    
    // Find user's portfolio
    let portfolio = await Portfolio.findOne({ userId: req.user.id });
    
    if (!portfolio) {
      portfolio = await Portfolio.create({
        userId: req.user.id,
        name: 'Default Portfolio',
        positions: [],
        watchlist: [],
      });
    }
    
    // Check if asset exists
    let asset;
    
    // Try to find in regular assets
    asset = await Asset.findById(assetId);
    
    // If not found, try tokenized assets
    if (!asset) {
      asset = await TokenizedAsset.findById(assetId);
    }
    
    if (!asset) {
      return next(new AppError(`Asset not found with id of ${assetId}`, 404));
    }
    
    // Check if asset is already in watchlist
    const existingItem = portfolio.watchlist.find(
      (item) => item.assetId.toString() === assetId
    );
    
    if (existingItem) {
      return next(new AppError('Asset already in watchlist', 400));
    }
    
    // Add to watchlist
    portfolio.watchlist.push({
      assetId,
      addedAt: new Date(),
      notes,
      priceAlert,
    });
    
    await portfolio.save();
    
    // Populate asset data for response
    await portfolio.populate('watchlist.assetId', 'name symbol type price priceChangePercent24h imageUrl');
    
    logger.info(`User ${req.user.id} added ${asset.symbol} to watchlist`);
    
    res.status(201).json({
      success: true,
      data: portfolio.watchlist,
    });
  } catch (error) {
    logger.error(`Error adding to watchlist: ${error.message}`);
    next(error);
  }
};

// @desc    Remove asset from watchlist
// @route   DELETE /api/v1/portfolio/watchlist/:assetId
// @access  Private
export const removeFromWatchlist = async (req, res, next) => {
  try {
    const { assetId } = req.params;
    
    // Find user's portfolio
    const portfolio = await Portfolio.findOne({ userId: req.user.id });
    
    if (!portfolio) {
      return next(new AppError('Portfolio not found', 404));
    }
    
    // Check if asset is in watchlist
    const existingItem = portfolio.watchlist.find(
      (item) => item.assetId.toString() === assetId
    );
    
    if (!existingItem) {
      return next(new AppError('Asset not found in watchlist', 404));
    }
    
    // Remove from watchlist
    portfolio.watchlist = portfolio.watchlist.filter(
      (item) => item.assetId.toString() !== assetId
    );
    
    await portfolio.save();
    
    logger.info(`User ${req.user.id} removed asset from watchlist`);
    
    res.status(200).json({
      success: true,
      data: portfolio.watchlist,
    });
  } catch (error) {
    logger.error(`Error removing from watchlist: ${error.message}`);
    next(error);
  }
};

// @desc    Update portfolio settings
// @route   PUT /api/v1/portfolio/settings
// @access  Private
export const updatePortfolioSettings = async (req, res, next) => {
  try {
    const { name, description, settings } = req.body;
    
    // Find user's portfolio
    let portfolio = await Portfolio.findOne({ userId: req.user.id });
    
    if (!portfolio) {
      return next(new AppError('Portfolio not found', 404));
    }
    
    // Update fields
    if (name) portfolio.name = name;
    if (description) portfolio.description = description;
    
    if (settings) {
      // Update settings
      if (settings.defaultCurrency) {
        portfolio.settings.defaultCurrency = settings.defaultCurrency;
      }
      
      if (settings.riskLevel) {
        portfolio.settings.riskLevel = settings.riskLevel;
      }
      
      if (settings.autoRebalance) {
        portfolio.settings.autoRebalance = {
          ...portfolio.settings.autoRebalance,
          ...settings.autoRebalance,
        };
      }
    }
    
    await portfolio.save();
    
    logger.info(`User ${req.user.id} updated portfolio settings`);
    
    res.status(200).json({
      success: true,
      data: portfolio,
    });
  } catch (error) {
    logger.error(`Error updating portfolio settings: ${error.message}`);
    next(error);
  }
};

// @desc    Get portfolio AI insights
// @route   GET /api/v1/portfolio/insights
// @access  Private
export const getPortfolioInsights = async (req, res, next) => {
  try {
    // Find user's portfolio
    const portfolio = await Portfolio.findOne({ userId: req.user.id });
    
    if (!portfolio) {
      return next(new AppError('Portfolio not found', 404));
    }
    
    // Check if AI insights exist and are recent (less than 24 hours old)
    const now = new Date();
    const insightsAreRecent =
      portfolio.aiInsights &&
      portfolio.aiInsights.lastUpdated &&
      now - portfolio.aiInsights.lastUpdated < 24 * 60 * 60 * 1000;
    
    if (!portfolio.aiInsights || !insightsAreRecent) {
      // In a real application, this would trigger an AI analysis job
      // For now, we'll just return a message
      return res.status(202).json({
        success: true,
        message: 'AI insights are being generated. Please check back later.',
        data: portfolio.aiInsights || null,
      });
    }
    
    res.status(200).json({
      success: true,
      data: portfolio.aiInsights,
    });
  } catch (error) {
    logger.error(`Error getting portfolio insights: ${error.message}`);
    next(error);
  }
}; 