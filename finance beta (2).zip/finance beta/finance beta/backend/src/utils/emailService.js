import nodemailer from 'nodemailer';
import env from '../config/env.js';
import { logger } from './logger.js';
import sendEmail from './sendEmail.js';

/**
 * Email service for sending various types of emails
 */
const emailService = {
  /**
   * Send welcome email with verification link
   * @param {Object} options - Email options
   * @param {String} options.email - Recipient email
   * @param {String} options.name - Recipient name
   * @param {String} options.verificationUrl - Verification URL
   * @returns {Promise} - Email info
   */
  sendWelcomeEmail: async ({ email, name, verificationUrl }) => {
    try {
      const message = `
        <h1>Welcome to Finance App!</h1>
        <p>Hello ${name},</p>
        <p>Thank you for registering with Finance App. Please verify your email by clicking on the link below:</p>
        <a href="${verificationUrl}" target="_blank">Verify Email</a>
        <p>If you did not register for an account, please ignore this email.</p>
        <p>Regards,<br>Finance App Team</p>
      `;

      return await sendEmail({
        email,
        subject: 'Welcome to Finance App - Verify Your Email',
        message,
      });
    } catch (error) {
      logger.error(`Error sending welcome email: ${error.message}`);
      throw error;
    }
  },

  /**
   * Send password reset email
   * @param {Object} options - Email options
   * @param {String} options.email - Recipient email
   * @param {String} options.name - Recipient name
   * @param {String} options.resetToken - Reset token
   * @param {String} options.resetUrl - Reset URL
   * @returns {Promise} - Email info
   */
  sendPasswordResetEmail: async ({ email, name, resetToken, resetUrl }) => {
    try {
      const message = `
        <h1>Password Reset</h1>
        <p>Hello ${name},</p>
        <p>You are receiving this email because you (or someone else) has requested the reset of a password.</p>
        <p>Please click on the following link to reset your password:</p>
        <a href="${resetUrl}" target="_blank">Reset Password</a>
        <p>If you did not request this, please ignore this email and your password will remain unchanged.</p>
        <p>Regards,<br>Finance App Team</p>
      `;

      return await sendEmail({
        email,
        subject: 'Password Reset Request',
        message,
      });
    } catch (error) {
      logger.error(`Error sending password reset email: ${error.message}`);
      throw error;
    }
  },

  /**
   * Send alert notification email
   * @param {Object} options - Email options
   * @param {String} options.email - Recipient email
   * @param {String} options.name - Recipient name
   * @param {String} options.alertType - Type of alert
   * @param {String} options.alertMessage - Alert message
   * @param {String} options.actionUrl - Action URL
   * @returns {Promise} - Email info
   */
  sendAlertEmail: async ({ email, name, alertType, alertMessage, actionUrl }) => {
    try {
      const message = `
        <h1>Alert Notification</h1>
        <p>Hello ${name},</p>
        <p>You have a new ${alertType} alert:</p>
        <p>${alertMessage}</p>
        ${actionUrl ? `<a href="${actionUrl}" target="_blank">View Details</a>` : ''}
        <p>Regards,<br>Finance App Team</p>
      `;

      return await sendEmail({
        email,
        subject: `Finance App - ${alertType} Alert`,
        message,
      });
    } catch (error) {
      logger.error(`Error sending alert email: ${error.message}`);
      throw error;
    }
  },
};

export default emailService; 