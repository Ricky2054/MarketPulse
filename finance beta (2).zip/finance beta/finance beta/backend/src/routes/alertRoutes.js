import express from 'express';
import {
  getAlerts,
  getAlert,
  createAlert,
  updateAlert,
  deleteAlert,
  getAlertHistory,
} from '../controllers/alertController.js';
import { authenticate } from '../middleware/auth.js';
import { validate, schemas } from '../utils/validator.js';

const router = express.Router();

// All routes require authentication
router.use(authenticate);

// Alert routes
router.get('/', getAlerts);
router.get('/history', getAlertHistory);
router.get('/:id', getAlert);
router.post('/', validate(schemas.alertCreate), createAlert);
router.put('/:id', validate(schemas.alertUpdate), updateAlert);
router.delete('/:id', deleteAlert);

export default router; 