import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import axios from 'axios';
import { Asset } from './marketSlice';

export interface TokenizedAsset extends Asset {
  assetType: 'real_estate' | 'art' | 'commodity' | 'collectible' | 'other';
  description: string;
  location?: string;
  issuer: string;
  totalSupply: number;
  currentSupply: number;
  documentationUrl?: string;
  images: string[];
  verificationStatus: 'verified' | 'pending' | 'unverified';
}

export interface TokenizationState {
  tokenizedAssets: TokenizedAsset[];
  selectedAsset: TokenizedAsset | null;
  loading: boolean;
  error: string | null;
  filters: {
    assetType: string[];
    verificationStatus: string[];
    search: string;
    sortBy: string;
    sortDirection: 'asc' | 'desc';
  };
}

const initialState: TokenizationState = {
  tokenizedAssets: [],
  selectedAsset: null,
  loading: false,
  error: null,
  filters: {
    assetType: [],
    verificationStatus: [],
    search: '',
    sortBy: 'price',
    sortDirection: 'desc',
  },
};

export const fetchTokenizedAssets = createAsyncThunk(
  'tokenization/fetchTokenizedAssets',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get('/api/tokenization/assets');
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch tokenized assets');
    }
  }
);

export const fetchTokenizedAssetDetails = createAsyncThunk(
  'tokenization/fetchTokenizedAssetDetails',
  async (assetId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(`/api/tokenization/assets/${assetId}`);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch tokenized asset details');
    }
  }
);

export const investInTokenizedAsset = createAsyncThunk(
  'tokenization/investInTokenizedAsset',
  async (
    { assetId, amount }: { assetId: string; amount: number },
    { rejectWithValue }
  ) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return rejectWithValue('No token found');

      const response = await axios.post(
        '/api/tokenization/invest',
        { assetId, amount },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to invest in tokenized asset');
    }
  }
);

const tokenizationSlice = createSlice({
  name: 'tokenization',
  initialState,
  reducers: {
    setSelectedTokenizedAsset: (state, action: PayloadAction<TokenizedAsset | null>) => {
      state.selectedAsset = action.payload;
    },
    setTokenizationFilters: (state, action: PayloadAction<Partial<TokenizationState['filters']>>) => {
      state.filters = { ...state.filters, ...action.payload };
    },
    clearTokenizationFilters: (state) => {
      state.filters = initialState.filters;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTokenizedAssets.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTokenizedAssets.fulfilled, (state, action: PayloadAction<TokenizedAsset[]>) => {
        state.loading = false;
        state.tokenizedAssets = action.payload;
      })
      .addCase(fetchTokenizedAssets.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchTokenizedAssetDetails.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTokenizedAssetDetails.fulfilled, (state, action: PayloadAction<TokenizedAsset>) => {
        state.loading = false;
        state.selectedAsset = action.payload;
      })
      .addCase(fetchTokenizedAssetDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(investInTokenizedAsset.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(investInTokenizedAsset.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(investInTokenizedAsset.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { setSelectedTokenizedAsset, setTokenizationFilters, clearTokenizationFilters } =
  tokenizationSlice.actions;
export default tokenizationSlice.reducer; 