import Alert from '../models/Alert.js';
import Asset from '../models/Asset.js';
import TokenizedAsset from '../models/TokenizedAsset.js';
import Portfolio from '../models/Portfolio.js';
import AppError from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { io } from '../index.js';
import emailService from '../utils/emailService.js';

// @desc    Get all alerts for a user
// @route   GET /api/v1/alerts
// @access  Private
export const getAlerts = async (req, res, next) => {
  try {
    const { type, status, sort, limit = 20, page = 1 } = req.query;
    
    // Build query
    const query = { user: req.user.id };
    
    // Filter by type
    if (type) {
      query.type = type;
    }
    
    // Filter by status
    if (status) {
      query.status = status;
    }
    
    // Count total documents
    const total = await Alert.countDocuments(query);
    
    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    // Build sort object
    let sortObj = {};
    if (sort) {
      const sortFields = sort.split(',');
      sortFields.forEach(field => {
        if (field.startsWith('-')) {
          sortObj[field.substring(1)] = -1;
        } else {
          sortObj[field] = 1;
        }
      });
    } else {
      // Default sort by createdAt
      sortObj = { createdAt: -1 };
    }
    
    // Execute query
    const alerts = await Alert.find(query)
      .sort(sortObj)
      .skip(skip)
      .limit(parseInt(limit));
    
    res.status(200).json({
      success: true,
      count: alerts.length,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / parseInt(limit)),
      },
      data: alerts,
    });
  } catch (error) {
    logger.error(`Error getting alerts: ${error.message}`);
    next(error);
  }
};

// @desc    Get alert statistics
// @route   GET /api/v1/alerts/stats
// @access  Private
export const getAlertStats = async (req, res, next) => {
  try {
    // Get alert statistics
    const stats = await Alert.getAlertStats(req.user.id);
    
    res.status(200).json({
      success: true,
      data: stats,
    });
  } catch (error) {
    logger.error(`Error getting alert stats: ${error.message}`);
    next(error);
  }
};

// @desc    Get single alert
// @route   GET /api/v1/alerts/:id
// @access  Private
export const getAlert = async (req, res, next) => {
  try {
    const alert = await Alert.findById(req.params.id);
    
    if (!alert) {
      return next(new AppError(`Alert not found with id of ${req.params.id}`, 404));
    }
    
    // Check if alert belongs to user
    if (alert.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new AppError('Not authorized to access this alert', 401));
    }
    
    res.status(200).json({
      success: true,
      data: alert,
    });
  } catch (error) {
    logger.error(`Error getting alert: ${error.message}`);
    next(error);
  }
};

// @desc    Create new alert
// @route   POST /api/v1/alerts
// @access  Private
export const createAlert = async (req, res, next) => {
  try {
    // Add user to request body
    req.body.user = req.user.id;
    
    // Create alert
    const alert = await Alert.create(req.body);
    
    logger.info(`Alert created: ${alert._id} by user ${req.user.id}`);
    
    res.status(201).json({
      success: true,
      data: alert,
    });
  } catch (error) {
    logger.error(`Error creating alert: ${error.message}`);
    next(error);
  }
};

// @desc    Create price alert
// @route   POST /api/v1/alerts/price
// @access  Private
export const createPriceAlert = async (req, res, next) => {
  try {
    const { assetId, price, condition, message } = req.body;
    
    if (!assetId || !price || !condition) {
      return next(new AppError('Please provide assetId, price, and condition', 400));
    }
    
    // Validate condition
    if (!['above', 'below'].includes(condition)) {
      return next(new AppError('Condition must be either "above" or "below"', 400));
    }
    
    // Find asset
    let asset;
    let isTokenized = false;
    
    // Try to find in regular assets
    asset = await Asset.findById(assetId);
    
    // If not found, try tokenized assets
    if (!asset) {
      asset = await TokenizedAsset.findById(assetId);
      isTokenized = true;
    }
    
    if (!asset) {
      return next(new AppError(`Asset not found with id of ${assetId}`, 404));
    }
    
    // Create alert
    const alert = await Alert.create({
      userId: req.user.id,
      type: 'price_alert',
      title: `Price Alert: ${asset.symbol} ${condition === 'above' ? 'above' : 'below'} ${price}`,
      message: message || `You will be notified when ${asset.name} (${asset.symbol}) ${condition === 'above' ? 'rises above' : 'falls below'} ${price}`,
      priority: 'medium',
      [isTokenized ? 'relatedTokenizedAsset' : 'relatedAsset']: {
        [isTokenized ? 'tokenizedAssetId' : 'assetId']: asset._id,
        symbol: asset.symbol,
        name: asset.name,
        price: isTokenized ? asset.tokenPrice : asset.price,
      },
      actionUrl: isTokenized ? `/tokenized-assets/${asset.symbol.toLowerCase()}` : `/assets/${asset.symbol.toLowerCase()}`,
      actionText: 'View Asset',
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
    });
    
    // Add price alert to portfolio watchlist if asset is in watchlist
    const portfolio = await Portfolio.findOne({ userId: req.user.id });
    
    if (portfolio) {
      const watchlistItem = portfolio.watchlist.find(
        (item) => item.assetId.toString() === assetId
      );
      
      if (watchlistItem) {
        watchlistItem.priceAlert = {
          enabled: true,
          condition,
          price: parseFloat(price),
        };
        
        await portfolio.save();
      }
    }
    
    // Log alert creation
    logger.info(`Price alert created for user ${req.user.id}: ${asset.symbol} ${condition} ${price}`);
    
    res.status(201).json({
      success: true,
      data: alert,
    });
  } catch (error) {
    logger.error(`Error creating price alert: ${error.message}`);
    next(error);
  }
};

// @desc    Mark alert as read
// @route   PUT /api/v1/alerts/:id/read
// @access  Private
export const markAlertAsRead = async (req, res, next) => {
  try {
    const alert = await Alert.findById(req.params.id);
    
    if (!alert) {
      return next(new AppError(`Alert not found with id of ${req.params.id}`, 404));
    }
    
    // Check if alert belongs to user
    if (alert.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new AppError('Not authorized to access this alert', 401));
    }
    
    // Mark as read
    await alert.markAsRead();
    
    res.status(200).json({
      success: true,
      data: alert,
    });
  } catch (error) {
    logger.error(`Error marking alert as read: ${error.message}`);
    next(error);
  }
};

// @desc    Mark all alerts as read
// @route   PUT /api/v1/alerts/read-all
// @access  Private
export const markAllAlertsAsRead = async (req, res, next) => {
  try {
    // Mark all unread alerts as read
    const count = await Alert.markAllAsRead(req.user.id);
    
    res.status(200).json({
      success: true,
      data: {
        count,
        message: `${count} alerts marked as read`,
      },
    });
  } catch (error) {
    logger.error(`Error marking all alerts as read: ${error.message}`);
    next(error);
  }
};

// @desc    Archive alert
// @route   PUT /api/v1/alerts/:id/archive
// @access  Private
export const archiveAlert = async (req, res, next) => {
  try {
    const alert = await Alert.findById(req.params.id);
    
    if (!alert) {
      return next(new AppError(`Alert not found with id of ${req.params.id}`, 404));
    }
    
    // Check if alert belongs to user
    if (alert.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new AppError('Not authorized to access this alert', 401));
    }
    
    // Archive alert
    await alert.archive();
    
    res.status(200).json({
      success: true,
      data: alert,
    });
  } catch (error) {
    logger.error(`Error archiving alert: ${error.message}`);
    next(error);
  }
};

// @desc    Delete alert
// @route   DELETE /api/v1/alerts/:id
// @access  Private
export const deleteAlert = async (req, res, next) => {
  try {
    const alert = await Alert.findById(req.params.id);
    
    if (!alert) {
      return next(new AppError(`Alert not found with id of ${req.params.id}`, 404));
    }
    
    // Check if alert belongs to user
    if (alert.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new AppError('Not authorized to delete this alert', 401));
    }
    
    await alert.deleteOne();
    
    logger.info(`Alert deleted: ${req.params.id}`);
    
    res.status(200).json({
      success: true,
      data: {},
    });
  } catch (error) {
    logger.error(`Error deleting alert: ${error.message}`);
    next(error);
  }
};

// @desc    Create system alert (Admin only)
// @route   POST /api/v1/alerts/system
// @access  Private (Admin)
export const createSystemAlert = async (req, res, next) => {
  try {
    const { title, message, priority, userIds, expiresAt } = req.body;
    
    if (!title || !message || !priority) {
      return next(new AppError('Please provide title, message, and priority', 400));
    }
    
    // Validate priority
    if (!['low', 'medium', 'high', 'critical'].includes(priority)) {
      return next(new AppError('Priority must be low, medium, high, or critical', 400));
    }
    
    // Create alerts for specified users or all users
    let alerts = [];
    
    if (userIds && userIds.length > 0) {
      // Create alerts for specific users
      const alertPromises = userIds.map((userId) =>
        Alert.create({
          userId,
          type: 'system',
          title,
          message,
          priority,
          status: 'unread',
          expiresAt: expiresAt ? new Date(expiresAt) : undefined,
        })
      );
      
      alerts = await Promise.all(alertPromises);
      
      // Emit real-time notifications
      alerts.forEach((alert) => {
        io.to(`user_${alert.userId}`).emit('newAlert', {
          id: alert._id,
          type: alert.type,
          title: alert.title,
          message: alert.message,
          priority: alert.priority,
          createdAt: alert.createdAt,
        });
      });
    } else {
      // This would create alerts for all users in a real application
      // For now, just return a message
      return res.status(202).json({
        success: true,
        message: 'System alert would be sent to all users in a production environment',
      });
    }
    
    // Log system alert creation
    logger.info(`System alert created by admin ${req.user.id}: ${title}`);
    
    res.status(201).json({
      success: true,
      count: alerts.length,
      data: alerts,
    });
  } catch (error) {
    logger.error(`Error creating system alert: ${error.message}`);
    next(error);
  }
};

// @desc    Process price alerts (System use)
// @route   POST /api/v1/alerts/process-price-alerts
// @access  Private (System)
export const processPriceAlerts = async (req, res, next) => {
  try {
    const { assetId, price, priceChange } = req.body;
    
    if (!assetId || price === undefined) {
      return next(new AppError('Please provide assetId and price', 400));
    }
    
    // Find asset
    let asset;
    let isTokenized = false;
    
    // Try to find in regular assets
    asset = await Asset.findById(assetId);
    
    // If not found, try tokenized assets
    if (!asset) {
      asset = await TokenizedAsset.findById(assetId);
      isTokenized = true;
    }
    
    if (!asset) {
      return next(new AppError(`Asset not found with id of ${assetId}`, 404));
    }
    
    // Find all price alerts for this asset
    const alerts = await Alert.find({
      status: 'unread',
      [isTokenized ? 'relatedTokenizedAsset.tokenizedAssetId' : 'relatedAsset.assetId']: assetId,
      type: 'price_alert',
    });
    
    // Process each alert
    const triggeredAlerts = [];
    
    for (const alert of alerts) {
      const alertPrice = isTokenized
        ? alert.relatedTokenizedAsset.priceAlert?.price
        : alert.relatedAsset.priceAlert?.price;
      
      const alertCondition = isTokenized
        ? alert.relatedTokenizedAsset.priceAlert?.condition
        : alert.relatedAsset.priceAlert?.condition;
      
      if (
        (alertCondition === 'above' && price >= alertPrice) ||
        (alertCondition === 'below' && price <= alertPrice)
      ) {
        // Create a new triggered alert
        const triggeredAlert = await Alert.createPriceAlert(
          alert.userId,
          asset,
          price,
          priceChange,
          alertCondition
        );
        
        // Mark the original alert as read
        await alert.markAsRead();
        
        // Emit real-time notification
        io.to(`user_${alert.userId}`).emit('newAlert', {
          id: triggeredAlert._id,
          type: triggeredAlert.type,
          title: triggeredAlert.title,
          message: triggeredAlert.message,
          priority: triggeredAlert.priority,
          createdAt: triggeredAlert.createdAt,
        });
        
        triggeredAlerts.push(triggeredAlert);
      }
    }
    
    // Log price alert processing
    logger.info(`Processed price alerts for ${asset.symbol}: ${triggeredAlerts.length} triggered`);
    
    res.status(200).json({
      success: true,
      count: triggeredAlerts.length,
      data: triggeredAlerts,
    });
  } catch (error) {
    logger.error(`Error processing price alerts: ${error.message}`);
    next(error);
  }
};

// @desc    Get alert history
// @route   GET /api/v1/alerts/history
// @access  Private
export const getAlertHistory = async (req, res, next) => {
  try {
    const { limit = 20, page = 1 } = req.query;
    
    // Build query
    const query = { 
      user: req.user.id,
      status: 'triggered'
    };
    
    // Count total documents
    const total = await Alert.countDocuments(query);
    
    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    // Execute query
    const alertHistory = await Alert.find(query)
      .sort({ triggeredAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));
    
    res.status(200).json({
      success: true,
      count: alertHistory.length,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / parseInt(limit)),
      },
      data: alertHistory,
    });
  } catch (error) {
    logger.error(`Error getting alert history: ${error.message}`);
    next(error);
  }
};

// @desc    Process price alert
// @route   POST /api/v1/alerts/process-price
// @access  Private (Internal)
export const processPriceAlert = async (assetSymbol, currentPrice) => {
  try {
    // Find all active price alerts for this asset
    const alerts = await Alert.find({
      type: 'price',
      status: 'active',
      'conditions.asset': assetSymbol,
    });
    
    if (alerts.length === 0) {
      return;
    }
    
    logger.info(`Processing ${alerts.length} price alerts for ${assetSymbol}`);
    
    // Process each alert
    for (const alert of alerts) {
      const condition = alert.conditions[0]; // Price alerts have only one condition
      
      let isTriggered = false;
      let message = '';
      
      // Check if alert condition is met
      switch (condition.operator) {
        case 'above':
          isTriggered = currentPrice > condition.value;
          message = `${assetSymbol} price is above ${condition.value}`;
          break;
        case 'below':
          isTriggered = currentPrice < condition.value;
          message = `${assetSymbol} price is below ${condition.value}`;
          break;
        case 'percent_increase':
          const increaseThreshold = condition.basePrice * (1 + condition.value / 100);
          isTriggered = currentPrice >= increaseThreshold;
          message = `${assetSymbol} price increased by ${condition.value}% from ${condition.basePrice}`;
          break;
        case 'percent_decrease':
          const decreaseThreshold = condition.basePrice * (1 - condition.value / 100);
          isTriggered = currentPrice <= decreaseThreshold;
          message = `${assetSymbol} price decreased by ${condition.value}% from ${condition.basePrice}`;
          break;
        default:
          logger.error(`Unknown operator: ${condition.operator}`);
          continue;
      }
      
      // If alert is triggered
      if (isTriggered) {
        // Update alert
        alert.status = 'triggered';
        alert.triggeredAt = Date.now();
        alert.message = message;
        await alert.save();
        
        logger.info(`Alert triggered: ${alert._id} - ${message}`);
        
        // Get user
        const user = await User.findById(alert.user);
        
        if (user) {
          // Send notification based on user preferences
          if (user.preferences.notifications.email) {
            try {
              await emailService.sendAlertEmail({
                email: user.email,
                name: user.name,
                alertType: 'Price Alert',
                alertMessage: message,
                actionUrl: `${process.env.FRONTEND_URL}/alerts/${alert._id}`,
              });
              
              logger.info(`Alert email sent to ${user.email}`);
            } catch (error) {
              logger.error(`Error sending alert email: ${error.message}`);
            }
          }
          
          // Send push notification if user has push subscription
          if (user.preferences.notifications.push && user.pushSubscription) {
            try {
              await sendPushNotification(
                user.pushSubscription,
                'Price Alert',
                message
              );
              
              logger.info(`Push notification sent to user ${user._id}`);
            } catch (error) {
              logger.error(`Error sending push notification: ${error.message}`);
            }
          }
        }
      }
    }
  } catch (error) {
    logger.error(`Error processing price alerts: ${error.message}`);
  }
}; 