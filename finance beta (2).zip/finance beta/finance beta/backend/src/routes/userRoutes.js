import express from 'express';
import {
  getUsers,
  getUser,
  updateUser,
  deleteUser,
  registerPushSubscription,
} from '../controllers/userController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { validate, schemas } from '../utils/validator.js';

const router = express.Router();

// All routes require authentication
router.use(authenticate);

// User routes
router.get('/me', getUser);
router.put('/me', validate(schemas.userUpdate), updateUser);
router.post('/push-subscription', registerPushSubscription);

// Admin routes
router.get('/', authorize('admin'), getUsers);
router.get('/:id', authorize('admin'), getUser);
router.put('/:id', authorize('admin'), validate(schemas.userUpdate), updateUser);
router.delete('/:id', authorize('admin'), deleteUser);

export default router; 