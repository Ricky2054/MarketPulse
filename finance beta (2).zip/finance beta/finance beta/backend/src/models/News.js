import mongoose from 'mongoose';

const NewsSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    summary: {
      type: String,
      required: true,
    },
    content: {
      type: String,
      required: true,
    },
    source: {
      name: {
        type: String,
        required: true,
      },
      url: {
        type: String,
        required: true,
      },
      logoUrl: String,
      reliability: {
        type: Number,
        min: 0,
        max: 10,
      },
    },
    author: {
      name: String,
      url: String,
      imageUrl: String,
    },
    publishedAt: {
      type: Date,
      required: true,
      index: true,
    },
    updatedAt: {
      type: Date,
      default: Date.now,
    },
    url: {
      type: String,
      required: true,
      unique: true,
    },
    imageUrl: String,
    categories: {
      type: [String],
      index: true,
    },
    tags: {
      type: [String],
      index: true,
    },
    relatedAssets: [
      {
        assetId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Asset',
        },
        symbol: String,
        name: String,
        relevanceScore: {
          type: Number,
          min: 0,
          max: 1,
        },
      },
    ],
    relatedTokenizedAssets: [
      {
        tokenizedAssetId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'TokenizedAsset',
        },
        symbol: String,
        name: String,
        relevanceScore: {
          type: Number,
          min: 0,
          max: 1,
        },
      },
    ],
    sentiment: {
      score: {
        type: Number,
        min: -1,
        max: 1,
      },
      label: {
        type: String,
        enum: ['very_negative', 'negative', 'neutral', 'positive', 'very_positive'],
      },
      confidence: {
        type: Number,
        min: 0,
        max: 1,
      },
    },
    impact: {
      type: String,
      enum: ['low', 'medium', 'high', 'critical'],
      default: 'medium',
    },
    aiAnalysis: {
      summary: String,
      keyPoints: [String],
      marketImplications: String,
      investmentAdvice: String,
      confidence: {
        type: Number,
        min: 0,
        max: 1,
      },
    },
    status: {
      type: String,
      enum: ['draft', 'published', 'archived'],
      default: 'published',
      index: true,
    },
    featured: {
      type: Boolean,
      default: false,
      index: true,
    },
    viewCount: {
      type: Number,
      default: 0,
    },
    likeCount: {
      type: Number,
      default: 0,
    },
    shareCount: {
      type: Number,
      default: 0,
    },
    commentCount: {
      type: Number,
      default: 0,
    },
    metadata: {
      type: mongoose.Schema.Types.Mixed,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Indexes for faster queries
NewsSchema.index({ publishedAt: -1 });
NewsSchema.index({ 'relatedAssets.symbol': 1, publishedAt: -1 });
NewsSchema.index({ 'relatedTokenizedAssets.symbol': 1, publishedAt: -1 });
NewsSchema.index({ 'sentiment.label': 1, publishedAt: -1 });
NewsSchema.index({ featured: 1, publishedAt: -1 });
NewsSchema.index({ status: 1, publishedAt: -1 });

// Virtual for age of news
NewsSchema.virtual('age').get(function () {
  return Math.floor((Date.now() - this.publishedAt) / (1000 * 60 * 60 * 24)); // in days
});

// Virtual for news URL
NewsSchema.virtual('newsUrl').get(function () {
  return `/news/${this._id}`;
});

// Static method to find news with pagination and filtering
NewsSchema.statics.findNews = async function (
  filters = {},
  page = 1,
  limit = 20,
  sort = { publishedAt: -1 }
) {
  const query = { ...filters, status: 'published' };
  
  const total = await this.countDocuments(query);
  const news = await this.find(query)
    .sort(sort)
    .skip((page - 1) * limit)
    .limit(limit);
  
  return {
    news,
    pagination: {
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    },
  };
};

// Static method to find news related to an asset
NewsSchema.statics.findAssetNews = async function (
  assetSymbol,
  page = 1,
  limit = 20
) {
  const query = {
    status: 'published',
    $or: [
      { 'relatedAssets.symbol': assetSymbol },
      { 'relatedTokenizedAssets.symbol': assetSymbol },
    ],
  };
  
  const total = await this.countDocuments(query);
  const news = await this.find(query)
    .sort({ publishedAt: -1 })
    .skip((page - 1) * limit)
    .limit(limit);
  
  return {
    news,
    pagination: {
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    },
  };
};

// Static method to get trending news
NewsSchema.statics.getTrendingNews = async function (limit = 5) {
  // Calculate a trending score based on recency, views, likes, and shares
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  
  return this.aggregate([
    {
      $match: {
        status: 'published',
        publishedAt: { $gte: oneWeekAgo },
      },
    },
    {
      $addFields: {
        // Calculate recency score (1.0 for now, decreasing to 0.1 for week-old news)
        recencyScore: {
          $divide: [
            { $subtract: [new Date(), '$publishedAt'] },
            1000 * 60 * 60 * 24 * 7, // 7 days in milliseconds
          ],
        },
        // Calculate engagement score
        engagementScore: {
          $add: [
            '$viewCount',
            { $multiply: ['$likeCount', 2] },
            { $multiply: ['$shareCount', 3] },
            { $multiply: ['$commentCount', 2] },
          ],
        },
      },
    },
    {
      $addFields: {
        // Normalize recency score (newer is better)
        normalizedRecencyScore: { $subtract: [1, '$recencyScore'] },
        // Calculate trending score
        trendingScore: {
          $add: [
            { $multiply: [{ $subtract: [1, '$recencyScore'] }, 0.6] }, // 60% weight to recency
            { $multiply: ['$engagementScore', 0.4] }, // 40% weight to engagement
          ],
        },
      },
    },
    {
      $sort: { trendingScore: -1 },
    },
    {
      $limit: limit,
    },
  ]);
};

// Static method to get news sentiment for an asset
NewsSchema.statics.getAssetSentiment = async function (assetSymbol, days = 7) {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);
  
  const query = {
    status: 'published',
    publishedAt: { $gte: startDate },
    $or: [
      { 'relatedAssets.symbol': assetSymbol },
      { 'relatedTokenizedAssets.symbol': assetSymbol },
    ],
  };
  
  const sentimentData = await this.aggregate([
    {
      $match: query,
    },
    {
      $group: {
        _id: {
          $dateToString: { format: '%Y-%m-%d', date: '$publishedAt' },
        },
        averageSentiment: { $avg: '$sentiment.score' },
        count: { $sum: 1 },
        articles: {
          $push: {
            id: '$_id',
            title: '$title',
            sentiment: '$sentiment',
            url: '$url',
          },
        },
      },
    },
    {
      $sort: { _id: 1 },
    },
  ]);
  
  // Calculate overall sentiment
  const overallSentiment = await this.aggregate([
    {
      $match: query,
    },
    {
      $group: {
        _id: null,
        averageSentiment: { $avg: '$sentiment.score' },
        totalArticles: { $sum: 1 },
        sentimentCounts: {
          $push: '$sentiment.label',
        },
      },
    },
  ]);
  
  // Count sentiment labels
  let sentimentDistribution = {
    very_negative: 0,
    negative: 0,
    neutral: 0,
    positive: 0,
    very_positive: 0,
  };
  
  if (overallSentiment.length > 0 && overallSentiment[0].sentimentCounts) {
    overallSentiment[0].sentimentCounts.forEach((label) => {
      if (label) sentimentDistribution[label]++;
    });
  }
  
  return {
    dailySentiment: sentimentData,
    overallSentiment: overallSentiment[0] || { averageSentiment: 0, totalArticles: 0 },
    sentimentDistribution,
  };
};

// Method to increment view count
NewsSchema.methods.incrementViewCount = async function () {
  this.viewCount += 1;
  return this.save();
};

// Method to like/unlike news
NewsSchema.methods.toggleLike = async function (increment = true) {
  this.likeCount += increment ? 1 : -1;
  if (this.likeCount < 0) this.likeCount = 0;
  return this.save();
};

// Method to share news
NewsSchema.methods.incrementShareCount = async function () {
  this.shareCount += 1;
  return this.save();
};

const News = mongoose.model('News', NewsSchema);

export default News;