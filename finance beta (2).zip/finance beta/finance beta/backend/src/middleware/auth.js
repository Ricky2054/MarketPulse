import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import AppError from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { redisClient } from '../index.js';

// Protect routes
export const authenticate = async (req, res, next) => {
  try {
    let token;

    // Get token from Authorization header
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith('Bearer')
    ) {
      token = req.headers.authorization.split(' ')[1];
    }
    // Get token from cookie
    else if (req.cookies && req.cookies.token) {
      token = req.cookies.token;
    }

    // Make sure token exists
    if (!token) {
      return next(new AppError('Not authorized to access this route', 401));
    }

    try {
      // Check if token is blacklisted
      const isBlacklisted = await redisClient.get(`blacklist_${token}`);
      if (isBlacklisted) {
        return next(new AppError('Not authorized to access this route', 401));
      }

      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Get user from the token
      const user = await User.findById(decoded.id);

      if (!user) {
        return next(new AppError('User not found', 404));
      }

      // Check if user is verified
      if (!user.isVerified) {
        return next(new AppError('Please verify your email to access this route', 401));
      }

      // Add user to request object
      req.user = user;
      next();
    } catch (error) {
      logger.error(`Authentication error: ${error.message}`);
      return next(new AppError('Not authorized to access this route', 401));
    }
  } catch (error) {
    logger.error(`Authentication error: ${error.message}`);
    next(error);
  }
};

// Grant access to specific roles
export const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return next(new AppError('User not found', 404));
    }

    if (!roles.includes(req.user.role)) {
      return next(
        new AppError(`User role ${req.user.role} is not authorized to access this route`, 403)
      );
    }

    next();
  };
};

// Blacklist token
export const blacklistToken = async (token, ttl) => {
  try {
    await redisClient.set(`blacklist_${token}`, 'true', {
      EX: ttl,
    });
    logger.info(`Token blacklisted with TTL: ${ttl}`);
    return true;
  } catch (error) {
    logger.error(`Error blacklisting token: ${error.message}`);
    return false;
  }
};

export default { authenticate, authorize, blacklistToken }; 