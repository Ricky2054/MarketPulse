import mongoose from 'mongoose';

const MarketDataSchema = new mongoose.Schema(
  {
    symbol: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    assetId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Asset',
      index: true,
    },
    tokenizedAssetId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'TokenizedAsset',
      index: true,
    },
    dataType: {
      type: String,
      enum: ['ohlcv', 'ticker', 'orderbook', 'trades', 'market_summary', 'technical_indicator'],
      required: true,
      index: true,
    },
    interval: {
      type: String,
      enum: ['1m', '5m', '15m', '30m', '1h', '2h', '4h', '6h', '12h', '1d', '3d', '1w', '1M'],
      index: true,
    },
    timestamp: {
      type: Date,
      required: true,
      index: true,
    },
    source: {
      type: String,
      required: true,
      index: true,
    },
    // OHLCV data
    ohlcv: {
      open: Number,
      high: Number,
      low: Number,
      close: Number,
      volume: Number,
      volumeQuote: Number,
    },
    // Ticker data
    ticker: {
      price: Number,
      priceChange: Number,
      priceChangePercent: Number,
      volume24h: Number,
      high24h: Number,
      low24h: Number,
      bid: Number,
      ask: Number,
      bidVolume: Number,
      askVolume: Number,
      spread: Number,
      spreadPercent: Number,
      timestamp: Date,
    },
    // Orderbook data
    orderbook: {
      bids: [
        {
          price: Number,
          amount: Number,
        },
      ],
      asks: [
        {
          price: Number,
          amount: Number,
        },
      ],
      timestamp: Date,
      depth: Number,
    },
    // Trades data
    trades: [
      {
        id: String,
        price: Number,
        amount: Number,
        side: {
          type: String,
          enum: ['buy', 'sell'],
        },
        timestamp: Date,
      },
    ],
    // Market summary data
    marketSummary: {
      price: Number,
      priceChange24h: Number,
      priceChangePercent24h: Number,
      volume24h: Number,
      volumeChange24h: Number,
      volumeChangePercent24h: Number,
      marketCap: Number,
      marketCapChange24h: Number,
      marketCapChangePercent24h: Number,
      totalSupply: Number,
      circulatingSupply: Number,
      ath: Number,
      athDate: Date,
      atl: Number,
      atlDate: Date,
      rank: Number,
      high24h: Number,
      low24h: Number,
      priceChangePercent7d: Number,
      priceChangePercent30d: Number,
      priceChangePercent90d: Number,
      priceChangePercent1y: Number,
      totalVolume: Number,
    },
    // Technical indicators
    technicalIndicators: {
      rsi: {
        value: Number,
        period: Number,
      },
      macd: {
        value: Number,
        signal: Number,
        histogram: Number,
        fastPeriod: Number,
        slowPeriod: Number,
        signalPeriod: Number,
      },
      ema: {
        value: Number,
        period: Number,
      },
      sma: {
        value: Number,
        period: Number,
      },
      bb: {
        upper: Number,
        middle: Number,
        lower: Number,
        period: Number,
        stdDev: Number,
      },
      atr: {
        value: Number,
        period: Number,
      },
      obv: {
        value: Number,
      },
      adx: {
        value: Number,
        period: Number,
      },
      stochastic: {
        k: Number,
        d: Number,
        kPeriod: Number,
        dPeriod: Number,
        slowing: Number,
      },
      ichimoku: {
        tenkanSen: Number,
        kijunSen: Number,
        senkouSpanA: Number,
        senkouSpanB: Number,
        chikouSpan: Number,
      },
      pivotPoints: {
        r3: Number,
        r2: Number,
        r1: Number,
        pivot: Number,
        s1: Number,
        s2: Number,
        s3: Number,
        type: String,
      },
      fibonacciRetracement: {
        trend: String,
        levels: [
          {
            level: Number,
            value: Number,
          },
        ],
      },
    },
    // AI-generated insights
    aiInsights: {
      sentiment: {
        type: String,
        enum: ['very_bearish', 'bearish', 'neutral', 'bullish', 'very_bullish'],
      },
      trendStrength: {
        type: Number,
        min: 0,
        max: 100,
      },
      supportLevels: [Number],
      resistanceLevels: [Number],
      shortTermPrediction: {
        direction: {
          type: String,
          enum: ['up', 'down', 'sideways'],
        },
        confidence: {
          type: Number,
          min: 0,
          max: 100,
        },
        targetPrice: Number,
        timeframe: String,
      },
      patterns: [
        {
          name: String,
          confidence: Number,
          significance: String,
        },
      ],
      anomalyDetection: {
        isAnomaly: Boolean,
        anomalyScore: Number,
        description: String,
      },
      lastUpdated: Date,
    },
    metadata: {
      type: mongoose.Schema.Types.Mixed,
    },
  },
  {
    timestamps: true,
  }
);

// Compound indexes for faster queries
MarketDataSchema.index({ symbol: 1, dataType: 1, timestamp: -1 });
MarketDataSchema.index({ assetId: 1, dataType: 1, timestamp: -1 });
MarketDataSchema.index({ tokenizedAssetId: 1, dataType: 1, timestamp: -1 });
MarketDataSchema.index({ symbol: 1, dataType: 1, interval: 1, timestamp: -1 });
MarketDataSchema.index({ source: 1, dataType: 1, timestamp: -1 });

// Static method to get latest ticker data for a symbol
MarketDataSchema.statics.getLatestTicker = async function (symbol) {
  return this.findOne({
    symbol,
    dataType: 'ticker',
  }).sort({ timestamp: -1 });
};

// Static method to get OHLCV data for a symbol with pagination
MarketDataSchema.statics.getOHLCV = async function (
  symbol,
  interval = '1d',
  limit = 100,
  startTime = null,
  endTime = null
) {
  const query = {
    symbol,
    dataType: 'ohlcv',
    interval,
  };
  
  if (startTime || endTime) {
    query.timestamp = {};
    if (startTime) query.timestamp.$gte = new Date(startTime);
    if (endTime) query.timestamp.$lte = new Date(endTime);
  }
  
  return this.find(query)
    .sort({ timestamp: 1 })
    .limit(limit)
    .select('timestamp ohlcv');
};

// Static method to get market summary for multiple symbols
MarketDataSchema.statics.getMarketSummaries = async function (symbols = []) {
  const query = {
    dataType: 'market_summary',
  };
  
  if (symbols.length > 0) {
    query.symbol = { $in: symbols };
  }
  
  return this.find(query)
    .sort({ 'marketSummary.rank': 1 })
    .limit(symbols.length || 100);
};

// Static method to get technical indicators for a symbol
MarketDataSchema.statics.getTechnicalIndicators = async function (symbol, indicators = []) {
  const query = {
    symbol,
    dataType: 'technical_indicator',
  };
  
  const projection = {
    symbol: 1,
    timestamp: 1,
    technicalIndicators: 1,
  };
  
  // If specific indicators are requested, only return those
  if (indicators.length > 0) {
    indicators.forEach((indicator) => {
      projection[`technicalIndicators.${indicator}`] = 1;
    });
  }
  
  return this.findOne(query)
    .sort({ timestamp: -1 })
    .select(projection);
};

// Static method to get AI insights for a symbol
MarketDataSchema.statics.getAIInsights = async function (symbol) {
  const query = {
    symbol,
    'aiInsights.lastUpdated': { $exists: true },
  };
  
  return this.findOne(query)
    .sort({ 'aiInsights.lastUpdated': -1 })
    .select('symbol timestamp aiInsights');
};

// Static method to update market data
MarketDataSchema.statics.updateMarketData = async function (data) {
  const { symbol, dataType, interval, timestamp, source, ...rest } = data;
  
  const query = {
    symbol,
    dataType,
    source,
  };
  
  if (interval) query.interval = interval;
  if (timestamp) query.timestamp = new Date(timestamp);
  
  const update = {
    $set: {
      ...rest,
      updatedAt: new Date(),
    },
  };
  
  const options = {
    upsert: true,
    new: true,
  };
  
  return this.findOneAndUpdate(query, update, options);
};

const MarketData = mongoose.model('MarketData', MarketDataSchema);

export default MarketData; 