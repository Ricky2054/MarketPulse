import User from '../models/User.js';
import emailService from './emailService.js';
import smsService from './smsService.js';
import pushNotificationService from './pushNotificationService.js';
import { logger } from './logger.js';
import { setupSocketEvents } from './socketEvents.js';

/**
 * Notification service for sending notifications across different channels
 * @class NotificationService
 */
class NotificationService {
  constructor() {
    this.socketEvents = null;
  }

  /**
   * Initialize the notification service with Socket.io
   * @param {Object} io - Socket.io instance
   * @param {Object} redisClient - Redis client
   */
  initialize(io, redisClient) {
    this.socketEvents = setupSocketEvents(io, redisClient);
    logger.info('Notification service initialized');
  }

  /**
   * Send a notification to a user through multiple channels
   * @param {Object} options - Notification options
   * @param {string} options.userId - User ID
   * @param {string} options.type - Notification type (alert, price, news, system)
   * @param {Array} options.channels - Notification channels (email, sms, push, in_app)
   * @param {Object} options.data - Notification data
   * @returns {Promise<Object>} Notification results
   */
  async sendNotification(options) {
    try {
      const { userId, type, channels = ['in_app'], data } = options;
      
      // Get user
      const user = await User.findById(userId);
      if (!user) {
        throw new Error(`User not found with ID: ${userId}`);
      }
      
      // Check user preferences
      const userPreferences = user.preferences || {};
      const enabledChannels = channels.filter((channel) => {
        // Check if the channel is enabled in user preferences
        if (userPreferences.notifications && 
            userPreferences.notifications[type] && 
            userPreferences.notifications[type][channel] === false) {
          return false;
        }
        return true;
      });
      
      if (enabledChannels.length === 0) {
        logger.info(`User ${userId} has disabled all notification channels for ${type}`);
        return { success: false, message: 'All notification channels are disabled' };
      }
      
      // Results object
      const results = {
        success: true,
        channels: {},
      };
      
      // Send notifications through each enabled channel
      const promises = [];
      
      // In-app notification (Socket.io)
      if (enabledChannels.includes('in_app') && this.socketEvents) {
        switch (type) {
          case 'alert':
            promises.push(
              Promise.resolve(this.socketEvents.emitAlert(userId, data))
                .then(() => {
                  results.channels.in_app = { success: true };
                })
                .catch((error) => {
                  logger.error(`Error sending in-app alert notification: ${error.message}`);
                  results.channels.in_app = { success: false, error: error.message };
                })
            );
            break;
            
          case 'price':
            if (data.symbol) {
              promises.push(
                Promise.resolve(this.socketEvents.emitPriceUpdate(data.symbol, data))
                  .then(() => {
                    results.channels.in_app = { success: true };
                  })
                  .catch((error) => {
                    logger.error(`Error sending in-app price notification: ${error.message}`);
                    results.channels.in_app = { success: false, error: error.message };
                  })
              );
            }
            break;
            
          case 'news':
            if (data.relatedAssets && data.relatedAssets.length > 0) {
              promises.push(
                Promise.resolve(this.socketEvents.emitNewsNotification(data.relatedAssets, data))
                  .then(() => {
                    results.channels.in_app = { success: true };
                  })
                  .catch((error) => {
                    logger.error(`Error sending in-app news notification: ${error.message}`);
                    results.channels.in_app = { success: false, error: error.message };
                  })
              );
            }
            break;
            
          case 'system':
            promises.push(
              Promise.resolve(this.socketEvents.emitSystemNotification(userId, data))
                .then(() => {
                  results.channels.in_app = { success: true };
                })
                .catch((error) => {
                  logger.error(`Error sending in-app system notification: ${error.message}`);
                  results.channels.in_app = { success: false, error: error.message };
                })
            );
            break;
            
          default:
            logger.warn(`Unknown notification type: ${type}`);
            break;
        }
      }
      
      // Email notification
      if (enabledChannels.includes('email') && user.email) {
        switch (type) {
          case 'alert':
            promises.push(
              emailService.sendAlertEmail({
                email: user.email,
                name: user.name,
                alert: data,
              })
                .then((result) => {
                  results.channels.email = { success: true, messageId: result.messageId };
                })
                .catch((error) => {
                  logger.error(`Error sending email alert notification: ${error.message}`);
                  results.channels.email = { success: false, error: error.message };
                })
            );
            break;
            
          // Add other email notification types as needed
            
          default:
            logger.warn(`Email notification not implemented for type: ${type}`);
            break;
        }
      }
      
      // SMS notification
      if (enabledChannels.includes('sms') && user.phone) {
        switch (type) {
          case 'alert':
            promises.push(
              smsService.sendAlertSms({
                phone: user.phone,
                alert: data,
              })
                .then((result) => {
                  results.channels.sms = { success: true, sid: result.sid };
                })
                .catch((error) => {
                  logger.error(`Error sending SMS alert notification: ${error.message}`);
                  results.channels.sms = { success: false, error: error.message };
                })
            );
            break;
            
          // Add other SMS notification types as needed
            
          default:
            logger.warn(`SMS notification not implemented for type: ${type}`);
            break;
        }
      }
      
      // Push notification
      if (enabledChannels.includes('push') && user.pushSubscription) {
        switch (type) {
          case 'alert':
            promises.push(
              pushNotificationService.sendAlertNotification({
                subscription: user.pushSubscription,
                alert: data,
                userId,
              })
                .then((result) => {
                  results.channels.push = { success: true };
                  
                  // Check if subscription has expired
                  if (result.expired) {
                    // Remove expired subscription
                    user.pushSubscription = null;
                    user.save();
                    results.channels.push.expired = true;
                  }
                })
                .catch((error) => {
                  logger.error(`Error sending push alert notification: ${error.message}`);
                  results.channels.push = { success: false, error: error.message };
                })
            );
            break;
            
          case 'price':
            promises.push(
              pushNotificationService.sendPriceUpdateNotification({
                subscription: user.pushSubscription,
                symbol: data.symbol,
                price: data.price,
                priceChangePercent: data.priceChangePercent,
              })
                .then((result) => {
                  results.channels.push = { success: true };
                  
                  // Check if subscription has expired
                  if (result.expired) {
                    // Remove expired subscription
                    user.pushSubscription = null;
                    user.save();
                    results.channels.push.expired = true;
                  }
                })
                .catch((error) => {
                  logger.error(`Error sending push price notification: ${error.message}`);
                  results.channels.push = { success: false, error: error.message };
                })
            );
            break;
            
          case 'news':
            promises.push(
              pushNotificationService.sendNewsNotification({
                subscription: user.pushSubscription,
                news: data,
              })
                .then((result) => {
                  results.channels.push = { success: true };
                  
                  // Check if subscription has expired
                  if (result.expired) {
                    // Remove expired subscription
                    user.pushSubscription = null;
                    user.save();
                    results.channels.push.expired = true;
                  }
                })
                .catch((error) => {
                  logger.error(`Error sending push news notification: ${error.message}`);
                  results.channels.push = { success: false, error: error.message };
                })
            );
            break;
            
          default:
            logger.warn(`Push notification not implemented for type: ${type}`);
            break;
        }
      }
      
      // Wait for all promises to resolve
      await Promise.all(promises);
      
      // Check if any channel succeeded
      const anySuccess = Object.values(results.channels).some((channel) => channel.success);
      results.success = anySuccess;
      
      if (!anySuccess) {
        results.message = 'Failed to send notification through any channel';
      }
      
      logger.info(`Notification sent to user ${userId} via ${Object.keys(results.channels).filter(channel => results.channels[channel].success).join(', ')}`);
      
      return results;
    } catch (error) {
      logger.error(`Error in notification service: ${error.message}`);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Send a notification to multiple users
   * @param {Object} options - Notification options
   * @param {Array} options.userIds - User IDs
   * @param {string} options.type - Notification type
   * @param {Array} options.channels - Notification channels
   * @param {Object} options.data - Notification data
   * @returns {Promise<Object>} Notification results
   */
  async sendBulkNotification(options) {
    const { userIds, ...notificationOptions } = options;
    
    const results = {
      success: true,
      total: userIds.length,
      succeeded: 0,
      failed: 0,
      errors: [],
    };
    
    // Send notification to each user
    for (const userId of userIds) {
      try {
        const result = await this.sendNotification({
          ...notificationOptions,
          userId,
        });
        
        if (result.success) {
          results.succeeded++;
        } else {
          results.failed++;
          results.errors.push({
            userId,
            error: result.message || 'Unknown error',
          });
        }
      } catch (error) {
        results.failed++;
        results.errors.push({
          userId,
          error: error.message,
        });
      }
    }
    
    results.success = results.succeeded > 0;
    
    logger.info(`Bulk notification sent to ${results.succeeded}/${results.total} users`);
    
    return results;
  }
}

// Create and export a singleton instance
const notificationService = new NotificationService();
export default notificationService; 