import News from '../models/News.js';
import Asset from '../models/Asset.js';
import TokenizedAsset from '../models/TokenizedAsset.js';
import AppError from '../utils/appError.js';
import { logger } from '../utils/logger.js';

// @desc    Get all news with pagination and filtering
// @route   GET /api/v1/news
// @access  Public
export const getNews = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 20;
    const sort = req.query.sort || '-publishedAt';
    
    // Build filter object
    const filter = {};
    
    if (req.query.category) {
      filter.categories = req.query.category;
    }
    
    if (req.query.tag) {
      filter.tags = req.query.tag;
    }
    
    if (req.query.search) {
      filter.$or = [
        { title: { $regex: req.query.search, $options: 'i' } },
        { summary: { $regex: req.query.search, $options: 'i' } },
        { content: { $regex: req.query.search, $options: 'i' } },
      ];
    }
    
    if (req.query.sentiment) {
      filter['sentiment.label'] = req.query.sentiment;
    }
    
    if (req.query.impact) {
      filter.impact = req.query.impact;
    }
    
    if (req.query.assetSymbol) {
      filter.$or = [
        { 'relatedAssets.symbol': req.query.assetSymbol },
        { 'relatedTokenizedAssets.symbol': req.query.assetSymbol },
      ];
    }
    
    if (req.query.featured === 'true') {
      filter.featured = true;
    }
    
    if (req.query.startDate && req.query.endDate) {
      filter.publishedAt = {
        $gte: new Date(req.query.startDate),
        $lte: new Date(req.query.endDate),
      };
    } else if (req.query.startDate) {
      filter.publishedAt = { $gte: new Date(req.query.startDate) };
    } else if (req.query.endDate) {
      filter.publishedAt = { $lte: new Date(req.query.endDate) };
    }
    
    // Execute query with pagination
    const result = await News.findNews(filter, page, limit, sort);
    
    res.status(200).json({
      success: true,
      count: result.news.length,
      pagination: result.pagination,
      data: result.news,
    });
  } catch (error) {
    logger.error(`Error getting news: ${error.message}`);
    next(error);
  }
};

// @desc    Get single news article
// @route   GET /api/v1/news/:id
// @access  Public
export const getNewsArticle = async (req, res, next) => {
  try {
    const news = await News.findById(req.params.id);
    
    if (!news) {
      return next(new AppError(`News article not found with id of ${req.params.id}`, 404));
    }
    
    // Increment view count
    await news.incrementViewCount();
    
    res.status(200).json({
      success: true,
      data: news,
    });
  } catch (error) {
    logger.error(`Error getting news article: ${error.message}`);
    next(error);
  }
};

// @desc    Create new news article
// @route   POST /api/v1/news
// @access  Private (Admin)
export const createNewsArticle = async (req, res, next) => {
  try {
    // Create news article
    const news = await News.create(req.body);
    
    // Log news creation
    logger.info(`News article created: ${news.title} by user ${req.user.id}`);
    
    res.status(201).json({
      success: true,
      data: news,
    });
  } catch (error) {
    logger.error(`Error creating news article: ${error.message}`);
    next(error);
  }
};

// @desc    Update news article
// @route   PUT /api/v1/news/:id
// @access  Private (Admin)
export const updateNewsArticle = async (req, res, next) => {
  try {
    let news = await News.findById(req.params.id);
    
    if (!news) {
      return next(new AppError(`News article not found with id of ${req.params.id}`, 404));
    }
    
    // Update news article
    news = await News.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    
    // Log news update
    logger.info(`News article updated: ${news.title} by user ${req.user.id}`);
    
    res.status(200).json({
      success: true,
      data: news,
    });
  } catch (error) {
    logger.error(`Error updating news article: ${error.message}`);
    next(error);
  }
};

// @desc    Delete news article
// @route   DELETE /api/v1/news/:id
// @access  Private (Admin)
export const deleteNewsArticle = async (req, res, next) => {
  try {
    const news = await News.findById(req.params.id);
    
    if (!news) {
      return next(new AppError(`News article not found with id of ${req.params.id}`, 404));
    }
    
    // Instead of deleting, mark as archived
    news.status = 'archived';
    await news.save();
    
    // Log news deletion
    logger.info(`News article archived: ${news.title} by user ${req.user.id}`);
    
    res.status(200).json({
      success: true,
      data: {},
    });
  } catch (error) {
    logger.error(`Error deleting news article: ${error.message}`);
    next(error);
  }
};

// @desc    Like news article
// @route   PUT /api/v1/news/:id/like
// @access  Private
export const likeNewsArticle = async (req, res, next) => {
  try {
    const news = await News.findById(req.params.id);
    
    if (!news) {
      return next(new AppError(`News article not found with id of ${req.params.id}`, 404));
    }
    
    // Increment like count
    await news.toggleLike(true);
    
    res.status(200).json({
      success: true,
      data: {
        likeCount: news.likeCount,
      },
    });
  } catch (error) {
    logger.error(`Error liking news article: ${error.message}`);
    next(error);
  }
};

// @desc    Unlike news article
// @route   PUT /api/v1/news/:id/unlike
// @access  Private
export const unlikeNewsArticle = async (req, res, next) => {
  try {
    const news = await News.findById(req.params.id);
    
    if (!news) {
      return next(new AppError(`News article not found with id of ${req.params.id}`, 404));
    }
    
    // Decrement like count
    await news.toggleLike(false);
    
    res.status(200).json({
      success: true,
      data: {
        likeCount: news.likeCount,
      },
    });
  } catch (error) {
    logger.error(`Error unliking news article: ${error.message}`);
    next(error);
  }
};

// @desc    Share news article
// @route   PUT /api/v1/news/:id/share
// @access  Private
export const shareNewsArticle = async (req, res, next) => {
  try {
    const news = await News.findById(req.params.id);
    
    if (!news) {
      return next(new AppError(`News article not found with id of ${req.params.id}`, 404));
    }
    
    // Increment share count
    await news.incrementShareCount();
    
    res.status(200).json({
      success: true,
      data: {
        shareCount: news.shareCount,
      },
    });
  } catch (error) {
    logger.error(`Error sharing news article: ${error.message}`);
    next(error);
  }
};

// @desc    Get trending news
// @route   GET /api/v1/news/trending
// @access  Public
export const getTrendingNews = async (req, res, next) => {
  try {
    const limit = parseInt(req.query.limit, 10) || 5;
    
    // Get trending news
    const trendingNews = await News.getTrendingNews(limit);
    
    res.status(200).json({
      success: true,
      count: trendingNews.length,
      data: trendingNews,
    });
  } catch (error) {
    logger.error(`Error getting trending news: ${error.message}`);
    next(error);
  }
};

// @desc    Get news by asset
// @route   GET /api/v1/news/asset/:symbol
// @access  Public
export const getNewsByAsset = async (req, res, next) => {
  try {
    const { symbol } = req.params;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    
    // Check if asset exists
    let asset;
    
    // Try to find in regular assets
    asset = await Asset.findOne({ symbol: symbol.toUpperCase() });
    
    // If not found, try tokenized assets
    if (!asset) {
      asset = await TokenizedAsset.findOne({ symbol: symbol.toUpperCase() });
    }
    
    if (!asset) {
      return next(new AppError(`Asset not found with symbol ${symbol}`, 404));
    }
    
    // Get news related to this asset
    const result = await News.findAssetNews(symbol.toUpperCase(), page, limit);
    
    res.status(200).json({
      success: true,
      count: result.news.length,
      pagination: result.pagination,
      data: result.news,
    });
  } catch (error) {
    logger.error(`Error getting news by asset: ${error.message}`);
    next(error);
  }
};

// @desc    Get news sentiment for asset
// @route   GET /api/v1/news/sentiment/:symbol
// @access  Public
export const getNewsSentiment = async (req, res, next) => {
  try {
    const { symbol } = req.params;
    const days = parseInt(req.query.days, 10) || 7;
    
    // Check if asset exists
    let asset;
    
    // Try to find in regular assets
    asset = await Asset.findOne({ symbol: symbol.toUpperCase() });
    
    // If not found, try tokenized assets
    if (!asset) {
      asset = await TokenizedAsset.findOne({ symbol: symbol.toUpperCase() });
    }
    
    if (!asset) {
      return next(new AppError(`Asset not found with symbol ${symbol}`, 404));
    }
    
    // Get sentiment data
    const sentiment = await News.getAssetSentiment(symbol.toUpperCase(), days);
    
    res.status(200).json({
      success: true,
      data: sentiment,
    });
  } catch (error) {
    logger.error(`Error getting news sentiment: ${error.message}`);
    next(error);
  }
};

// @desc    Get news categories and tags
// @route   GET /api/v1/news/metadata
// @access  Public
export const getNewsMetadata = async (req, res, next) => {
  try {
    // Get unique categories
    const categories = await News.distinct('categories');
    
    // Get unique tags
    const tags = await News.distinct('tags');
    
    // Get sources
    const sources = await News.distinct('source.name');
    
    res.status(200).json({
      success: true,
      data: {
        categories,
        tags,
        sources,
      },
    });
  } catch (error) {
    logger.error(`Error getting news metadata: ${error.message}`);
    next(error);
  }
}; 