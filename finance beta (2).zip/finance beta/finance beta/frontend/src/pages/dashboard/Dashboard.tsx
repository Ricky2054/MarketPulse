import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import styled from 'styled-components';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { fetchMarketData } from '../../store/slices/marketSlice';
import { fetchPortfolio } from '../../store/slices/portfolioSlice';
import { fetchAlerts } from '../../store/slices/alertsSlice';
import { RootState, AppDispatch } from '../../store';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const DashboardContainer = styled.div`
  padding: 20px;
`;

const DashboardHeader = styled.div`
  margin-bottom: 30px;
  
  h1 {
    font-size: 28px;
    color: #2c3e50;
    margin-bottom: 10px;
  }
  
  p {
    color: #7f8c8d;
    font-size: 16px;
  }
`;

const DashboardGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
`;

const Card = styled.div`
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 20px;
`;

const CardHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
  
  h2 {
    font-size: 18px;
    color: #2c3e50;
    margin: 0;
  }
  
  button {
    background: none;
    border: none;
    color: #3498db;
    cursor: pointer;
    font-size: 14px;
    
    &:hover {
      text-decoration: underline;
    }
  }
`;

const StatGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 15px;
`;

const StatItem = styled.div`
  h3 {
    font-size: 14px;
    color: #7f8c8d;
    margin: 0 0 5px 0;
  }
  
  p {
    font-size: 24px;
    font-weight: 600;
    color: #2c3e50;
    margin: 0;
  }
  
  .positive {
    color: #2ecc71;
  }
  
  .negative {
    color: #e74c3c;
  }
`;

const AssetList = styled.div`
  margin-top: 15px;
`;

const AssetItem = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 0;
  border-bottom: 1px solid #f1f1f1;
  
  &:last-child {
    border-bottom: none;
  }
  
  .asset-info {
    display: flex;
    align-items: center;
    
    img {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      margin-right: 10px;
    }
    
    .asset-name {
      h4 {
        font-size: 16px;
        margin: 0 0 3px 0;
        color: #2c3e50;
      }
      
      span {
        font-size: 12px;
        color: #7f8c8d;
      }
    }
  }
  
  .asset-price {
    text-align: right;
    
    p {
      font-size: 16px;
      font-weight: 600;
      margin: 0 0 3px 0;
      color: #2c3e50;
    }
    
    span {
      font-size: 12px;
      
      &.positive {
        color: #2ecc71;
      }
      
      &.negative {
        color: #e74c3c;
      }
    }
  }
`;

const AlertItem = styled.div`
  padding: 10px 0;
  border-bottom: 1px solid #f1f1f1;
  
  &:last-child {
    border-bottom: none;
  }
  
  h4 {
    font-size: 16px;
    margin: 0 0 5px 0;
    color: #2c3e50;
  }
  
  p {
    font-size: 14px;
    color: #7f8c8d;
    margin: 0;
  }
  
  .alert-time {
    font-size: 12px;
    color: #95a5a6;
    margin-top: 5px;
  }
`;

const ChartContainer = styled.div`
  height: 300px;
  margin-top: 15px;
`;

const Dashboard = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { user } = useSelector((state: RootState) => state.auth);
  const { assets, loading: marketLoading } = useSelector((state: RootState) => state.market);
  const { 
    positions, 
    totalValue, 
    totalProfitLoss, 
    totalProfitLossPercentage, 
    loading: portfolioLoading 
  } = useSelector((state: RootState) => state.portfolio);
  const { alerts, loading: alertsLoading } = useSelector((state: RootState) => state.alerts);
  
  useEffect(() => {
    dispatch(fetchMarketData());
    dispatch(fetchPortfolio());
    dispatch(fetchAlerts());
  }, [dispatch]);
  
  // Sample chart data
  const chartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Portfolio Value',
        data: [10000, 12000, 11500, 13000, 14500, 14000, 15000, 16500, 16000, 17500, 19000, 20000],
        borderColor: '#3498db',
        backgroundColor: 'rgba(52, 152, 219, 0.1)',
        tension: 0.4,
        fill: true,
      },
    ],
  };
  
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        mode: 'index',
        intersect: false,
      },
    },
    scales: {
      y: {
        beginAtZero: false,
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };
  
  return (
    <DashboardContainer>
      <DashboardHeader>
        <h1>Welcome back, {user?.name || 'Trader'}</h1>
        <p>Here's an overview of your portfolio and market insights</p>
      </DashboardHeader>
      
      <DashboardGrid>
        <Card>
          <CardHeader>
            <h2>Portfolio Summary</h2>
            <button>View All</button>
          </CardHeader>
          
          {portfolioLoading ? (
            <div>Loading portfolio data...</div>
          ) : (
            <>
              <StatGrid>
                <StatItem>
                  <h3>Total Value</h3>
                  <p>${totalValue?.toLocaleString() || '0.00'}</p>
                </StatItem>
                <StatItem>
                  <h3>Profit/Loss</h3>
                  <p className={totalProfitLoss >= 0 ? 'positive' : 'negative'}>
                    ${Math.abs(totalProfitLoss || 0).toLocaleString()} ({totalProfitLossPercentage || 0}%)
                  </p>
                </StatItem>
              </StatGrid>
              
              <ChartContainer>
                <Line data={chartData} options={chartOptions} />
              </ChartContainer>
            </>
          )}
        </Card>
        
        <Card>
          <CardHeader>
            <h2>Top Assets</h2>
            <button>View All</button>
          </CardHeader>
          
          {marketLoading ? (
            <div>Loading market data...</div>
          ) : (
            <AssetList>
              {assets.slice(0, 5).map((asset) => (
                <AssetItem key={asset.id}>
                  <div className="asset-info">
                    <img src={asset.imageUrl || `https://via.placeholder.com/30?text=${asset.symbol}`} alt={asset.name} />
                    <div className="asset-name">
                      <h4>{asset.name}</h4>
                      <span>{asset.symbol}</span>
                    </div>
                  </div>
                  <div className="asset-price">
                    <p>${asset.price.toLocaleString()}</p>
                    <span className={asset.change24h >= 0 ? 'positive' : 'negative'}>
                      {asset.change24h >= 0 ? '+' : ''}{asset.change24h}%
                    </span>
                  </div>
                </AssetItem>
              ))}
            </AssetList>
          )}
        </Card>
        
        <Card>
          <CardHeader>
            <h2>Recent Alerts</h2>
            <button>View All</button>
          </CardHeader>
          
          {alertsLoading ? (
            <div>Loading alerts...</div>
          ) : (
            <div>
              {alerts.length > 0 ? (
                alerts.slice(0, 5).map((alert) => (
                  <AlertItem key={alert.id}>
                    <h4>{alert.asset.name} ({alert.asset.symbol})</h4>
                    <p>{alert.message || `${alert.type.charAt(0).toUpperCase() + alert.type.slice(1)} alert triggered`}</p>
                    <div className="alert-time">
                      {new Date(alert.triggeredAt || alert.createdAt).toLocaleString()}
                    </div>
                  </AlertItem>
                ))
              ) : (
                <p>No recent alerts</p>
              )}
            </div>
          )}
        </Card>
        
        <Card>
          <CardHeader>
            <h2>Market Insights</h2>
            <button>View All</button>
          </CardHeader>
          
          <div>
            <p>AI-powered market analysis and predictions will be displayed here.</p>
            <p>This feature is coming soon in the next update.</p>
          </div>
        </Card>
      </DashboardGrid>
    </DashboardContainer>
  );
};

export default Dashboard; 