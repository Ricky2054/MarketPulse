import express from 'express';
import {
  getTokenizedAssets,
  getTokenizedAsset,
  createTokenizedAsset,
  updateTokenizedAsset,
  deleteTokenizedAsset,
  buyTokenizedAsset,
  sellTokenizedAsset,
} from '../controllers/tokenizedAssetController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { validate, schemas } from '../utils/validator.js';

const router = express.Router();

// Public routes
router.get('/', getTokenizedAssets);
router.get('/:symbol', getTokenizedAsset);

// Protected routes
router.use(authenticate);
router.post('/:symbol/buy', buyTokenizedAsset);
router.post('/:symbol/sell', sellTokenizedAsset);

// Admin routes
router.post('/', authorize('admin'), validate(schemas.tokenizedAssetCreate), createTokenizedAsset);
router.put('/:symbol', authorize('admin'), validate(schemas.tokenizedAssetUpdate), updateTokenizedAsset);
router.delete('/:symbol', authorize('admin'), deleteTokenizedAsset);

export default router; 