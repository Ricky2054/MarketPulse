import mongoose from 'mongoose';

const TransactionSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    portfolioId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Portfolio',
      required: true,
      index: true,
    },
    assetId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Asset',
      required: true,
      index: true,
    },
    type: {
      type: String,
      enum: ['buy', 'sell', 'transfer_in', 'transfer_out', 'dividend', 'interest', 'fee', 'tokenization', 'detokenization'],
      required: true,
      index: true,
    },
    status: {
      type: String,
      enum: ['pending', 'completed', 'failed', 'cancelled'],
      default: 'pending',
      index: true,
    },
    quantity: {
      type: Number,
      required: true,
    },
    price: {
      type: Number,
      required: true,
      min: [0, 'Price cannot be negative'],
    },
    totalAmount: {
      type: Number,
      required: true,
    },
    fee: {
      type: Number,
      default: 0,
      min: [0, 'Fee cannot be negative'],
    },
    date: {
      type: Date,
      default: Date.now,
      index: true,
    },
    paymentMethod: {
      type: String,
      enum: ['bank_transfer', 'credit_card', 'debit_card', 'crypto_wallet', 'internal_balance'],
      required: function() {
        return ['buy', 'sell'].includes(this.type);
      },
    },
    paymentDetails: {
      accountId: String,
      transactionId: String,
      provider: String,
    },
    blockchain: {
      network: String,
      txHash: String,
      blockNumber: Number,
      confirmations: Number,
      gasUsed: Number,
      gasFee: Number,
    },
    notes: {
      type: String,
    },
    tags: [String],
    metadata: {
      type: mongoose.Schema.Types.Mixed,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Compound index for faster queries
TransactionSchema.index({ userId: 1, date: -1 });
TransactionSchema.index({ portfolioId: 1, date: -1 });
TransactionSchema.index({ assetId: 1, date: -1 });
TransactionSchema.index({ userId: 1, assetId: 1, date: -1 });

// Virtual for profit/loss (for sell transactions)
TransactionSchema.virtual('profitLoss').get(function () {
  if (this.type === 'sell' && this._acquisitionCost) {
    return this.totalAmount - this._acquisitionCost - this.fee;
  }
  return null;
});

// Method to set acquisition cost for calculating profit/loss
TransactionSchema.methods.setAcquisitionCost = function (cost) {
  this._acquisitionCost = cost;
  return this;
};

// Static method to find user transactions with pagination
TransactionSchema.statics.findUserTransactions = async function (
  userId,
  filters = {},
  page = 1,
  limit = 20,
  sort = { date: -1 }
) {
  const query = { userId, ...filters };
  
  const total = await this.countDocuments(query);
  const transactions = await this.find(query)
    .sort(sort)
    .skip((page - 1) * limit)
    .limit(limit)
    .populate('assetId', 'name symbol type price')
    .populate('portfolioId', 'name');
  
  return {
    transactions,
    pagination: {
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    },
  };
};

// Static method to get transaction statistics
TransactionSchema.statics.getTransactionStats = async function (userId, period = 30) {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - period);
  
  const stats = await this.aggregate([
    {
      $match: {
        userId: mongoose.Types.ObjectId(userId),
        date: { $gte: startDate },
        status: 'completed',
      },
    },
    {
      $group: {
        _id: '$type',
        count: { $sum: 1 },
        totalAmount: { $sum: '$totalAmount' },
        totalFees: { $sum: '$fee' },
      },
    },
  ]);
  
  // Format the results
  const formattedStats = {
    totalTransactions: 0,
    totalVolume: 0,
    totalFees: 0,
    byType: {},
  };
  
  stats.forEach((stat) => {
    formattedStats.totalTransactions += stat.count;
    formattedStats.totalVolume += stat.totalAmount;
    formattedStats.totalFees += stat.totalFees;
    
    formattedStats.byType[stat._id] = {
      count: stat.count,
      totalAmount: stat.totalAmount,
      totalFees: stat.totalFees,
    };
  });
  
  return formattedStats;
};

// Pre-save middleware to calculate total amount if not provided
TransactionSchema.pre('save', function (next) {
  if (!this.totalAmount && this.quantity && this.price) {
    this.totalAmount = this.quantity * this.price;
  }
  next();
});

const Transaction = mongoose.model('Transaction', TransactionSchema);

export default Transaction; 