import Joi from 'joi';
import AppError from './appError.js';

/**
 * Validate request data against a schema
 * @param {Object} schema - Joi schema
 * @param {string} property - Request property to validate (body, params, query)
 * @returns {Function} Express middleware
 */
export const validate = (schema, property = 'body') => {
  return (req, res, next) => {
    const { error } = schema.validate(req[property], {
      abortEarly: false,
      stripUnknown: true,
    });

    if (!error) {
      return next();
    }

    const errors = error.details.reduce((acc, curr) => {
      acc[curr.path[0]] = curr.message.replace(/['"]/g, '');
      return acc;
    }, {});

    return next(new AppError('Validation error', 400, true, errors));
  };
};

/**
 * Common validation schemas
 */
export const schemas = {
  // User schemas
  userRegister: Joi.object({
    name: Joi.string().min(2).max(50).required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required(),
    confirmPassword: Joi.string().valid(Joi.ref('password')).required().messages({
      'any.only': 'Passwords do not match',
    }),
  }),

  userLogin: Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
  }),

  userUpdate: Joi.object({
    name: Joi.string().min(2).max(50),
    email: Joi.string().email(),
    phone: Joi.string(),
    country: Joi.string(),
    preferences: Joi.object(),
  }),

  passwordChange: Joi.object({
    currentPassword: Joi.string().required(),
    newPassword: Joi.string().min(6).required(),
    confirmPassword: Joi.string().valid(Joi.ref('newPassword')).required().messages({
      'any.only': 'Passwords do not match',
    }),
  }),

  // Asset schemas
  assetCreate: Joi.object({
    symbol: Joi.string().required(),
    name: Joi.string().required(),
    type: Joi.string().valid('crypto', 'stock', 'tokenized', 'forex', 'commodity', 'index').required(),
    price: Joi.number().min(0).required(),
    priceChange24h: Joi.number(),
    priceChangePercent24h: Joi.number(),
    volume24h: Joi.number().min(0),
    marketCap: Joi.number().min(0),
    circulatingSupply: Joi.number().min(0),
    totalSupply: Joi.number().min(0),
    maxSupply: Joi.number().min(0),
    imageUrl: Joi.string().uri(),
    description: Joi.string(),
    website: Joi.string().uri(),
    whitepaper: Joi.string().uri(),
    explorer: Joi.string().uri(),
    social: Joi.object(),
    tags: Joi.array().items(Joi.string()),
    isActive: Joi.boolean(),
    isVerified: Joi.boolean(),
    tokenomics: Joi.object(),
  }),

  assetUpdate: Joi.object({
    name: Joi.string(),
    type: Joi.string().valid('crypto', 'stock', 'tokenized', 'forex', 'commodity', 'index'),
    price: Joi.number().min(0),
    priceChange24h: Joi.number(),
    priceChangePercent24h: Joi.number(),
    volume24h: Joi.number().min(0),
    marketCap: Joi.number().min(0),
    circulatingSupply: Joi.number().min(0),
    totalSupply: Joi.number().min(0),
    maxSupply: Joi.number().min(0),
    imageUrl: Joi.string().uri(),
    description: Joi.string(),
    website: Joi.string().uri(),
    whitepaper: Joi.string().uri(),
    explorer: Joi.string().uri(),
    social: Joi.object(),
    tags: Joi.array().items(Joi.string()),
    isActive: Joi.boolean(),
    isVerified: Joi.boolean(),
    tokenomics: Joi.object(),
  }),

  // Tokenized asset schemas
  tokenizedAssetCreate: Joi.object({
    symbol: Joi.string().required(),
    name: Joi.string().required(),
    underlyingAssetType: Joi.string().valid('real_estate', 'art', 'collectible', 'commodity', 'equity', 'fund', 'other').required(),
    tokenPrice: Joi.number().min(0).required(),
    totalSupply: Joi.number().min(0).required(),
    circulatingSupply: Joi.number().min(0).required(),
    marketCap: Joi.number().min(0),
    issuer: Joi.string().required(),
    description: Joi.string(),
    imageUrl: Joi.string().uri(),
    documentUrl: Joi.string().uri(),
    website: Joi.string().uri(),
    isActive: Joi.boolean(),
    isVerified: Joi.boolean(),
    assetDetails: Joi.object(),
    dividendYield: Joi.number().min(0),
    dividendSchedule: Joi.string(),
    fees: Joi.object(),
    restrictions: Joi.object(),
  }),

  tokenizedAssetUpdate: Joi.object({
    name: Joi.string(),
    underlyingAssetType: Joi.string().valid('real_estate', 'art', 'collectible', 'commodity', 'equity', 'fund', 'other'),
    tokenPrice: Joi.number().min(0),
    totalSupply: Joi.number().min(0),
    circulatingSupply: Joi.number().min(0),
    marketCap: Joi.number().min(0),
    issuer: Joi.string(),
    description: Joi.string(),
    imageUrl: Joi.string().uri(),
    documentUrl: Joi.string().uri(),
    website: Joi.string().uri(),
    isActive: Joi.boolean(),
    isVerified: Joi.boolean(),
    assetDetails: Joi.object(),
    dividendYield: Joi.number().min(0),
    dividendSchedule: Joi.string(),
    fees: Joi.object(),
    restrictions: Joi.object(),
  }),

  // Portfolio schemas
  portfolioCreate: Joi.object({
    name: Joi.string().required(),
    description: Joi.string(),
    isPublic: Joi.boolean(),
  }),

  portfolioUpdate: Joi.object({
    name: Joi.string(),
    description: Joi.string(),
    isPublic: Joi.boolean(),
  }),

  portfolioAddAsset: Joi.object({
    symbol: Joi.string().required(),
    quantity: Joi.number().min(0).required(),
    purchasePrice: Joi.number().min(0).required(),
    purchaseDate: Joi.date().iso(),
    notes: Joi.string(),
  }),

  portfolioUpdateAsset: Joi.object({
    quantity: Joi.number().min(0),
    purchasePrice: Joi.number().min(0),
    purchaseDate: Joi.date().iso(),
    notes: Joi.string(),
  }),

  // Transaction schemas
  transactionCreate: Joi.object({
    type: Joi.string().valid('buy', 'sell', 'transfer', 'dividend', 'fee', 'other').required(),
    symbol: Joi.string().required(),
    quantity: Joi.number().min(0).required(),
    price: Joi.number().min(0).required(),
    totalAmount: Joi.number().min(0).required(),
    fee: Joi.number().min(0),
    date: Joi.date().iso(),
    notes: Joi.string(),
    portfolioId: Joi.string().required(),
  }),

  transactionUpdate: Joi.object({
    type: Joi.string().valid('buy', 'sell', 'transfer', 'dividend', 'fee', 'other'),
    symbol: Joi.string(),
    quantity: Joi.number().min(0),
    price: Joi.number().min(0),
    totalAmount: Joi.number().min(0),
    fee: Joi.number().min(0),
    date: Joi.date().iso(),
    notes: Joi.string(),
    portfolioId: Joi.string(),
  }),

  // Alert schemas
  alertCreate: Joi.object({
    type: Joi.string().valid('price', 'news', 'technical', 'portfolio', 'system').required(),
    symbol: Joi.string().when('type', {
      is: Joi.string().valid('price', 'news', 'technical'),
      then: Joi.required(),
      otherwise: Joi.optional(),
    }),
    condition: Joi.string().valid('above', 'below', 'percent_change', 'volume_spike', 'news_sentiment', 'portfolio_change').required(),
    threshold: Joi.number().when('condition', {
      is: Joi.string().valid('above', 'below', 'percent_change', 'volume_spike', 'portfolio_change'),
      then: Joi.required(),
      otherwise: Joi.optional(),
    }),
    message: Joi.string(),
    isActive: Joi.boolean(),
    expiresAt: Joi.date().iso(),
    notificationChannels: Joi.array().items(Joi.string().valid('email', 'sms', 'push', 'in_app')),
  }),

  alertUpdate: Joi.object({
    condition: Joi.string().valid('above', 'below', 'percent_change', 'volume_spike', 'news_sentiment', 'portfolio_change'),
    threshold: Joi.number(),
    message: Joi.string(),
    isActive: Joi.boolean(),
    expiresAt: Joi.date().iso(),
    notificationChannels: Joi.array().items(Joi.string().valid('email', 'sms', 'push', 'in_app')),
  }),

  // Market data schemas
  marketDataUpdate: Joi.object({
    symbol: Joi.string().required(),
    dataType: Joi.string().valid('ohlcv', 'ticker', 'technical', 'insight').required(),
    interval: Joi.string().when('dataType', {
      is: 'ohlcv',
      then: Joi.string().valid('1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w', '1M').required(),
      otherwise: Joi.optional(),
    }),
    timestamp: Joi.date().iso(),
    source: Joi.string().required(),
    ohlcv: Joi.object({
      open: Joi.number().required(),
      high: Joi.number().required(),
      low: Joi.number().required(),
      close: Joi.number().required(),
      volume: Joi.number().required(),
    }).when('dataType', {
      is: 'ohlcv',
      then: Joi.required(),
      otherwise: Joi.optional(),
    }),
    ticker: Joi.object({
      price: Joi.number().required(),
      volume24h: Joi.number().required(),
      priceChange24h: Joi.number(),
      priceChangePercent24h: Joi.number(),
      marketCap: Joi.number(),
      high24h: Joi.number(),
      low24h: Joi.number(),
    }).when('dataType', {
      is: 'ticker',
      then: Joi.required(),
      otherwise: Joi.optional(),
    }),
    technical: Joi.object().when('dataType', {
      is: 'technical',
      then: Joi.required(),
      otherwise: Joi.optional(),
    }),
    insight: Joi.object().when('dataType', {
      is: 'insight',
      then: Joi.required(),
      otherwise: Joi.optional(),
    }),
  }),

  // News schemas
  newsCreate: Joi.object({
    title: Joi.string().required(),
    content: Joi.string().required(),
    summary: Joi.string().required(),
    source: Joi.string().required(),
    sourceUrl: Joi.string().uri().required(),
    imageUrl: Joi.string().uri(),
    publishedAt: Joi.date().iso(),
    author: Joi.string(),
    category: Joi.string(),
    tags: Joi.array().items(Joi.string()),
    relatedAssets: Joi.array().items(Joi.string()),
    sentiment: Joi.object({
      score: Joi.number().min(-1).max(1),
      label: Joi.string().valid('positive', 'neutral', 'negative'),
      confidence: Joi.number().min(0).max(1),
    }),
    impact: Joi.string().valid('high', 'medium', 'low'),
  }),

  newsUpdate: Joi.object({
    title: Joi.string(),
    content: Joi.string(),
    summary: Joi.string(),
    source: Joi.string(),
    sourceUrl: Joi.string().uri(),
    imageUrl: Joi.string().uri(),
    publishedAt: Joi.date().iso(),
    author: Joi.string(),
    category: Joi.string(),
    tags: Joi.array().items(Joi.string()),
    relatedAssets: Joi.array().items(Joi.string()),
    sentiment: Joi.object({
      score: Joi.number().min(-1).max(1),
      label: Joi.string().valid('positive', 'neutral', 'negative'),
      confidence: Joi.number().min(0).max(1),
    }),
    impact: Joi.string().valid('high', 'medium', 'low'),
    isArchived: Joi.boolean(),
  }),
};

/**
 * Validate MongoDB ObjectId
 * @param {string} id - ObjectId to validate
 * @returns {boolean} Whether the id is valid
 */
export const isValidObjectId = (id) => {
  return /^[0-9a-fA-F]{24}$/.test(id);
}; 