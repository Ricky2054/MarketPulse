import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styled from 'styled-components';

const SidebarContainer = styled.aside<{ collapsed: boolean }>`
  width: ${(props) => (props.collapsed ? '80px' : '250px')};
  height: 100vh;
  background-color: #2c3e50;
  color: #ecf0f1;
  transition: width 0.3s ease;
  overflow-x: hidden;
`;

const SidebarHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px;
  border-bottom: 1px solid #34495e;
`;

const Logo = styled.div<{ collapsed: boolean }>`
  font-size: ${(props) => (props.collapsed ? '0' : '20px')};
  font-weight: bold;
  white-space: nowrap;
  overflow: hidden;
  transition: font-size 0.3s ease;
`;

const ToggleButton = styled.button`
  background: none;
  border: none;
  color: #ecf0f1;
  cursor: pointer;
  font-size: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  
  &:focus {
    outline: none;
  }
`;

const NavMenu = styled.nav`
  margin-top: 20px;
`;

const NavItem = styled(NavLink)<{ collapsed: boolean }>`
  display: flex;
  align-items: center;
  padding: ${(props) => (props.collapsed ? '15px 0' : '15px 20px')};
  justify-content: ${(props) => (props.collapsed ? 'center' : 'flex-start')};
  text-decoration: none;
  color: #ecf0f1;
  transition: background-color 0.2s;
  
  &:hover {
    background-color: #34495e;
  }
  
  &.active {
    background-color: #3498db;
    
    svg {
      color: #ffffff;
    }
  }
  
  svg {
    margin-right: ${(props) => (props.collapsed ? '0' : '15px')};
    font-size: 20px;
    color: #bdc3c7;
  }
  
  span {
    white-space: nowrap;
    display: ${(props) => (props.collapsed ? 'none' : 'inline')};
  }
`;

const SidebarFooter = styled.div<{ collapsed: boolean }>`
  position: absolute;
  bottom: 0;
  width: 100%;
  padding: ${(props) => (props.collapsed ? '15px 0' : '15px 20px')};
  border-top: 1px solid #34495e;
  text-align: ${(props) => (props.collapsed ? 'center' : 'left')};
  font-size: 12px;
`;

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  
  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };
  
  return (
    <SidebarContainer collapsed={collapsed}>
      <SidebarHeader>
        <Logo collapsed={collapsed}>MarketPulse</Logo>
        <ToggleButton onClick={toggleSidebar}>
          {collapsed ? (
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="13 17 18 12 13 7"></polyline>
              <polyline points="6 17 11 12 6 7"></polyline>
            </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="11 17 6 12 11 7"></polyline>
              <polyline points="18 17 13 12 18 7"></polyline>
            </svg>
          )}
        </ToggleButton>
      </SidebarHeader>
      
      <NavMenu>
        <NavItem to="/" collapsed={collapsed} className={location.pathname === '/' ? 'active' : ''}>
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="3" width="7" height="7"></rect>
            <rect x="14" y="3" width="7" height="7"></rect>
            <rect x="14" y="14" width="7" height="7"></rect>
            <rect x="3" y="14" width="7" height="7"></rect>
          </svg>
          <span>Dashboard</span>
        </NavItem>
        
        <NavItem to="/trading" collapsed={collapsed} className={location.pathname.includes('/trading') ? 'active' : ''}>
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
            <polyline points="16 7 22 7 22 13"></polyline>
          </svg>
          <span>Trading</span>
        </NavItem>
        
        <NavItem to="/analytics" collapsed={collapsed} className={location.pathname.includes('/analytics') ? 'active' : ''}>
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21.21 15.89A10 10 0 1 1 8 2.83"></path>
            <path d="M22 12A10 10 0 0 0 12 2v10z"></path>
          </svg>
          <span>Analytics</span>
        </NavItem>
        
        <NavItem to="/tokenization" collapsed={collapsed} className={location.pathname.includes('/tokenization') ? 'active' : ''}>
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
            <circle cx="12" cy="12" r="3"></circle>
          </svg>
          <span>Tokenization</span>
        </NavItem>
        
        <NavItem to="/portfolio" collapsed={collapsed} className={location.pathname.includes('/portfolio') ? 'active' : ''}>
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 4H3a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"></path>
            <path d="M16 2v4"></path>
            <path d="M8 2v4"></path>
            <path d="M3 10h18"></path>
          </svg>
          <span>Portfolio</span>
        </NavItem>
        
        <NavItem to="/alerts" collapsed={collapsed} className={location.pathname.includes('/alerts') ? 'active' : ''}>
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
          </svg>
          <span>Alerts</span>
        </NavItem>
      </NavMenu>
      
      <SidebarFooter collapsed={collapsed}>
        <span>© 2023 MarketPulse</span>
      </SidebarFooter>
    </SidebarContainer>
  );
};

export default Sidebar; 