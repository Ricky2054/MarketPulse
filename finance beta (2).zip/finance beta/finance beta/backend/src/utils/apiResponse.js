/**
 * Standard API response format
 * @class ApiResponse
 */
class ApiResponse {
  /**
   * Create a success response
   * @param {Object} data - Response data
   * @param {string} message - Success message
   * @param {number} statusCode - HTTP status code
   * @returns {Object} Response object
   */
  static success(data = null, message = 'Operation successful', statusCode = 200) {
    return {
      success: true,
      message,
      statusCode,
      data,
    };
  }

  /**
   * Create an error response
   * @param {string} message - Error message
   * @param {number} statusCode - HTTP status code
   * @param {Object} errors - Detailed errors
   * @returns {Object} Response object
   */
  static error(message = 'Operation failed', statusCode = 500, errors = null) {
    return {
      success: false,
      message,
      statusCode,
      errors,
    };
  }

  /**
   * Create a paginated response
   * @param {Array} data - Response data
   * @param {number} page - Current page
   * @param {number} limit - Items per page
   * @param {number} total - Total items
   * @param {string} message - Success message
   * @param {number} statusCode - HTTP status code
   * @returns {Object} Response object
   */
  static paginate(data, page, limit, total, message = 'Operation successful', statusCode = 200) {
    const totalPages = Math.ceil(total / limit);
    const hasNext = page < totalPages;
    const hasPrev = page > 1;

    return {
      success: true,
      message,
      statusCode,
      data,
      pagination: {
        page,
        limit,
        total,
        totalPages,
        hasNext,
        hasPrev,
        nextPage: hasNext ? page + 1 : null,
        prevPage: hasPrev ? page - 1 : null,
      },
    };
  }
}

export default ApiResponse; 