import jwt from 'jsonwebtoken';
import bcryptjs from 'bcryptjs';
import crypto from 'crypto';
import User from '../models/User.js';
import AppError from '../utils/appError.js';
import sendEmail from '../utils/sendEmail.js';
import { redisClient } from '../config/redis.js';
import { logger } from '../utils/logger.js';
import emailService from '../utils/emailService.js';

// Generate JWT token
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN,
  });
};

// Send token response
const sendTokenResponse = (user, statusCode, res) => {
  const token = generateToken(user._id);
  
  const cookieOptions = {
    expires: new Date(
      Date.now() + process.env.JWT_COOKIE_EXPIRES_IN * 24 * 60 * 60 * 1000
    ),
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
  };
  
  // Remove password from response
  user.password = undefined;
  
  res
    .status(statusCode)
    .cookie('token', token, cookieOptions)
    .json({
      success: true,
      token,
      user,
    });
};

// @desc    Register user
// @route   POST /api/v1/auth/register
// @access  Public
export const register = async (req, res, next) => {
  try {
    const { name, email, password } = req.body;
    
    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return next(new AppError('Email already in use', 400));
    }
    
    // Create verification token
    const verificationToken = crypto.randomBytes(20).toString('hex');
    const verificationTokenExpire = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
    
    // Create user
    const user = await User.create({
      name,
      email,
      password,
      verificationToken,
      verificationTokenExpire,
    });
    
    // Remove password from response
    user.password = undefined;
    
    // Send verification email
    const verificationUrl = `${req.protocol}://${req.get(
      'host'
    )}/api/v1/auth/verify-email/${verificationToken}`;
    
    try {
      await emailService.sendWelcomeEmail({
        email: user.email,
        name: user.name,
        verificationUrl,
      });
      
      logger.info(`Verification email sent to ${user.email}`);
    } catch (error) {
      logger.error(`Error sending verification email: ${error.message}`);
      // Don't return error to client, just log it
    }
    
    res.status(201).json({
      success: true,
      message: 'User registered successfully. Please verify your email.',
      data: user,
    });
  } catch (error) {
    logger.error(`Registration error: ${error.message}`);
    next(error);
  }
};

// @desc    Login user
// @route   POST /api/v1/auth/login
// @access  Public
export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    
    // Check if email and password exist
    if (!email || !password) {
      return next(new AppError('Please provide email and password', 400));
    }
    
    // Check if user exists and password is correct
    const user = await User.findOne({ email }).select('+password');
    
    if (!user || !(await user.matchPassword(password))) {
      return next(new AppError('Invalid credentials', 401));
    }
    
    // Check if user is verified
    if (!user.isVerified) {
      return next(new AppError('Please verify your email to login', 401));
    }
    
    // Generate token
    const token = user.getSignedJwtToken();
    
    // Remove password from response
    user.password = undefined;
    
    // Set cookie options
    const cookieOptions = {
      expires: new Date(Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000),
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
    };
    
    res.status(200)
      .cookie('token', token, cookieOptions)
      .json({
        success: true,
        token,
        data: user,
      });
  } catch (error) {
    logger.error(`Login error: ${error.message}`);
    next(error);
  }
};

// @desc    Logout user
// @route   POST /api/v1/auth/logout
// @access  Private
export const logout = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (token) {
      // Get token expiration time
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const exp = decoded.exp;
      const now = Math.floor(Date.now() / 1000);
      const timeToExpire = exp - now;
      
      // Add token to blacklist in Redis
      if (timeToExpire > 0) {
        await redisClient.set(`blacklist_${token}`, 'true', {
          EX: timeToExpire,
        });
      }
    }
    
    res.status(200)
      .cookie('token', 'none', {
        expires: new Date(Date.now() + 10 * 1000),
        httpOnly: true,
      })
      .json({
        success: true,
        message: 'User logged out successfully',
      });
  } catch (error) {
    logger.error(`Logout error: ${error.message}`);
    next(error);
  }
};

// @desc    Get current logged in user
// @route   GET /api/v1/auth/me
// @access  Private
export const getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    
    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    logger.error(`Get me error: ${error.message}`);
    next(error);
  }
};

// @desc    Update user details
// @route   PUT /api/v1/auth/updatedetails
// @access  Private
export const updateDetails = async (req, res, next) => {
  try {
    const fieldsToUpdate = {
      name: req.body.name,
      email: req.body.email,
    };
    
    // Remove undefined fields
    Object.keys(fieldsToUpdate).forEach(
      (key) => fieldsToUpdate[key] === undefined && delete fieldsToUpdate[key]
    );
    
    // Check if email is being updated and if it already exists
    if (fieldsToUpdate.email) {
      const existingUser = await User.findOne({ email: fieldsToUpdate.email });
      if (existingUser && existingUser._id.toString() !== req.user.id) {
        return next(new AppError('Email already in use', 400));
      }
    }
    
    const user = await User.findByIdAndUpdate(req.user.id, fieldsToUpdate, {
      new: true,
      runValidators: true,
    });
    
    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    logger.error(`Update details error: ${error.message}`);
    next(error);
  }
};

// @desc    Update password
// @route   PUT /api/v1/auth/update-password
// @access  Private
export const updatePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    // Get user with password
    const user = await User.findById(req.user.id).select('+password');
    
    // Check current password
    if (!(await user.matchPassword(currentPassword))) {
      return next(new AppError('Current password is incorrect', 401));
    }
    
    // Update password
    user.password = newPassword;
    await user.save();
    
    // Generate new token
    const token = user.getSignedJwtToken();
    
    // Remove password from response
    user.password = undefined;
    
    // Set cookie options
    const cookieOptions = {
      expires: new Date(Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000),
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
    };
    
    res.status(200)
      .cookie('token', token, cookieOptions)
      .json({
        success: true,
        message: 'Password updated successfully',
        token,
        data: user,
      });
  } catch (error) {
    logger.error(`Update password error: ${error.message}`);
    next(error);
  }
};

// @desc    Forgot password
// @route   POST /api/v1/auth/forgot-password
// @access  Public
export const forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    
    // Find user by email
    const user = await User.findOne({ email });
    
    if (!user) {
      return next(new AppError('There is no user with that email', 404));
    }
    
    // Get reset token
    const resetToken = user.getResetPasswordToken();
    await user.save({ validateBeforeSave: false });
    
    // Create reset URL
    const resetUrl = `${req.protocol}://${req.get(
      'host'
    )}/api/v1/auth/reset-password/${resetToken}`;
    
    try {
      await emailService.sendPasswordResetEmail({
        email: user.email,
        name: user.name,
        resetToken,
        resetUrl,
      });
      
      res.status(200).json({
        success: true,
        message: 'Password reset email sent',
      });
    } catch (error) {
      user.resetPasswordToken = undefined;
      user.resetPasswordExpire = undefined;
      await user.save({ validateBeforeSave: false });
      
      logger.error(`Error sending password reset email: ${error.message}`);
      return next(new AppError('Email could not be sent', 500));
    }
  } catch (error) {
    logger.error(`Forgot password error: ${error.message}`);
    next(error);
  }
};

// @desc    Reset password
// @route   PUT /api/v1/auth/reset-password/:resetToken
// @access  Public
export const resetPassword = async (req, res, next) => {
  try {
    // Get hashed token
    const resetPasswordToken = crypto
      .createHash('sha256')
      .update(req.params.resetToken)
      .digest('hex');
    
    // Find user by reset token
    const user = await User.findOne({
      resetPasswordToken,
      resetPasswordExpire: { $gt: Date.now() },
    });
    
    if (!user) {
      return next(new AppError('Invalid or expired token', 400));
    }
    
    // Set new password
    user.password = req.body.password;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpire = undefined;
    await user.save();
    
    res.status(200).json({
      success: true,
      message: 'Password reset successful',
    });
  } catch (error) {
    logger.error(`Reset password error: ${error.message}`);
    next(error);
  }
};

// @desc    Verify email
// @route   GET /api/v1/auth/verify-email/:verificationToken
// @access  Public
export const verifyEmail = async (req, res, next) => {
  try {
    // Find user by verification token
    const user = await User.findOne({
      verificationToken: req.params.verificationToken,
      verificationTokenExpire: { $gt: Date.now() },
    });
    
    if (!user) {
      return next(new AppError('Invalid or expired token', 400));
    }
    
    // Update user
    user.isVerified = true;
    user.verificationToken = undefined;
    user.verificationTokenExpire = undefined;
    await user.save();
    
    res.status(200).json({
      success: true,
      message: 'Email verified successfully',
    });
  } catch (error) {
    logger.error(`Verify email error: ${error.message}`);
    next(error);
  }
};

// @desc    Resend verification email
// @route   POST /api/v1/auth/resend-verification
// @access  Public
export const resendVerification = async (req, res, next) => {
  try {
    const { email } = req.body;
    
    // Check if email exists
    if (!email) {
      return next(new AppError('Please provide an email', 400));
    }
    
    const user = await User.findOne({ email });
    
    if (!user) {
      return next(new AppError('No user found with that email', 404));
    }
    
    if (user.isVerified) {
      return next(new AppError('Email already verified', 400));
    }
    
    // Create verification token
    const verificationToken = crypto.randomBytes(20).toString('hex');
    user.verificationToken = verificationToken;
    user.verificationTokenExpire = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
    await user.save({ validateBeforeSave: false });
    
    // Create verification URL
    const verificationUrl = `${req.protocol}://${req.get(
      'host'
    )}/api/v1/auth/verify-email/${verificationToken}`;
    
    const message = `
      <h1>Email Verification</h1>
      <p>Please verify your email by clicking on the link below:</p>
      <a href="${verificationUrl}" target="_blank">Verify Email</a>
    `;
    
    try {
      await sendEmail({
        email: user.email,
        subject: 'Email Verification',
        message,
      });
      
      res.status(200).json({
        success: true,
        message: 'Verification email sent',
      });
    } catch (error) {
      user.verificationToken = undefined;
      user.verificationTokenExpire = undefined;
      await user.save({ validateBeforeSave: false });
      
      logger.error(`Email could not be sent: ${error.message}`);
      return next(new AppError('Email could not be sent', 500));
    }
  } catch (error) {
    logger.error(`Resend verification error: ${error.message}`);
    next(error);
  }
}; 