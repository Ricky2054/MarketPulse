import express from 'express';
import {
  getOHLCVData,
  getTickerData,
  getMarketSummaries,
  getTechnicalIndicators,
  getAIInsights,
  updateMarketData,
  batchUpdateMarketData,
} from '../controllers/marketDataController.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// Public routes
router.get('/ohlcv/:symbol', getOHLCVData);
router.get('/ticker/:symbol', getTickerData);
router.get('/summaries', getMarketSummaries);
router.get('/indicators/:symbol', getTechnicalIndicators);
router.get('/insights/:symbol', getAIInsights);

// Protected routes (admin only)
router.post('/update', authenticate, authorize('admin'), updateMarketData);
router.post('/batch-update', authenticate, authorize('admin'), batchUpdateMarketData);

export default router; 