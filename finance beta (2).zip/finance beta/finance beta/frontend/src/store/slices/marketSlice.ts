import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import axios from 'axios';

export interface Asset {
  id: string;
  symbol: string;
  name: string;
  type: 'crypto' | 'stock' | 'tokenized';
  price: number;
  change24h: number;
  volume24h: number;
  marketCap?: number;
  imageUrl?: string;
}

export interface MarketState {
  assets: Asset[];
  filteredAssets: Asset[];
  selectedAsset: Asset | null;
  loading: boolean;
  error: string | null;
  filters: {
    type: string[];
    search: string;
    sortBy: string;
    sortDirection: 'asc' | 'desc';
  };
}

const initialState: MarketState = {
  assets: [],
  filteredAssets: [],
  selectedAsset: null,
  loading: false,
  error: null,
  filters: {
    type: [],
    search: '',
    sortBy: 'price',
    sortDirection: 'desc',
  },
};

export const fetchMarketData = createAsyncThunk('market/fetchMarketData', async (_, { rejectWithValue }) => {
  try {
    const response = await axios.get('/api/market/assets');
    return response.data;
  } catch (error: any) {
    return rejectWithValue(error.response?.data?.message || 'Failed to fetch market data');
  }
});

export const fetchAssetDetails = createAsyncThunk(
  'market/fetchAssetDetails',
  async (assetId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(`/api/market/assets/${assetId}`);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch asset details');
    }
  }
);

const marketSlice = createSlice({
  name: 'market',
  initialState,
  reducers: {
    setSelectedAsset: (state, action: PayloadAction<Asset | null>) => {
      state.selectedAsset = action.payload;
    },
    setFilters: (state, action: PayloadAction<Partial<MarketState['filters']>>) => {
      state.filters = { ...state.filters, ...action.payload };
      
      // Apply filters
      let filtered = [...state.assets];
      
      // Filter by type
      if (state.filters.type.length > 0) {
        filtered = filtered.filter(asset => state.filters.type.includes(asset.type));
      }
      
      // Filter by search term
      if (state.filters.search) {
        const searchTerm = state.filters.search.toLowerCase();
        filtered = filtered.filter(
          asset => 
            asset.name.toLowerCase().includes(searchTerm) || 
            asset.symbol.toLowerCase().includes(searchTerm)
        );
      }
      
      // Sort
      filtered.sort((a, b) => {
        const sortBy = state.filters.sortBy as keyof Asset;
        const aValue = a[sortBy];
        const bValue = b[sortBy];
        
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          return state.filters.sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
        }
        
        if (typeof aValue === 'string' && typeof bValue === 'string') {
          return state.filters.sortDirection === 'asc' 
            ? aValue.localeCompare(bValue) 
            : bValue.localeCompare(aValue);
        }
        
        return 0;
      });
      
      state.filteredAssets = filtered;
    },
    clearFilters: (state) => {
      state.filters = initialState.filters;
      state.filteredAssets = state.assets;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchMarketData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchMarketData.fulfilled, (state, action: PayloadAction<Asset[]>) => {
        state.loading = false;
        state.assets = action.payload;
        state.filteredAssets = action.payload;
      })
      .addCase(fetchMarketData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchAssetDetails.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAssetDetails.fulfilled, (state, action: PayloadAction<Asset>) => {
        state.loading = false;
        state.selectedAsset = action.payload;
      })
      .addCase(fetchAssetDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { setSelectedAsset, setFilters, clearFilters } = marketSlice.actions;
export default marketSlice.reducer; 