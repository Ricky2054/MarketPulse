import express from 'express';
import {
  register,
  login,
  logout,
  getMe,
  updatePassword,
  forgotPassword,
  resetPassword,
  verifyEmail,
} from '../controllers/authController.js';
import { authenticate } from '../middleware/auth.js';
import { validate, schemas } from '../utils/validator.js';

const router = express.Router();

// Public routes
router.post('/register', validate(schemas.userRegister), register);
router.post('/login', validate(schemas.userLogin), login);
router.post('/forgot-password', forgotPassword);
router.put('/reset-password/:resetToken', resetPassword);
router.get('/verify-email/:verificationToken', verifyEmail);

// Protected routes
router.use(authenticate);
router.get('/me', getMe);
router.post('/logout', logout);
router.put('/update-password', validate(schemas.passwordChange), updatePassword);

export default router; 