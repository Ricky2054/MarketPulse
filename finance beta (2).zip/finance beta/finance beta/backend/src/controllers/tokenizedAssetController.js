import TokenizedAsset from '../models/TokenizedAsset.js';
import Transaction from '../models/Transaction.js';
import Portfolio from '../models/Portfolio.js';
import AppError from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { io } from '../index.js';

// @desc    Get all tokenized assets
// @route   GET /api/v1/tokenized-assets
// @access  Public
export const getTokenizedAssets = async (req, res, next) => {
  try {
    const { category, status, sort, limit = 20, page = 1 } = req.query;
    
    // Build query
    const query = {};
    
    // Filter by category
    if (category) {
      query.category = category;
    }
    
    // Filter by status
    if (status) {
      query.status = status;
    } else {
      // By default, only show active assets
      query.isActive = true;
    }
    
    // Count total documents
    const total = await TokenizedAsset.countDocuments(query);
    
    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    // Build sort object
    let sortObj = {};
    if (sort) {
      const sortFields = sort.split(',');
      sortFields.forEach(field => {
        if (field.startsWith('-')) {
          sortObj[field.substring(1)] = -1;
        } else {
          sortObj[field] = 1;
        }
      });
    } else {
      // Default sort by market cap
      sortObj = { marketCap: -1 };
    }
    
    // Execute query
    const tokenizedAssets = await TokenizedAsset.find(query)
      .sort(sortObj)
      .skip(skip)
      .limit(parseInt(limit));
    
    res.status(200).json({
      success: true,
      count: tokenizedAssets.length,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / parseInt(limit)),
      },
      data: tokenizedAssets,
    });
  } catch (error) {
    logger.error(`Error getting tokenized assets: ${error.message}`);
    next(error);
  }
};

// @desc    Get single tokenized asset
// @route   GET /api/v1/tokenized-assets/:symbol
// @access  Public
export const getTokenizedAsset = async (req, res, next) => {
  try {
    const { symbol } = req.params;
    
    const tokenizedAsset = await TokenizedAsset.findOne({
      symbol: symbol.toUpperCase(),
    });
    
    if (!tokenizedAsset) {
      return next(new AppError(`Tokenized asset not found with symbol ${symbol}`, 404));
    }
    
    res.status(200).json({
      success: true,
      data: tokenizedAsset,
    });
  } catch (error) {
    logger.error(`Error getting tokenized asset: ${error.message}`);
    next(error);
  }
};

// @desc    Create new tokenized asset
// @route   POST /api/v1/tokenized-assets
// @access  Private/Admin
export const createTokenizedAsset = async (req, res, next) => {
  try {
    // Check if asset already exists
    const existingAsset = await TokenizedAsset.findOne({
      symbol: req.body.symbol.toUpperCase(),
    });
    
    if (existingAsset) {
      return next(new AppError(`Tokenized asset with symbol ${req.body.symbol} already exists`, 400));
    }
    
    // Create asset
    const tokenizedAsset = await TokenizedAsset.create({
      ...req.body,
      symbol: req.body.symbol.toUpperCase(),
      createdBy: req.user.id,
    });
    
    logger.info(`Tokenized asset created: ${tokenizedAsset.symbol} by user ${req.user.id}`);
    
    res.status(201).json({
      success: true,
      data: tokenizedAsset,
    });
  } catch (error) {
    logger.error(`Error creating tokenized asset: ${error.message}`);
    next(error);
  }
};

// @desc    Update tokenized asset
// @route   PUT /api/v1/tokenized-assets/:symbol
// @access  Private/Admin
export const updateTokenizedAsset = async (req, res, next) => {
  try {
    const { symbol } = req.params;
    
    // Find asset
    let tokenizedAsset = await TokenizedAsset.findOne({
      symbol: symbol.toUpperCase(),
    });
    
    if (!tokenizedAsset) {
      return next(new AppError(`Tokenized asset not found with symbol ${symbol}`, 404));
    }
    
    // Update asset
    tokenizedAsset = await TokenizedAsset.findOneAndUpdate(
      { symbol: symbol.toUpperCase() },
      { ...req.body, updatedBy: req.user.id },
      { new: true, runValidators: true }
    );
    
    logger.info(`Tokenized asset updated: ${tokenizedAsset.symbol} by user ${req.user.id}`);
    
    res.status(200).json({
      success: true,
      data: tokenizedAsset,
    });
  } catch (error) {
    logger.error(`Error updating tokenized asset: ${error.message}`);
    next(error);
  }
};

// @desc    Delete tokenized asset
// @route   DELETE /api/v1/tokenized-assets/:symbol
// @access  Private/Admin
export const deleteTokenizedAsset = async (req, res, next) => {
  try {
    const { symbol } = req.params;
    
    // Find asset
    const tokenizedAsset = await TokenizedAsset.findOne({
      symbol: symbol.toUpperCase(),
    });
    
    if (!tokenizedAsset) {
      return next(new AppError(`Tokenized asset not found with symbol ${symbol}`, 404));
    }
    
    // Check if asset is being used in any portfolios
    const portfoliosWithAsset = await Portfolio.countDocuments({
      'assets.symbol': symbol.toUpperCase(),
      'assets.type': 'tokenized',
    });
    
    if (portfoliosWithAsset > 0) {
      return next(
        new AppError(
          `Cannot delete asset that is being used in ${portfoliosWithAsset} portfolios`,
          400
        )
      );
    }
    
    // Delete asset
    await tokenizedAsset.deleteOne();
    
    logger.info(`Tokenized asset deleted: ${symbol} by user ${req.user.id}`);
    
    res.status(200).json({
      success: true,
      data: {},
    });
  } catch (error) {
    logger.error(`Error deleting tokenized asset: ${error.message}`);
    next(error);
  }
};

// @desc    Buy tokenized asset
// @route   POST /api/v1/tokenized-assets/:symbol/buy
// @access  Private
export const buyTokenizedAsset = async (req, res, next) => {
  try {
    const { symbol } = req.params;
    const { quantity, portfolioId } = req.body;
    
    if (!quantity || quantity <= 0) {
      return next(new AppError('Please provide a valid quantity', 400));
    }
    
    if (!portfolioId) {
      return next(new AppError('Please provide a portfolio ID', 400));
    }
    
    // Find asset
    const tokenizedAsset = await TokenizedAsset.findOne({
      symbol: symbol.toUpperCase(),
    });
    
    if (!tokenizedAsset) {
      return next(new AppError(`Tokenized asset not found with symbol ${symbol}`, 404));
    }
    
    // Check if asset is active
    if (!tokenizedAsset.isActive) {
      return next(new AppError(`Tokenized asset ${symbol} is not active for trading`, 400));
    }
    
    // Find portfolio
    const portfolio = await Portfolio.findById(portfolioId);
    
    if (!portfolio) {
      return next(new AppError(`Portfolio not found with id ${portfolioId}`, 404));
    }
    
    // Check if portfolio belongs to user
    if (portfolio.user.toString() !== req.user.id) {
      return next(new AppError('Not authorized to update this portfolio', 401));
    }
    
    // Calculate total cost
    const totalCost = quantity * tokenizedAsset.price;
    
    // Create transaction
    const transaction = await Transaction.create({
      user: req.user.id,
      portfolio: portfolioId,
      asset: tokenizedAsset._id,
      symbol: tokenizedAsset.symbol,
      type: 'buy',
      quantity,
      price: tokenizedAsset.price,
      total: totalCost,
      status: 'completed',
    });
    
    // Update portfolio
    const assetIndex = portfolio.assets.findIndex(
      (a) => a.symbol === symbol.toUpperCase() && a.type === 'tokenized'
    );
    
    if (assetIndex > -1) {
      // Update existing asset
      const existingAsset = portfolio.assets[assetIndex];
      const totalValue = existingAsset.quantity * existingAsset.averagePrice + quantity * tokenizedAsset.price;
      const totalQuantity = existingAsset.quantity + quantity;
      
      portfolio.assets[assetIndex].quantity = totalQuantity;
      portfolio.assets[assetIndex].averagePrice = totalValue / totalQuantity;
      portfolio.assets[assetIndex].currentValue = totalQuantity * tokenizedAsset.price;
    } else {
      // Add new asset
      portfolio.assets.push({
        symbol: tokenizedAsset.symbol,
        name: tokenizedAsset.name,
        type: 'tokenized',
        quantity,
        averagePrice: tokenizedAsset.price,
        currentPrice: tokenizedAsset.price,
        currentValue: quantity * tokenizedAsset.price,
      });
    }
    
    // Save portfolio
    await portfolio.save();
    
    logger.info(`User ${req.user.id} bought ${quantity} ${symbol} for ${totalCost}`);
    
    res.status(200).json({
      success: true,
      data: {
        transaction,
        portfolio,
      },
    });
  } catch (error) {
    logger.error(`Error buying tokenized asset: ${error.message}`);
    next(error);
  }
};

// @desc    Sell tokenized asset
// @route   POST /api/v1/tokenized-assets/:symbol/sell
// @access  Private
export const sellTokenizedAsset = async (req, res, next) => {
  try {
    const { symbol } = req.params;
    const { quantity, portfolioId } = req.body;
    
    if (!quantity || quantity <= 0) {
      return next(new AppError('Please provide a valid quantity', 400));
    }
    
    if (!portfolioId) {
      return next(new AppError('Please provide a portfolio ID', 400));
    }
    
    // Find asset
    const tokenizedAsset = await TokenizedAsset.findOne({
      symbol: symbol.toUpperCase(),
    });
    
    if (!tokenizedAsset) {
      return next(new AppError(`Tokenized asset not found with symbol ${symbol}`, 404));
    }
    
    // Check if asset is active
    if (!tokenizedAsset.isActive) {
      return next(new AppError(`Tokenized asset ${symbol} is not active for trading`, 400));
    }
    
    // Find portfolio
    const portfolio = await Portfolio.findById(portfolioId);
    
    if (!portfolio) {
      return next(new AppError(`Portfolio not found with id ${portfolioId}`, 404));
    }
    
    // Check if portfolio belongs to user
    if (portfolio.user.toString() !== req.user.id) {
      return next(new AppError('Not authorized to update this portfolio', 401));
    }
    
    // Find asset in portfolio
    const assetIndex = portfolio.assets.findIndex(
      (a) => a.symbol === symbol.toUpperCase() && a.type === 'tokenized'
    );
    
    if (assetIndex === -1) {
      return next(new AppError(`Asset ${symbol} not found in portfolio`, 404));
    }
    
    // Check if user has enough quantity
    if (portfolio.assets[assetIndex].quantity < quantity) {
      return next(
        new AppError(
          `Not enough quantity to sell. You have ${portfolio.assets[assetIndex].quantity} but trying to sell ${quantity}`,
          400
        )
      );
    }
    
    // Calculate total proceeds and profit/loss
    const totalProceeds = quantity * tokenizedAsset.price;
    const acquisitionCost = quantity * portfolio.assets[assetIndex].averagePrice;
    const profitLoss = totalProceeds - acquisitionCost;
    
    // Create transaction
    const transaction = await Transaction.create({
      user: req.user.id,
      portfolio: portfolioId,
      asset: tokenizedAsset._id,
      symbol: tokenizedAsset.symbol,
      type: 'sell',
      quantity,
      price: tokenizedAsset.price,
      total: totalProceeds,
      profitLoss,
      status: 'completed',
    });
    
    // Update portfolio
    if (portfolio.assets[assetIndex].quantity === quantity) {
      // Remove asset if selling all
      portfolio.assets.splice(assetIndex, 1);
    } else {
      // Update quantity
      portfolio.assets[assetIndex].quantity -= quantity;
      portfolio.assets[assetIndex].currentValue = portfolio.assets[assetIndex].quantity * tokenizedAsset.price;
    }
    
    // Save portfolio
    await portfolio.save();
    
    logger.info(`User ${req.user.id} sold ${quantity} ${symbol} for ${totalProceeds} (P/L: ${profitLoss})`);
    
    res.status(200).json({
      success: true,
      data: {
        transaction,
        portfolio,
        profitLoss,
      },
    });
  } catch (error) {
    logger.error(`Error selling tokenized asset: ${error.message}`);
    next(error);
  }
};

// @desc    Update tokenized asset price
// @route   PUT /api/v1/tokenized-assets/:id/price
// @access  Private (Admin/System)
export const updateTokenizedAssetPrice = async (req, res, next) => {
  try {
    const { price, volume } = req.body;
    
    if (!price) {
      return next(new AppError('Please provide a price', 400));
    }
    
    let asset = await TokenizedAsset.findById(req.params.id);
    
    if (!asset) {
      return next(new AppError(`Tokenized asset not found with id of ${req.params.id}`, 404));
    }
    
    // Update price
    await asset.updatePrice(price, volume);
    
    // Emit price update event
    io.emit('tokenizedAssetPriceUpdate', {
      symbol: asset.symbol,
      price: asset.tokenPrice,
      updatedAt: new Date(),
    });
    
    res.status(200).json({
      success: true,
      data: asset,
    });
  } catch (error) {
    logger.error(`Error updating tokenized asset price: ${error.message}`);
    next(error);
  }
};

// @desc    Get tokenized asset market stats
// @route   GET /api/v1/tokenized-assets/market/stats
// @access  Public
export const getMarketStats = async (req, res, next) => {
  try {
    // Get market statistics
    const stats = await TokenizedAsset.getMarketStats();
    
    res.status(200).json({
      success: true,
      data: stats,
    });
  } catch (error) {
    logger.error(`Error getting tokenized asset market stats: ${error.message}`);
    next(error);
  }
};

// @desc    Tokenize an asset
// @route   POST /api/v1/tokenized-assets/tokenize
// @access  Private
export const tokenizeAsset = async (req, res, next) => {
  try {
    const {
      name,
      symbol,
      description,
      assetType,
      tokenStandard,
      blockchain,
      totalSupply,
      tokenPrice,
      underlyingAsset,
      issuer,
      governance,
    } = req.body;
    
    // Validate required fields
    if (
      !name ||
      !symbol ||
      !description ||
      !assetType ||
      !tokenStandard ||
      !blockchain ||
      !totalSupply ||
      !tokenPrice ||
      !underlyingAsset ||
      !issuer
    ) {
      return next(new AppError('Please provide all required fields', 400));
    }
    
    // Check if asset with the same symbol already exists
    const existingAsset = await TokenizedAsset.findOne({ symbol });
    if (existingAsset) {
      return next(new AppError(`Tokenized asset with symbol ${symbol} already exists`, 400));
    }
    
    // Create tokenized asset
    const asset = await TokenizedAsset.create({
      name,
      symbol,
      description,
      assetType,
      tokenStandard,
      blockchain,
      totalSupply,
      circulatingSupply: totalSupply, // Initially all tokens are in circulation
      tokenPrice,
      marketCap: totalSupply * tokenPrice,
      underlyingAsset,
      issuer,
      governance,
      status: 'pending', // Pending verification
      verified: false,
      createdBy: req.user.id,
      priceHistory: [
        {
          date: new Date(),
          price: tokenPrice,
          volume: 0,
        },
      ],
    });
    
    // Create transaction record for tokenization
    const transaction = await Transaction.create({
      userId: req.user.id,
      assetId: asset._id,
      type: 'tokenization',
      status: 'completed',
      quantity: totalSupply,
      price: tokenPrice,
      totalAmount: totalSupply * tokenPrice,
      date: new Date(),
      notes: `Initial tokenization of ${name}`,
      blockchain: {
        network: blockchain.network,
        txHash: blockchain.deploymentTxHash,
      },
    });
    
    // Log tokenization
    logger.info(`Asset tokenized: ${asset.symbol} by user ${req.user.id}`);
    
    res.status(201).json({
      success: true,
      data: {
        asset,
        transaction,
      },
    });
  } catch (error) {
    logger.error(`Error tokenizing asset: ${error.message}`);
    next(error);
  }
}; 