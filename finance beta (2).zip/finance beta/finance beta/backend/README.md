# Finance App Backend

A comprehensive backend API for a finance application with tokenization features, real-time market data, portfolio management, and more.

## Features

- **User Authentication**: Secure registration, login, and account management
- **Market Data**: Real-time and historical market data for various asset types
- **Portfolio Management**: Create and manage investment portfolios
- **Tokenized Assets**: Support for tokenized real-world assets
- **Alerts**: Price and news alerts with multi-channel notifications
- **News**: Financial news with sentiment analysis and asset relevance
- **Real-time Updates**: Socket.io integration for live data

## Tech Stack

- **Node.js**: JavaScript runtime
- **Express**: Web framework
- **MongoDB**: NoSQL database for flexible data storage
- **PostgreSQL**: Relational database for structured data
- **Redis**: In-memory data store for caching and session management
- **Socket.io**: Real-time bidirectional event-based communication
- **JWT**: JSON Web Tokens for authentication
- **Winston**: Logging library
- **Joi**: Schema validation
- **Nodemailer**: Email sending
- **Twilio**: SMS notifications
- **Web-Push**: Push notifications

## Prerequisites

- Node.js (v18 or higher)
- MongoDB
- PostgreSQL
- Redis

## Installation

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
3. Copy the environment variables file:
   ```
   cp .env.example .env
   ```
4. Update the `.env` file with your configuration
5. Start the development server:
   ```
   npm run dev
   ```

## API Documentation

### Authentication

- `POST /api/v1/auth/register`: Register a new user
- `POST /api/v1/auth/login`: Login a user
- `POST /api/v1/auth/logout`: Logout a user
- `GET /api/v1/auth/me`: Get current user
- `PUT /api/v1/auth/update-password`: Update password
- `POST /api/v1/auth/forgot-password`: Request password reset
- `PUT /api/v1/auth/reset-password`: Reset password with token

### Users

- `GET /api/v1/users`: Get all users (admin)
- `GET /api/v1/users/:id`: Get user by ID
- `PUT /api/v1/users/:id`: Update user
- `DELETE /api/v1/users/:id`: Delete user
- `POST /api/v1/users/push-subscription`: Register push subscription

### Market Data

- `GET /api/v1/market-data/ohlcv/:symbol`: Get OHLCV data for a symbol
- `GET /api/v1/market-data/ticker/:symbol`: Get latest ticker data for a symbol
- `GET /api/v1/market-data/summaries`: Get market summaries for multiple symbols
- `GET /api/v1/market-data/indicators/:symbol`: Get technical indicators for a symbol
- `GET /api/v1/market-data/insights/:symbol`: Get AI insights for a symbol
- `POST /api/v1/market-data/update`: Update market data (admin)
- `POST /api/v1/market-data/batch-update`: Batch update market data (admin)

### Portfolios

- `GET /api/v1/portfolios`: Get user portfolios
- `GET /api/v1/portfolios/:id`: Get portfolio by ID
- `POST /api/v1/portfolios`: Create a new portfolio
- `PUT /api/v1/portfolios/:id`: Update portfolio
- `DELETE /api/v1/portfolios/:id`: Delete portfolio
- `POST /api/v1/portfolios/:id/assets`: Add asset to portfolio
- `PUT /api/v1/portfolios/:id/assets/:symbol`: Update asset in portfolio
- `DELETE /api/v1/portfolios/:id/assets/:symbol`: Remove asset from portfolio
- `GET /api/v1/portfolios/:id/performance`: Get portfolio performance

### Tokenized Assets

- `GET /api/v1/tokenized-assets`: Get all tokenized assets
- `GET /api/v1/tokenized-assets/:symbol`: Get tokenized asset by symbol
- `POST /api/v1/tokenized-assets`: Create a new tokenized asset (admin)
- `PUT /api/v1/tokenized-assets/:symbol`: Update tokenized asset (admin)
- `DELETE /api/v1/tokenized-assets/:symbol`: Delete tokenized asset (admin)
- `POST /api/v1/tokenized-assets/:symbol/buy`: Buy tokenized asset
- `POST /api/v1/tokenized-assets/:symbol/sell`: Sell tokenized asset

### Alerts

- `GET /api/v1/alerts`: Get user alerts
- `GET /api/v1/alerts/:id`: Get alert by ID
- `POST /api/v1/alerts`: Create a new alert
- `PUT /api/v1/alerts/:id`: Update alert
- `DELETE /api/v1/alerts/:id`: Delete alert
- `GET /api/v1/alerts/history`: Get alert history

### News

- `GET /api/v1/news`: Get all news articles
- `GET /api/v1/news/:id`: Get news article by ID
- `POST /api/v1/news`: Create a new news article (admin)
- `PUT /api/v1/news/:id`: Update news article (admin)
- `DELETE /api/v1/news/:id`: Delete news article (admin)
- `GET /api/v1/news/trending`: Get trending news
- `GET /api/v1/news/asset/:symbol`: Get news by asset
- `GET /api/v1/news/sentiment/:symbol`: Get news sentiment for asset
- `GET /api/v1/news/metadata`: Get news metadata (categories, tags, sources)

## Socket.io Events

### Client to Server

- `authenticate`: Authenticate socket connection
- `subscribe`: Subscribe to market updates
- `unsubscribe`: Unsubscribe from market updates
- `subscribePortfolio`: Subscribe to portfolio updates
- `unsubscribePortfolio`: Unsubscribe from portfolio updates
- `subscribeAlerts`: Subscribe to alerts
- `unsubscribeAlerts`: Unsubscribe from alerts

### Server to Client

- `authenticated`: Authentication successful
- `error`: Error message
- `priceUpdate`: Price update for subscribed symbol
- `portfolioUpdate`: Portfolio update
- `alert`: Alert notification
- `newsUpdate`: News update for subscribed symbol
- `notification`: General notification

## License

MIT 