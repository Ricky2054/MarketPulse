import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import axios from 'axios';
import { Asset } from './marketSlice';

export interface Alert {
  id: string;
  userId: string;
  assetId: string;
  asset: Asset;
  type: 'price' | 'volume' | 'volatility' | 'news' | 'custom';
  condition: 'above' | 'below' | 'percent_change' | 'custom';
  threshold: number;
  status: 'active' | 'triggered' | 'disabled';
  createdAt: string;
  triggeredAt?: string;
  notificationSent: boolean;
  message?: string;
}

export interface AlertsState {
  alerts: Alert[];
  loading: boolean;
  error: string | null;
}

const initialState: AlertsState = {
  alerts: [],
  loading: false,
  error: null,
};

export const fetchAlerts = createAsyncThunk('alerts/fetchAlerts', async (_, { rejectWithValue }) => {
  try {
    const token = localStorage.getItem('token');
    if (!token) return rejectWithValue('No token found');

    const response = await axios.get('/api/alerts', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error: any) {
    return rejectWithValue(error.response?.data?.message || 'Failed to fetch alerts');
  }
});

export const createAlert = createAsyncThunk(
  'alerts/createAlert',
  async (
    {
      assetId,
      type,
      condition,
      threshold,
      message,
    }: {
      assetId: string;
      type: Alert['type'];
      condition: Alert['condition'];
      threshold: number;
      message?: string;
    },
    { rejectWithValue }
  ) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return rejectWithValue('No token found');

      const response = await axios.post(
        '/api/alerts',
        { assetId, type, condition, threshold, message },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to create alert');
    }
  }
);

export const updateAlert = createAsyncThunk(
  'alerts/updateAlert',
  async (
    {
      alertId,
      status,
      threshold,
      message,
    }: {
      alertId: string;
      status?: Alert['status'];
      threshold?: number;
      message?: string;
    },
    { rejectWithValue }
  ) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return rejectWithValue('No token found');

      const response = await axios.put(
        `/api/alerts/${alertId}`,
        { status, threshold, message },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to update alert');
    }
  }
);

export const deleteAlert = createAsyncThunk(
  'alerts/deleteAlert',
  async (alertId: string, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return rejectWithValue('No token found');

      await axios.delete(`/api/alerts/${alertId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      return alertId;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to delete alert');
    }
  }
);

const alertsSlice = createSlice({
  name: 'alerts',
  initialState,
  reducers: {
    markAlertAsRead: (state, action: PayloadAction<string>) => {
      const alertId = action.payload;
      const alert = state.alerts.find((a) => a.id === alertId);
      if (alert) {
        alert.notificationSent = true;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Alerts
      .addCase(fetchAlerts.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAlerts.fulfilled, (state, action: PayloadAction<Alert[]>) => {
        state.loading = false;
        state.alerts = action.payload;
      })
      .addCase(fetchAlerts.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Create Alert
      .addCase(createAlert.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createAlert.fulfilled, (state, action: PayloadAction<Alert>) => {
        state.loading = false;
        state.alerts.push(action.payload);
      })
      .addCase(createAlert.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Update Alert
      .addCase(updateAlert.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateAlert.fulfilled, (state, action: PayloadAction<Alert>) => {
        state.loading = false;
        const index = state.alerts.findIndex((alert) => alert.id === action.payload.id);
        if (index !== -1) {
          state.alerts[index] = action.payload;
        }
      })
      .addCase(updateAlert.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Delete Alert
      .addCase(deleteAlert.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteAlert.fulfilled, (state, action: PayloadAction<string>) => {
        state.loading = false;
        state.alerts = state.alerts.filter((alert) => alert.id !== action.payload);
      })
      .addCase(deleteAlert.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { markAlertAsRead } = alertsSlice.actions;
export default alertsSlice.reducer; 