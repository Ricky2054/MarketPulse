import MarketData from '../models/MarketData.js';
import Asset from '../models/Asset.js';
import TokenizedAsset from '../models/TokenizedAsset.js';
import AppError from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { io } from '../index.js';

// @desc    Get OHLCV data for a symbol
// @route   GET /api/v1/market-data/ohlcv/:symbol
// @access  Public
export const getOHLCVData = async (req, res, next) => {
  try {
    const { symbol } = req.params;
    const interval = req.query.interval || '1d';
    const limit = parseInt(req.query.limit, 10) || 100;
    const startTime = req.query.startTime;
    const endTime = req.query.endTime;
    
    // Check if asset exists
    let asset;
    
    // Try to find in regular assets
    asset = await Asset.findOne({ symbol: symbol.toUpperCase() });
    
    // If not found, try tokenized assets
    if (!asset) {
      asset = await TokenizedAsset.findOne({ symbol: symbol.toUpperCase() });
    }
    
    if (!asset) {
      return next(new AppError(`Asset not found with symbol ${symbol}`, 404));
    }
    
    // Get OHLCV data
    const ohlcvData = await MarketData.getOHLCV(
      symbol.toUpperCase(),
      interval,
      limit,
      startTime,
      endTime
    );
    
    res.status(200).json({
      success: true,
      count: ohlcvData.length,
      data: ohlcvData,
    });
  } catch (error) {
    logger.error(`Error getting OHLCV data: ${error.message}`);
    next(error);
  }
};

// @desc    Get latest ticker data for a symbol
// @route   GET /api/v1/market-data/ticker/:symbol
// @access  Public
export const getTickerData = async (req, res, next) => {
  try {
    const { symbol } = req.params;
    
    // Check if asset exists
    let asset;
    
    // Try to find in regular assets
    asset = await Asset.findOne({ symbol: symbol.toUpperCase() });
    
    // If not found, try tokenized assets
    if (!asset) {
      asset = await TokenizedAsset.findOne({ symbol: symbol.toUpperCase() });
    }
    
    if (!asset) {
      return next(new AppError(`Asset not found with symbol ${symbol}`, 404));
    }
    
    // Get latest ticker data
    const tickerData = await MarketData.getLatestTicker(symbol.toUpperCase());
    
    if (!tickerData) {
      return next(new AppError(`No ticker data found for symbol ${symbol}`, 404));
    }
    
    res.status(200).json({
      success: true,
      data: tickerData,
    });
  } catch (error) {
    logger.error(`Error getting ticker data: ${error.message}`);
    next(error);
  }
};

// @desc    Get market summaries for multiple symbols
// @route   GET /api/v1/market-data/summaries
// @access  Public
export const getMarketSummaries = async (req, res, next) => {
  try {
    const symbols = req.query.symbols ? req.query.symbols.split(',') : [];
    
    // Get market summaries
    const summaries = await MarketData.getMarketSummaries(
      symbols.map((s) => s.toUpperCase())
    );
    
    res.status(200).json({
      success: true,
      count: summaries.length,
      data: summaries,
    });
  } catch (error) {
    logger.error(`Error getting market summaries: ${error.message}`);
    next(error);
  }
};

// @desc    Get technical indicators for a symbol
// @route   GET /api/v1/market-data/indicators/:symbol
// @access  Public
export const getTechnicalIndicators = async (req, res, next) => {
  try {
    const { symbol } = req.params;
    const indicators = req.query.indicators ? req.query.indicators.split(',') : [];
    
    // Check if asset exists
    let asset;
    
    // Try to find in regular assets
    asset = await Asset.findOne({ symbol: symbol.toUpperCase() });
    
    // If not found, try tokenized assets
    if (!asset) {
      asset = await TokenizedAsset.findOne({ symbol: symbol.toUpperCase() });
    }
    
    if (!asset) {
      return next(new AppError(`Asset not found with symbol ${symbol}`, 404));
    }
    
    // Get technical indicators
    const technicalIndicators = await MarketData.getTechnicalIndicators(
      symbol.toUpperCase(),
      indicators
    );
    
    if (!technicalIndicators) {
      return next(new AppError(`No technical indicators found for symbol ${symbol}`, 404));
    }
    
    res.status(200).json({
      success: true,
      data: technicalIndicators,
    });
  } catch (error) {
    logger.error(`Error getting technical indicators: ${error.message}`);
    next(error);
  }
};

// @desc    Get AI insights for a symbol
// @route   GET /api/v1/market-data/insights/:symbol
// @access  Public
export const getAIInsights = async (req, res, next) => {
  try {
    const { symbol } = req.params;
    
    // Check if asset exists
    let asset;
    
    // Try to find in regular assets
    asset = await Asset.findOne({ symbol: symbol.toUpperCase() });
    
    // If not found, try tokenized assets
    if (!asset) {
      asset = await TokenizedAsset.findOne({ symbol: symbol.toUpperCase() });
    }
    
    if (!asset) {
      return next(new AppError(`Asset not found with symbol ${symbol}`, 404));
    }
    
    // Get AI insights
    const insights = await MarketData.getAIInsights(symbol.toUpperCase());
    
    if (!insights) {
      return next(new AppError(`No AI insights found for symbol ${symbol}`, 404));
    }
    
    res.status(200).json({
      success: true,
      data: insights,
    });
  } catch (error) {
    logger.error(`Error getting AI insights: ${error.message}`);
    next(error);
  }
};

// @desc    Update market data
// @route   POST /api/v1/market-data/update
// @access  Private (Admin/System)
export const updateMarketData = async (req, res, next) => {
  try {
    const { symbol, dataType, interval, timestamp, source, ...rest } = req.body;
    
    if (!symbol || !dataType || !source) {
      return next(new AppError('Please provide symbol, dataType, and source', 400));
    }
    
    // Check if asset exists
    let asset;
    let isTokenized = false;
    
    // Try to find in regular assets
    asset = await Asset.findOne({ symbol: symbol.toUpperCase() });
    
    // If not found, try tokenized assets
    if (!asset) {
      asset = await TokenizedAsset.findOne({ symbol: symbol.toUpperCase() });
      isTokenized = true;
    }
    
    if (!asset) {
      return next(new AppError(`Asset not found with symbol ${symbol}`, 404));
    }
    
    // Update market data
    const marketData = await MarketData.updateMarketData({
      symbol: symbol.toUpperCase(),
      dataType,
      interval,
      timestamp: timestamp || new Date(),
      source,
      ...rest,
    });
    
    // If updating ticker data, also update asset price
    if (dataType === 'ticker' && rest.ticker && rest.ticker.price) {
      if (isTokenized) {
        await asset.updatePrice(rest.ticker.price, rest.ticker.volume24h || 0);
        
        // Emit price update event
        io.emit('tokenizedAssetPriceUpdate', {
          symbol: asset.symbol,
          price: asset.tokenPrice,
          updatedAt: new Date(),
        });
      } else {
        await asset.updatePrice(rest.ticker.price, rest.ticker.volume24h || 0);
        
        // Emit price update event
        io.emit('priceUpdate', {
          symbol: asset.symbol,
          price: asset.price,
          priceChange24h: asset.priceChange24h,
          priceChangePercent24h: asset.priceChangePercent24h,
          updatedAt: new Date(),
        });
      }
    }
    
    // Log market data update
    logger.info(`Market data updated: ${symbol} ${dataType} by user ${req.user.id}`);
    
    res.status(200).json({
      success: true,
      data: marketData,
    });
  } catch (error) {
    logger.error(`Error updating market data: ${error.message}`);
    next(error);
  }
};

// @desc    Batch update market data
// @route   POST /api/v1/market-data/batch-update
// @access  Private (Admin/System)
export const batchUpdateMarketData = async (req, res, next) => {
  try {
    const { updates } = req.body;
    
    if (!updates || !Array.isArray(updates) || updates.length === 0) {
      return next(new AppError('Please provide an array of updates', 400));
    }
    
    // Process each update
    const results = [];
    
    for (const update of updates) {
      const { symbol, dataType, interval, timestamp, source, ...rest } = update;
      
      if (!symbol || !dataType || !source) {
        results.push({
          symbol,
          success: false,
          error: 'Missing required fields',
        });
        continue;
      }
      
      try {
        // Check if asset exists
        let asset;
        let isTokenized = false;
        
        // Try to find in regular assets
        asset = await Asset.findOne({ symbol: symbol.toUpperCase() });
        
        // If not found, try tokenized assets
        if (!asset) {
          asset = await TokenizedAsset.findOne({ symbol: symbol.toUpperCase() });
          isTokenized = true;
        }
        
        if (!asset) {
          results.push({
            symbol,
            success: false,
            error: `Asset not found with symbol ${symbol}`,
          });
          continue;
        }
        
        // Update market data
        const marketData = await MarketData.updateMarketData({
          symbol: symbol.toUpperCase(),
          dataType,
          interval,
          timestamp: timestamp || new Date(),
          source,
          ...rest,
        });
        
        // If updating ticker data, also update asset price
        if (dataType === 'ticker' && rest.ticker && rest.ticker.price) {
          if (isTokenized) {
            await asset.updatePrice(rest.ticker.price, rest.ticker.volume24h || 0);
            
            // Emit price update event
            io.emit('tokenizedAssetPriceUpdate', {
              symbol: asset.symbol,
              price: asset.tokenPrice,
              updatedAt: new Date(),
            });
          } else {
            await asset.updatePrice(rest.ticker.price, rest.ticker.volume24h || 0);
            
            // Emit price update event
            io.emit('priceUpdate', {
              symbol: asset.symbol,
              price: asset.price,
              priceChange24h: asset.priceChange24h,
              priceChangePercent24h: asset.priceChangePercent24h,
              updatedAt: new Date(),
            });
          }
        }
        
        results.push({
          symbol,
          success: true,
          data: marketData,
        });
      } catch (error) {
        logger.error(`Error updating market data for ${symbol}: ${error.message}`);
        results.push({
          symbol,
          success: false,
          error: error.message,
        });
      }
    }
    
    // Log batch update
    logger.info(`Batch market data update: ${results.length} updates by user ${req.user.id}`);
    
    res.status(200).json({
      success: true,
      count: results.length,
      data: results,
    });
  } catch (error) {
    logger.error(`Error batch updating market data: ${error.message}`);
    next(error);
  }
}; 