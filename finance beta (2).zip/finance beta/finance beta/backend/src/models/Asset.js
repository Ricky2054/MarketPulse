import mongoose from 'mongoose';

const AssetSchema = new mongoose.Schema(
  {
    symbol: {
      type: String,
      required: [true, 'Please provide an asset symbol'],
      unique: true,
      trim: true,
      uppercase: true,
    },
    name: {
      type: String,
      required: [true, 'Please provide an asset name'],
      trim: true,
    },
    type: {
      type: String,
      required: [true, 'Please provide an asset type'],
      enum: ['crypto', 'stock', 'tokenized', 'forex', 'commodity', 'index'],
    },
    price: {
      type: Number,
      required: [true, 'Please provide the current price'],
      min: [0, 'Price cannot be negative'],
    },
    change24h: {
      type: Number,
      default: 0,
    },
    volume24h: {
      type: Number,
      default: 0,
      min: [0, 'Volume cannot be negative'],
    },
    marketCap: {
      type: Number,
      min: [0, 'Market cap cannot be negative'],
    },
    supply: {
      circulating: {
        type: Number,
        min: [0, 'Circulating supply cannot be negative'],
      },
      total: {
        type: Number,
        min: [0, 'Total supply cannot be negative'],
      },
      max: {
        type: Number,
        min: [0, 'Max supply cannot be negative'],
      },
    },
    imageUrl: {
      type: String,
    },
    description: {
      type: String,
    },
    website: {
      type: String,
    },
    whitepaper: {
      type: String,
    },
    explorer: {
      type: String,
    },
    social: {
      twitter: String,
      reddit: String,
      telegram: String,
      github: String,
    },
    tags: [String],
    isActive: {
      type: Boolean,
      default: true,
    },
    isVerified: {
      type: Boolean,
      default: false,
    },
    launchDate: {
      type: Date,
    },
    tokenomics: {
      distribution: [
        {
          category: String,
          percentage: Number,
        },
      ],
      unlockSchedule: [
        {
          date: Date,
          percentage: Number,
          description: String,
        },
      ],
    },
    // Additional fields for tokenized assets
    tokenizedDetails: {
      assetType: {
        type: String,
        enum: ['real_estate', 'art', 'commodity', 'collectible', 'other'],
      },
      location: String,
      issuer: String,
      totalSupply: Number,
      currentSupply: Number,
      documentationUrl: String,
      images: [String],
      verificationStatus: {
        type: String,
        enum: ['verified', 'pending', 'unverified'],
      },
    },
    // Historical price data (limited recent entries)
    priceHistory: [
      {
        timestamp: Date,
        price: Number,
        volume: Number,
      },
    ],
    // Technical indicators
    technicalIndicators: {
      rsi: Number,
      macd: {
        value: Number,
        signal: Number,
        histogram: Number,
      },
      movingAverages: {
        sma20: Number,
        sma50: Number,
        sma200: Number,
        ema20: Number,
        ema50: Number,
      },
      volatility: Number,
    },
    // AI-generated insights
    aiInsights: {
      sentiment: {
        type: String,
        enum: ['very_bearish', 'bearish', 'neutral', 'bullish', 'very_bullish'],
      },
      riskLevel: {
        type: String,
        enum: ['very_low', 'low', 'medium', 'high', 'very_high'],
      },
      shortTermPrediction: String,
      longTermPrediction: String,
      correlatedAssets: [
        {
          assetId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Asset',
          },
          correlationStrength: Number,
        },
      ],
      lastUpdated: Date,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtual for asset's full URL
AssetSchema.virtual('url').get(function () {
  return `/api/market/assets/${this._id}`;
});

// Index for faster queries
AssetSchema.index({ symbol: 1 });
AssetSchema.index({ type: 1 });
AssetSchema.index({ 'tokenizedDetails.assetType': 1 });
AssetSchema.index({ isActive: 1 });

// Method to update price and calculate change
AssetSchema.methods.updatePrice = function (newPrice, volume) {
  const oldPrice = this.price;
  this.price = newPrice;
  this.volume24h = volume || this.volume24h;
  
  // Calculate 24h change percentage
  if (oldPrice > 0) {
    this.change24h = ((newPrice - oldPrice) / oldPrice) * 100;
  }
  
  // Add to price history (limited to last 100 entries)
  this.priceHistory.push({
    timestamp: new Date(),
    price: newPrice,
    volume: volume || 0,
  });
  
  // Keep only the last 100 entries
  if (this.priceHistory.length > 100) {
    this.priceHistory = this.priceHistory.slice(-100);
  }
  
  return this.save();
};

const Asset = mongoose.model('Asset', AssetSchema);

export default Asset; 