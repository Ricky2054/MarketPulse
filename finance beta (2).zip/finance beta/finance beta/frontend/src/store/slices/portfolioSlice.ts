import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import axios from 'axios';
import { Asset } from './marketSlice';

export interface Position {
  id: string;
  assetId: string;
  asset: Asset;
  quantity: number;
  averagePrice: number;
  currentValue: number;
  profitLoss: number;
  profitLossPercentage: number;
  dateAcquired: string;
}

export interface Transaction {
  id: string;
  assetId: string;
  asset: Asset;
  type: 'buy' | 'sell';
  quantity: number;
  price: number;
  total: number;
  timestamp: string;
  status: 'completed' | 'pending' | 'failed';
}

export interface PortfolioState {
  positions: Position[];
  transactions: Transaction[];
  totalValue: number;
  totalProfitLoss: number;
  totalProfitLossPercentage: number;
  loading: boolean;
  error: string | null;
}

const initialState: PortfolioState = {
  positions: [],
  transactions: [],
  totalValue: 0,
  totalProfitLoss: 0,
  totalProfitLossPercentage: 0,
  loading: false,
  error: null,
};

export const fetchPortfolio = createAsyncThunk('portfolio/fetchPortfolio', async (_, { rejectWithValue }) => {
  try {
    const token = localStorage.getItem('token');
    if (!token) return rejectWithValue('No token found');

    const response = await axios.get('/api/portfolio', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error: any) {
    return rejectWithValue(error.response?.data?.message || 'Failed to fetch portfolio');
  }
});

export const fetchTransactions = createAsyncThunk(
  'portfolio/fetchTransactions',
  async (_, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return rejectWithValue('No token found');

      const response = await axios.get('/api/portfolio/transactions', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch transactions');
    }
  }
);

export const executeTransaction = createAsyncThunk(
  'portfolio/executeTransaction',
  async (
    {
      assetId,
      type,
      quantity,
      price,
    }: {
      assetId: string;
      type: 'buy' | 'sell';
      quantity: number;
      price: number;
    },
    { rejectWithValue }
  ) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return rejectWithValue('No token found');

      const response = await axios.post(
        '/api/portfolio/transactions',
        { assetId, type, quantity, price },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to execute transaction');
    }
  }
);

const portfolioSlice = createSlice({
  name: 'portfolio',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      // Fetch Portfolio
      .addCase(fetchPortfolio.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        fetchPortfolio.fulfilled,
        (state, action: PayloadAction<{ positions: Position[]; summary: { totalValue: number; totalProfitLoss: number; totalProfitLossPercentage: number } }>) => {
          state.loading = false;
          state.positions = action.payload.positions;
          state.totalValue = action.payload.summary.totalValue;
          state.totalProfitLoss = action.payload.summary.totalProfitLoss;
          state.totalProfitLossPercentage = action.payload.summary.totalProfitLossPercentage;
        }
      )
      .addCase(fetchPortfolio.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Fetch Transactions
      .addCase(fetchTransactions.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTransactions.fulfilled, (state, action: PayloadAction<Transaction[]>) => {
        state.loading = false;
        state.transactions = action.payload;
      })
      .addCase(fetchTransactions.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Execute Transaction
      .addCase(executeTransaction.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(executeTransaction.fulfilled, (state, action: PayloadAction<Transaction>) => {
        state.loading = false;
        state.transactions = [action.payload, ...state.transactions];
      })
      .addCase(executeTransaction.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default portfolioSlice.reducer; 