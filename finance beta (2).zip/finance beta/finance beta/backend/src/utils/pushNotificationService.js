import webpush from 'web-push';
import env from '../config/env.js';
import { logger } from './logger.js';

/**
 * Push notification service for sending web push notifications
 * @class PushNotificationService
 */
class PushNotificationService {
  constructor() {
    this.initialized = false;
    this.initializeService();
  }

  /**
   * Initialize the web push service
   */
  initializeService() {
    try {
      // Check if VAPID keys are set in environment variables
      if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
        // Set VAPID details
        webpush.setVapidDetails(
          'mailto:' + env.EMAIL_FROM,
          process.env.VAPID_PUBLIC_KEY,
          process.env.VAPID_PRIVATE_KEY
        );
        
        this.initialized = true;
        logger.info('Push notification service initialized');
      } else {
        logger.warn('Push notification service not configured properly. VAPID keys missing.');
      }
    } catch (error) {
      logger.error(`Push notification service initialization error: ${error.message}`);
    }
  }

  /**
   * Send a push notification
   * @param {Object} subscription - Push subscription object
   * @param {Object} payload - Notification payload
   * @returns {Promise<Object>} Web push response
   */
  async sendNotification(subscription, payload) {
    try {
      if (!this.initialized) {
        throw new Error('Push notification service not initialized');
      }

      const response = await webpush.sendNotification(
        subscription,
        JSON.stringify(payload)
      );
      
      logger.info(`Push notification sent: ${response.statusCode}`);
      return response;
    } catch (error) {
      // Handle expired or invalid subscriptions
      if (error.statusCode === 404 || error.statusCode === 410) {
        logger.warn(`Push subscription has expired or is invalid: ${error.message}`);
        return { expired: true, error };
      }
      
      logger.error(`Error sending push notification: ${error.message}`);
      throw error;
    }
  }

  /**
   * Send an alert notification
   * @param {Object} options - Options
   * @param {Object} options.subscription - Push subscription object
   * @param {Object} options.alert - Alert object
   * @param {string} options.userId - User ID
   * @returns {Promise<Object>} Web push response
   */
  async sendAlertNotification(options) {
    const { alert, subscription } = options;
    
    const payload = {
      title: 'Finance Alert',
      body: alert.message || `${alert.condition.toUpperCase()} ${alert.threshold} for ${alert.symbol || 'your portfolio'}`,
      icon: '/icons/alert-icon.png',
      badge: '/icons/badge-icon.png',
      data: {
        url: `/alerts/${alert._id}`,
        alertId: alert._id,
        userId: options.userId,
        type: 'alert',
        timestamp: new Date().toISOString(),
      },
      actions: [
        {
          action: 'view',
          title: 'View Details',
        },
        {
          action: 'dismiss',
          title: 'Dismiss',
        },
      ],
    };
    
    return this.sendNotification(subscription, payload);
  }

  /**
   * Send a price update notification
   * @param {Object} options - Options
   * @param {Object} options.subscription - Push subscription object
   * @param {string} options.symbol - Asset symbol
   * @param {number} options.price - Current price
   * @param {number} options.priceChangePercent - Price change percentage
   * @returns {Promise<Object>} Web push response
   */
  async sendPriceUpdateNotification(options) {
    const { symbol, price, priceChangePercent, subscription } = options;
    
    const direction = priceChangePercent >= 0 ? 'up' : 'down';
    const changeText = `${Math.abs(priceChangePercent).toFixed(2)}% ${direction}`;
    
    const payload = {
      title: `${symbol} Price Update`,
      body: `Current price: $${price.toFixed(2)} (${changeText})`,
      icon: `/icons/${direction}-icon.png`,
      badge: '/icons/badge-icon.png',
      data: {
        url: `/market/${symbol}`,
        symbol,
        price,
        priceChangePercent,
        type: 'price',
        timestamp: new Date().toISOString(),
      },
      actions: [
        {
          action: 'view',
          title: 'View Chart',
        },
      ],
    };
    
    return this.sendNotification(subscription, payload);
  }

  /**
   * Send a news notification
   * @param {Object} options - Options
   * @param {Object} options.subscription - Push subscription object
   * @param {Object} options.news - News article
   * @returns {Promise<Object>} Web push response
   */
  async sendNewsNotification(options) {
    const { news, subscription } = options;
    
    const payload = {
      title: news.title,
      body: news.summary,
      icon: news.imageUrl || '/icons/news-icon.png',
      badge: '/icons/badge-icon.png',
      image: news.imageUrl,
      data: {
        url: `/news/${news._id}`,
        newsId: news._id,
        type: 'news',
        timestamp: new Date().toISOString(),
      },
      actions: [
        {
          action: 'read',
          title: 'Read Article',
        },
      ],
    };
    
    return this.sendNotification(subscription, payload);
  }

  /**
   * Generate VAPID keys
   * @returns {Object} VAPID keys
   */
  static generateVapidKeys() {
    return webpush.generateVAPIDKeys();
  }
}

// Create and export a singleton instance
const pushNotificationService = new PushNotificationService();
export default pushNotificationService; 